import {
  pgTable,
  serial,
  integer,
  text,
  numeric,
  boolean,
  timestamp,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { operatingWeeksTable } from "./weeks";

export const tasksTable = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull().default("todo"), // backlog | todo | in_progress | done | cancelled
  priority: text("priority").notNull().default("medium"), // critical | high | medium | low
  module: text("module").notNull().default("other"), // home | finance | subscriptions | product | content | field | road | growth | compliance | team | other
  type: text("type"), // feature | bug | research | content | field | admin
  dueDate: date("due_date", { mode: "string" }),
  weekId: integer("week_id").references(() => operatingWeeksTable.id),
  estimatedHours: numeric("estimated_hours", { precision: 6, scale: 2 }),
  actualHours: numeric("actual_hours", { precision: 6, scale: 2 }),
  assignedTo: text("assigned_to"),
  acceptanceCriteria: text("acceptance_criteria"),
  position: integer("position").notNull().default(0),
  isRecurring: boolean("is_recurring").notNull().default(false),
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  updatedBy: text("updated_by"),
});

export const insertTaskSchema = createInsertSchema(tasksTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasksTable.$inferSelect;
