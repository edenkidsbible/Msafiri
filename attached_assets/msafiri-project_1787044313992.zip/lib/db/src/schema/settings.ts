import {
  pgTable,
  serial,
  text,
  integer,
  numeric,
  timestamp,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const settingsTable = pgTable("settings", {
  id: serial("id").primaryKey(),
  firstFundingDate: date("first_funding_date", { mode: "string" })
    .notNull()
    .default("2026-08-14"),
  weeklyFundingAmountKes: numeric("weekly_funding_amount_kes", {
    precision: 15,
    scale: 2,
  })
    .notNull()
    .default("10000.00"),
  exchangeRateKesPerUsd: numeric("exchange_rate_kes_per_usd", {
    precision: 10,
    scale: 4,
  })
    .notNull()
    .default("129.3600"),
  fuelPricePerLitreKes: numeric("fuel_price_per_litre_kes", {
    precision: 10,
    scale: 2,
  })
    .notNull()
    .default("214.00"),
  vehicleEfficiencyKmPerLitre: numeric("vehicle_efficiency_km_per_litre", {
    precision: 8,
    scale: 2,
  })
    .notNull()
    .default("12.00"),
  cashFloorKes: numeric("cash_floor_kes", { precision: 15, scale: 2 })
    .notNull()
    .default("2500.00"),
  reserveTransferTargetKes: numeric("reserve_transfer_target_kes", {
    precision: 15,
    scale: 2,
  })
    .notNull()
    .default("1500.00"),
  monthlySubscriptionPriceKes: numeric("monthly_subscription_price_kes", {
    precision: 10,
    scale: 2,
  })
    .notNull()
    .default("0.00"),
  replitMonthlyUsd: numeric("replit_monthly_usd", { precision: 10, scale: 2 })
    .notNull()
    .default("20.00"),
  replitNextBillingDate: date("replit_next_billing_date", { mode: "string" }),
  baselineActivePaid: integer("baseline_active_paid").notNull().default(0),
  baselineDownloads: integer("baseline_downloads").notNull().default(0),
  currentMrrOverrideKes: numeric("current_mrr_override_kes", {
    precision: 15,
    scale: 2,
  }),
  updatedAt: timestamp("updated_at", { withTimezone: true })
    .notNull()
    .defaultNow()
    .$onUpdate(() => new Date()),
  updatedBy: text("updated_by"),
});

export const insertSettingsSchema = createInsertSchema(settingsTable).omit({
  id: true,
  updatedAt: true,
});
export type InsertSettings = z.infer<typeof insertSettingsSchema>;
export type Settings = typeof settingsTable.$inferSelect;
