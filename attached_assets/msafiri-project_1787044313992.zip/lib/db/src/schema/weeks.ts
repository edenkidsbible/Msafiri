import {
  pgTable,
  serial,
  integer,
  date,
  numeric,
  text,
  timestamp,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const operatingWeeksTable = pgTable("operating_weeks", {
  id: serial("id").primaryKey(),
  weekNumber: integer("week_number").notNull().unique(),
  startDate: date("start_date", { mode: "string" }).notNull(),
  endDate: date("end_date", { mode: "string" }).notNull(),
  // Planned
  plannedCashInKes: numeric("planned_cash_in_kes", { precision: 15, scale: 2 }),
  plannedCashOutKes: numeric("planned_cash_out_kes", { precision: 15, scale: 2 }),
  plannedEndingCashKes: numeric("planned_ending_cash_kes", { precision: 15, scale: 2 }),
  // Actual (computed from transactions)
  actualCashInKes: numeric("actual_cash_in_kes", { precision: 15, scale: 2 }),
  actualCashOutKes: numeric("actual_cash_out_kes", { precision: 15, scale: 2 }),
  actualEndingCashKes: numeric("actual_ending_cash_kes", { precision: 15, scale: 2 }),
  varianceKes: numeric("variance_kes", { precision: 15, scale: 2 }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const weeklyPlansTable = pgTable("weekly_plans", {
  id: serial("id").primaryKey(),
  weekId: integer("week_id").notNull().references(() => operatingWeeksTable.id),
  mainObjective: text("main_objective"),
  requiredOutcomes: text("required_outcomes").array(),
  completedOutcomes: text("completed_outcomes").array(),
  cashDecision: text("cash_decision"),
  productPriority: text("product_priority"),
  userPriority: text("user_priority"),
  fieldSprint: text("field_sprint"),
  contentPlan: text("content_plan"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  updatedBy: text("updated_by"),
});

export const weeklyReviewsTable = pgTable("weekly_reviews", {
  id: serial("id").primaryKey(),
  weekId: integer("week_id").notNull().references(() => operatingWeeksTable.id),
  whatWorked: text("what_worked"),
  whatDidntWork: text("what_didnt_work"),
  keyLearning: text("key_learning"),
  nextWeekFocus: text("next_week_focus"),
  reviewedAt: timestamp("reviewed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedBy: text("updated_by"),
});

export const insertOperatingWeekSchema = createInsertSchema(operatingWeeksTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWeeklyPlanSchema = createInsertSchema(weeklyPlansTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertWeeklyReviewSchema = createInsertSchema(weeklyReviewsTable).omit({ id: true, createdAt: true });

export type InsertOperatingWeek = z.infer<typeof insertOperatingWeekSchema>;
export type OperatingWeek = typeof operatingWeeksTable.$inferSelect;
export type InsertWeeklyPlan = z.infer<typeof insertWeeklyPlanSchema>;
export type WeeklyPlan = typeof weeklyPlansTable.$inferSelect;
export type InsertWeeklyReview = z.infer<typeof insertWeeklyReviewSchema>;
export type WeeklyReview = typeof weeklyReviewsTable.$inferSelect;
