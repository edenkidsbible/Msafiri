import {
  pgTable,
  serial,
  integer,
  text,
  boolean,
  timestamp,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { operatingWeeksTable } from "./weeks";

export const contentItemsTable = pgTable("content_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  status: text("status").notNull().default("idea"), // idea | selected | brief | script | film | edit | review | schedule | posted | measured | archive
  weekId: integer("week_id").references(() => operatingWeeksTable.id),
  isCore: boolean("is_core").notNull().default(false),
  platforms: text("platforms").array(),
  pillar: text("pillar"),
  format: text("format"),
  angle: text("angle"),
  hook: text("hook"),
  captionSeed: text("caption_seed"),
  cta: text("cta"),
  scheduledDate: date("scheduled_date", { mode: "string" }),
  postedDate: date("posted_date", { mode: "string" }),
  linkedFieldTripId: integer("linked_field_trip_id"), // FK set after field_trips
  views: integer("views"),
  clicks: integer("clicks"),
  installs: integer("installs"),
  paidSubscribersAttributed: integer("paid_subscribers_attributed"),
  founderMinutes: integer("founder_minutes"),
  notes: text("notes"),
  complianceNotes: text("compliance_notes"),
  hasComplianceWarning: boolean("has_compliance_warning").notNull().default(false),
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  updatedBy: text("updated_by"),
});

export const insertContentItemSchema = createInsertSchema(contentItemsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertContentItem = z.infer<typeof insertContentItemSchema>;
export type ContentItem = typeof contentItemsTable.$inferSelect;
