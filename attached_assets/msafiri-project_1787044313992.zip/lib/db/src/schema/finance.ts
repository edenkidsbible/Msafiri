import {
  pgTable,
  serial,
  integer,
  text,
  numeric,
  boolean,
  timestamp,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { operatingWeeksTable } from "./weeks";

export const transactionCategoriesTable = pgTable("transaction_categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // income | expense | reserve | refund
  description: text("description"),
  isSystem: boolean("is_system").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const transactionsTable = pgTable("transactions", {
  id: serial("id").primaryKey(),
  date: date("date", { mode: "string" }).notNull(),
  type: text("type").notNull(), // income | expense | refund_in | refund_out | reserve_transfer
  amountKes: numeric("amount_kes", { precision: 15, scale: 2 }).notNull(),
  description: text("description").notNull(),
  cleared: boolean("cleared").notNull().default(false),
  categoryId: integer("category_id").references(() => transactionCategoriesTable.id),
  weekId: integer("week_id").references(() => operatingWeeksTable.id),
  paymentMethod: text("payment_method"),
  reference: text("reference"),
  notes: text("notes"),
  linkedFieldTripId: integer("linked_field_trip_id"), // FK added after field_trips table
  linkedContentId: integer("linked_content_id"),      // FK added after content_items table
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
  updatedBy: text("updated_by"),
});

export const recurringExpensesTable = pgTable("recurring_expenses", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  amountKes: numeric("amount_kes", { precision: 15, scale: 2 }),
  currencyType: text("currency_type").notNull().default("KES"), // KES | USD
  amountUsd: numeric("amount_usd", { precision: 10, scale: 2 }),
  frequency: text("frequency").notNull(), // weekly | monthly | annual
  categoryId: integer("category_id").references(() => transactionCategoriesTable.id),
  nextBillingDate: date("next_billing_date", { mode: "string" }),
  isActive: boolean("is_active").notNull().default(true),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertTransactionCategorySchema = createInsertSchema(transactionCategoriesTable).omit({ id: true, createdAt: true });
export const insertTransactionSchema = createInsertSchema(transactionsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertRecurringExpenseSchema = createInsertSchema(recurringExpensesTable).omit({ id: true, createdAt: true, updatedAt: true });

export type InsertTransactionCategory = z.infer<typeof insertTransactionCategorySchema>;
export type TransactionCategory = typeof transactionCategoriesTable.$inferSelect;
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactionsTable.$inferSelect;
export type InsertRecurringExpense = z.infer<typeof insertRecurringExpenseSchema>;
export type RecurringExpense = typeof recurringExpensesTable.$inferSelect;
