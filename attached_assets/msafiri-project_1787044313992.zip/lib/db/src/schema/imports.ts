import {
  pgTable,
  serial,
  integer,
  text,
  boolean,
  timestamp,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const importBatchesTable = pgTable("import_batches", {
  id: serial("id").primaryKey(),
  status: text("status").notNull().default("pending"), // pending | dry_run | committed | rolled_back | failed
  filename: text("filename").notNull(),
  filePath: text("file_path"),
  fileChecksum: text("file_checksum"),
  sheetCount: integer("sheet_count"),
  rowsCreated: integer("rows_created"),
  rowsUpdated: integer("rows_updated"),
  rowsSkipped: integer("rows_skipped"),
  rowsErrored: integer("rows_errored"),
  warningsJson: text("warnings_json"), // JSON array
  errorsJson: text("errors_json"),     // JSON array
  sheetsJson: text("sheets_json"),     // JSON array of ImportSheetSummary
  committedAt: timestamp("committed_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertImportBatchSchema = createInsertSchema(importBatchesTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertImportBatch = z.infer<typeof insertImportBatchSchema>;
export type ImportBatch = typeof importBatchesTable.$inferSelect;
