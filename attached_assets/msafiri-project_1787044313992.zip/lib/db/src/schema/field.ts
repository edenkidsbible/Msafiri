import {
  pgTable,
  serial,
  integer,
  text,
  numeric,
  boolean,
  timestamp,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { operatingWeeksTable } from "./weeks";

export const fieldTripsTable = pgTable("field_trips", {
  id: serial("id").primaryKey(),
  date: date("date", { mode: "string" }).notNull(),
  purpose: text("purpose").notNull(),
  corridor: text("corridor"),
  status: text("status").notNull().default("planned"), // planned | in_progress | completed | cancelled
  weekId: integer("week_id").references(() => operatingWeeksTable.id),
  plannedKm: numeric("planned_km", { precision: 8, scale: 2 }),
  startOdometer: numeric("start_odometer", { precision: 10, scale: 1 }),
  endOdometer: numeric("end_odometer", { precision: 10, scale: 1 }),
  actualKm: numeric("actual_km", { precision: 8, scale: 2 }),
  parkingKes: numeric("parking_kes", { precision: 10, scale: 2 }),
  tollsKes: numeric("tolls_kes", { precision: 10, scale: 2 }),
  contingencyKes: numeric("contingency_kes", { precision: 10, scale: 2 }),
  actualFuelSpendKes: numeric("actual_fuel_spend_kes", { precision: 10, scale: 2 }),
  requiredOutputs: text("required_outputs"),
  assignedTo: text("assigned_to"),
  notes: text("notes"),
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const roadRecordsTable = pgTable("road_records", {
  id: serial("id").primaryKey(),
  recordDate: date("record_date", { mode: "string" }),
  county: text("county").notNull(),
  corridor: text("corridor").notNull(),
  landmark: text("landmark"),
  direction: text("direction"),
  dataType: text("data_type").notNull(), // speed_camera | speed_limit | road_hazard | other
  coordinates: text("coordinates"),
  speedLimitKph: integer("speed_limit_kph"),
  confidence: text("confidence").notNull().default("D"), // A | B | C | D
  sourceType: text("source_type"),
  evidence: text("evidence"),
  verifier: text("verifier"),
  lastVerifiedDate: date("last_verified_date", { mode: "string" }),
  nextAction: text("next_action"),
  status: text("status").notNull().default("needs_verification"), // active | needs_verification | archived
  linkedFieldTripId: integer("linked_field_trip_id").references(() => fieldTripsTable.id),
  notes: text("notes"),
  isDeleted: boolean("is_deleted").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertFieldTripSchema = createInsertSchema(fieldTripsTable).omit({ id: true, createdAt: true, updatedAt: true });
export const insertRoadRecordSchema = createInsertSchema(roadRecordsTable).omit({ id: true, createdAt: true, updatedAt: true });

export type InsertFieldTrip = z.infer<typeof insertFieldTripSchema>;
export type FieldTrip = typeof fieldTripsTable.$inferSelect;
export type InsertRoadRecord = z.infer<typeof insertRoadRecordSchema>;
export type RoadRecord = typeof roadRecordsTable.$inferSelect;
