import {
  pgTable,
  serial,
  integer,
  text,
  numeric,
  timestamp,
  date,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { operatingWeeksTable } from "./weeks";

export const subscriptionWeekMetricsTable = pgTable("subscription_week_metrics", {
  id: serial("id").primaryKey(),
  weekId: integer("week_id").notNull().references(() => operatingWeeksTable.id),
  periodStartDate: date("period_start_date", { mode: "string" }),
  newDownloads: integer("new_downloads"),
  trialsStarted: integer("trials_started"),
  newPaid: integer("new_paid"),
  renewals: integer("renewals"),
  cancellations: integer("cancellations"),
  activePaidEnd: integer("active_paid_end").notNull(),
  grossSalesKes: numeric("gross_sales_kes", { precision: 15, scale: 2 }),
  processorFeesKes: numeric("processor_fees_kes", { precision: 15, scale: 2 }),
  refundsKes: numeric("refunds_kes", { precision: 15, scale: 2 }),
  cashReceivedKes: numeric("cash_received_kes", { precision: 15, scale: 2 }),
  notes: text("notes"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  createdBy: text("created_by"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const insertSubscriptionWeekMetricSchema = createInsertSchema(subscriptionWeekMetricsTable).omit({ id: true, createdAt: true, updatedAt: true });
export type InsertSubscriptionWeekMetric = z.infer<typeof insertSubscriptionWeekMetricSchema>;
export type SubscriptionWeekMetric = typeof subscriptionWeekMetricsTable.$inferSelect;
