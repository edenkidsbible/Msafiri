# Build Msafiri Founder OS — Internal Business Admin Platform

## Role and mission

Act as a senior product architect, full-stack TypeScript engineer, database designer, automation engineer, QA lead, and security reviewer. Build a private internal web application called **Msafiri Founder OS** that replaces the attached Excel workbook as the day-to-day operating system for the Msafiri business.

The attached source file is:

`Msafiri_Founder_OS_Live_App_Masterplan_Aug2026-Jan2027.xlsx`

Read and analyze the workbook itself. Do not rely only on this prompt. The workbook is the authoritative source for its seed data, assumptions, field names, operating rules, dropdown values, formulas, content ideas, tasks, risks, sources, and historical/planned records.

## Business context you must preserve

- Msafiri is already live on both Android and iOS.
- Google testing, App Store Connect setup, and store account fees are already completed and must not be budgeted again.
- Real users have started downloading the app and some are paying for subscriptions.
- The founder contributes **KES 10,000 every Friday**.
- The first funding date in this operating plan is **Friday, 14 August 2026**.
- The business is founder-led, remote-first, and not ready for an office or a full-time employee.
- The live consumer app currently depends on Replit hosting costing **US$20 per month**. The planning exchange rate is editable; the workbook currently uses **KES 129.36 per US dollar**.
- Field work is required for road and speed-camera verification, user learning, and social content creation.
- Fuel currently costs **KES 214 per litre** and the founder’s car averages **12 kilometres per litre**.
- The default business timezone is **Africa/Nairobi**.
- The default business currency is **KES**, while some costs may be denominated in USD.
- The content commitment is four core posts per week, initially focused on TikTok and Instagram.
- The product must be framed as a road-safety and compliance tool. Do not create workflows or public messaging that encourage evading enforcement.

## Critical safety boundary

The existing Msafiri consumer app is live. Build this admin system as a separate private internal application or clearly isolated admin artifact. Do not modify, refactor, redeploy, or connect directly to the live consumer app or its production database without explicit approval and credentials from me.

For the first release, use manual entry, workbook import, and CSV import for app-store and subscription metrics. Create clean integration interfaces for future webhooks or APIs, but do not guess how the consumer app stores data.

## Non-negotiable product principles

1. **PostgreSQL is the source of truth.** Do not use the Excel workbook or Google Sheets as the live backend.
2. The workbook is used for one-time or repeatable import, data seeding, source traceability, and validation.
3. Spreadsheet formulas must become tested backend business rules, database queries, or calculation services. Do not merely display formula strings.
4. Derived values update immediately after relevant records are created, edited, deleted, imported, or reconciled.
5. The interface must default to a simple founder view. Do not recreate 45 spreadsheet tabs in the main navigation.
6. Advanced modules must remain available behind grouped navigation and progressive disclosure.
7. All financial calculations must use decimal-safe arithmetic. Never use JavaScript floating-point arithmetic directly for money.
8. Important actions require server-side authorization, validation, audit logs, and safe error handling.
9. Do not automatically spend money, mark a payment as made, confirm a road record, publish content, or change a growth gate. Automations may calculate, remind, draft, flag, and recommend; a responsible user must approve consequential actions.
10. Preserve data lineage: every imported record should retain its source workbook, source sheet, source row, import batch, and original raw values.

## Preferred technical architecture

Use this stack unless the environment requires an equivalent supported choice:

- Frontend: React + TypeScript.
- Styling and components: Tailwind CSS and accessible component primitives such as shadcn/ui.
- Backend: Node.js + TypeScript with a clear service layer and REST or typed RPC endpoints.
- Database: Replit managed PostgreSQL.
- ORM and migrations: Drizzle ORM.
- Validation: Zod on both client and server boundaries.
- Authentication: Replit Auth if available in this project. Keep application roles in the database rather than relying only on the authentication provider.
- File storage: Replit App Storage for the original workbook, receipts, evidence photos, road-verification files, content assets, and exports.
- Spreadsheet parsing: ExcelJS or another maintained server-side XLSX parser.
- Charts: Recharts or an equivalent accessible chart library.
- Date handling: a timezone-aware library. Store timestamps in UTC and present them in Africa/Nairobi.
- Money handling: PostgreSQL `numeric` fields plus a decimal library in application code.
- Automated tests: Vitest or Jest for unit/integration tests and Playwright for critical browser flows.

Create a clean modular codebase with folders for database schema, migrations, services, calculation rules, imports, calendar sync, scheduled jobs, UI modules, tests, and documentation.

## First task: inspect and map the workbook before building

The attached workbook contains 45 sheets, thousands of formulas, dropdown lists, source references, content records, financial plans, and operating data. Before implementing the application:

1. Parse every worksheet.
2. Generate `docs/workbook-inventory.md` containing:
   - worksheet name;
   - detected title and header row;
   - row and column counts;
   - tables, formulas, data validations, and charts detected;
   - proposed destination entity or reference table;
   - whether each column is imported, computed, archived, or ignored;
   - any ambiguity or import warning.
3. Generate `docs/formula-map.md` containing:
   - each distinct formula pattern;
   - its business meaning;
   - the backend function, SQL query, or view that replaces it;
   - at least one test case;
   - the source sheet and representative cells.
4. Generate `docs/data-model.md` and a schema diagram.
5. Do not silently omit a worksheet. If a sheet is reference-only, import it into an appropriate reference table or archive it with a documented reason.
6. Preserve the uploaded original file in app storage with filename, checksum, upload date, uploader, and import status.

## Workbook-to-application module mapping

Group all workbook information into the following application modules.

### 1. Home and weekly command

Workbook sources:

- START HERE
- Founder Dashboard
- Weekly Command Center
- 24-Week Operating Plan
- Weekly Review
- Growth Gates

Application features:

- A calm, uncluttered home screen showing only what the founder needs today and this week.
- Current operating week, automatically calculated from the first funding Friday, with an owner-only manual override.
- Five primary cards: cash available, active paid subscribers and MRR, urgent tasks, content due, and field work due.
- A “This Week” page with one main objective, up to seven required outcomes, cash decision, product priority, user priority, field sprint, content plan, and weekly review.
- Friday funding workflow and Sunday review workflow.
- Rule-based alerts, not vague AI advice.
- Quick actions: Log money, Log subscription numbers, Add task, Plan field trip, Add content, and Add road record.

### 2. Finance and runway

Workbook sources:

- Assumptions
- Cash & Runway
- Money Log
- Fuel & Field Ops financial fields
- Revenue & Subscriptions cash fields

Application features:

- Editable settings for funding, exchange rate, fuel, efficiency, cash floor, reserve, budget caps, subscription price, and growth gates.
- Transaction ledger supporting income, expense, refund in, refund out, and reserve transfer.
- Categories, payment method, receipt/reference, linked business record, cleared status, notes, creator, and audit history.
- Planned versus actual cash by operating week.
- Recurring expenses, beginning with Replit at US$20 per month. Let the founder set the next real charge date. Planned KES cost equals USD amount multiplied by the editable planning exchange rate; the actual transaction overrides the estimate.
- Operating cash and reserve tracked separately.
- A spending request and approval model for future team members.
- Budget warnings and hard UI guardrails, while the owner retains final authority.
- Reconciliation view showing planned amount, actual amount, variance, missing receipt, and uncleared transaction.
- CSV/XLSX export.

### 3. Users, subscriptions, and revenue

Workbook sources:

- Revenue & Subscriptions
- User Research CRM
- Revenue Experiments

Application features:

- Weekly metrics for downloads, trials, new paid, renewals, cancellations, active paid, gross sales, store or processor fees, refunds, net accrued revenue, cash received, and notes.
- Derived MRR, trial-to-paid conversion, download-to-paid conversion, gross ARPPU, churn, and cumulative values.
- Baseline metrics as of the first funding date.
- Manual data entry and CSV import in the first release.
- Import adapters designed for future RevenueCat, Google Play, Apple, analytics, or internal API integration, but do not enable them without configuration.
- Paying-user and cancellation interview CRM with consent, follow-up dates, reason to pay or not pay, cancellation risk, quotes, and feature requests.
- A simple funnel view and trend charts.

### 4. Product, tasks, and operating plan

Workbook sources:

- Product Backlog
- Business Foundation
- 24-Week Operating Plan
- SOP Library

Application features:

- Unified task system with list, kanban, calendar, and “My Work” views.
- Task fields: title, description, module, priority, type, status, owner, assignee, due date, operating week, estimated effort, actual effort, acceptance criteria, source, dependency, attachment, comments, and audit history.
- Product backlog scoring and sorting.
- Milestones and weekly stage objectives.
- Recurring tasks generated from SOPs.
- SOP pages with purpose, steps, acceptance criteria, frequency, estimated time, owner, handoff readiness, last review, and next review.
- Do not create a separate task for every workbook formula or reference row.

### 5. Field operations and road data

Workbook sources:

- Fuel & Field Ops
- Road Data Ops
- relevant Safety & Compliance rules

Application features:

- Plan a field trip with date, purpose, corridor, planned kilometres, odometer readings, parking/tolls, required outputs, assigned person, and status.
- Automatically calculate total kilometres, estimated litres, estimated fuel cost, and total trip cost.
- Link each trip to content assets, camera/speed-limit leads, verified road records, evidence files, and learnings.
- Road-record fields must include record ID, date, county, corridor, landmark, direction, data type, coordinates, speed limit where relevant, source type, confidence, evidence, verifier, last verified date, next action, status, and field trip.
- Confidence levels: A — Confirmed, B — Strong, C — Community, D — Unverified.
- No record may become “Confirmed” without evidence and an authorized verifier.
- Keep historical verification events rather than overwriting the prior state.
- Provide map-ready coordinates and filters, but do not depend on Google Maps data extraction or scraping.
- Add an optional mobile-friendly offline draft mode later; do not make it a Phase 1 blocker.

### 6. Content Studio

Workbook sources:

- Content Guide
- Content Dashboard
- Phase 1 Calendar
- Weekly Themes
- Audience Map
- Feature Story Map
- Content Idea Bank
- Series Playbook
- Hook Bank
- CTA Bank
- Script Templates
- Shot Bank
- Production Tracker
- Content Experiments
- Content Metrics
- KPI Decision Rules
- Campaign Moments
- Safety & Compliance

Application features:

- Content calendar with day, week, month, list, and production-board views.
- Import all planned calendar content and preserve its rich fields: theme, campaign, pillar, series, feature, audience, funnel stage, format, platforms, angle, hook, shot list, caption seed, CTA, asset needs, owner, status, script status, link, performance metrics, solo priority, production mode, minutes, cost, trip ID, paid subscribers attributed, revenue attributed, and notes.
- Content idea library with search and filters by pillar, feature, series, audience, funnel, format, difficulty, score, compliance note, and repurpose opportunity.
- Reusable hooks, CTAs, scripts, shots, audiences, features, series, weekly themes, and campaign moments.
- A four-core-post weekly capacity guardrail. Optional ideas should stay optional.
- Production flow: Idea → Selected → Brief → Script → Film → Edit → Review → Schedule → Posted → Measured → Repurpose or Archive.
- Automatically create the minimum production tasks and calendar reminders when content is scheduled.
- Performance metrics: views, shares, comments, clicks, installs, paid subscribers, attributed net revenue, cost, founder minutes, and calculated efficiency measures.
- Prominent compliance warnings for speed-camera, enforcement, alcohol, accident, dashcam, insurance, road-hazard, interview, privacy, and user-generated-content topics.

### 7. Growth, ads, creators, partnerships, and revenue tests

Workbook sources:

- Growth Experiments
- Ads Testing
- Micro-Influencer Tracker
- Partnership CRM
- Revenue Experiments
- Competitor Watch
- Growth Gates

Application features:

- Experiment cards with hypothesis, audience, channel, variable, start/end, owner, budget, success metric, result, learning, and decision.
- Ads tracker with spend, impressions, clicks, installs, activations, paid users, revenue, CTR, CPC, CPI, activation rate, CAC, ROAS/payback, and stop/continue/scale decision.
- Creator tracker with deliverable, fee, referral code/link, post date, views, clicks, installs, activations, paid users, revenue, cost per install, cost per paid user, payback, quality, status, and next action.
- Partnership pipeline with organization, type, contact, value exchange, offer, stage, next step, follow-up, outcome, and notes.
- Revenue experiment pipeline.
- Competitor signal log with threat level, response due date, and learning.
- Growth-spend controls: ads and creator payments should show as locked until the relevant gate passes or the owner explicitly overrides with a recorded reason.

### 8. Team and permissions

Build for one founder now and a future team later.

Roles:

- Owner/Founder: full access, configuration, integrations, exports, deletion, approvals, and member management.
- Admin/Operations: manage most operational records but not ownership, billing credentials, or irreversible financial deletion.
- Finance: transactions, budgets, revenue, receipts, reconciliations, and finance reports.
- Content: content planning, production, assets, metrics, and comments; no private finance access unless explicitly granted.
- Road Data Verifier: field trips, evidence, road records, and verification; no private finance access.
- Product/Developer: product backlog, incidents, tasks, and technical SOPs.
- Viewer/Advisor: read-only access to explicitly shared modules.

Features:

- Owner-controlled invitations; no open public registration.
- Membership status, role, module-level permissions, deactivation, and last active date.
- Task assignment, comments, mentions, attachments, due dates, workload view, and activity feed.
- Every create, update, delete, approval, verification, import, export, and permission change must be auditable.
- Use soft deletion for business records. Permanent deletion should be rare, owner-only, and logged.

### 9. Compliance, risk, hiring, and office gates

Workbook sources:

- Compliance & Admin
- Risk Register
- Hiring & Office Gates
- Safety & Compliance
- Sources

Application features:

- Compliance checklist with due date, fee reference, owner, source, status, payment state, document, next action, and notes.
- Risk register with likelihood, impact, score, warning signal, mitigation, owner, status, and review date.
- Hiring and office decision gates with current decision, trigger, evidence, review cadence, and recorded decision history.
- Source library containing the workbook’s source name, URL, use, source type, checked date, and notes.
- Never silently treat an old fee or legal reference as current; show the checked date and a “verify before action” label.

### 10. Reports, imports, exports, and backups

Application features:

- Founder dashboard and weekly review report.
- Cash and runway report.
- Subscription and revenue report.
- Content performance report.
- Field cost and verification report.
- Task and team workload report.
- Growth experiment report.
- Export filtered data to CSV and complete backups to XLSX or JSON.
- Import history with preview, errors, warnings, counts, row-level source, rollback, and idempotent re-import.
- A manual backup action plus a scheduled database/export backup workflow.
- Never overwrite a good import without a recoverable import batch or rollback plan.

## Proposed core database entities

Create normalized tables or equivalent models for at least:

- organizations
- users
- memberships
- roles and permissions
- settings and assumptions
- audit_logs
- files and attachments
- import_batches, import_sheets, and import_rows
- operating_weeks
- weekly_plans and weekly_reviews
- tasks, task_comments, task_dependencies, and task_assignments
- transaction_categories, transactions, recurring_expenses, budget_lines, and reserves
- subscription_weekly_metrics and payout/reconciliation records
- research_contacts and research_interactions
- product_backlog_items
- field_trips
- road_records and road_verification_events
- content_items
- content_ideas
- content_series
- content_hooks
- content_ctas
- script_templates
- shot_library
- content_metrics
- content_experiments
- weekly_themes
- campaign_moments
- safety_rules
- growth_experiments
- ad_tests
- creator_tests
- partnerships and partnership_interactions
- revenue_experiments
- competitor_signals
- compliance_items
- risks
- sops
- hiring_office_gates and decision_history
- reference_sources
- calendar_connections
- calendar_events
- reminders and notifications

Every business table should include suitable identifiers, organization ID, created/updated timestamps, created/updated by, archive or soft-delete state, and import lineage where applicable.

## Required calculation and formula engine

Create pure, documented, unit-tested calculation functions. Derived values must not be manually editable unless an owner records an override and reason.

### Time and operating week

- `weekNumber = floor((recordDate - firstFundingFriday) / 7 days) + 1`
- Clamp workbook-era operating weeks to 1–24 for imported plans, while allowing future weeks in the application.
- Calculate the current operating week automatically using Africa/Nairobi.

### Fuel and field operations

- `fuelCostPerKm = fuelPricePerLitre / vehicleEfficiencyKmPerLitre`
- `tripKm = max(0, endOdometer - startOdometer)` when odometers are supplied; otherwise use entered distance.
- `estimatedLitres = tripKm / efficiency`
- `estimatedFuelCost = estimatedLitres × fuelPrice`
- `totalTripCost = actualFuelSpend if entered, otherwise estimatedFuelCost, plus parking, tolls, and approved contingencies`

### Subscription and revenue metrics

- `activePaidEnd = max(0, priorActivePaid + newPaid - cancellations)`
- For the first week use the baseline active paid value as prior active paid.
- `netAccruedRevenue = grossSales - processorFees - refunds`
- `MRR = activePaidEnd × currentMonthlySubscriptionPrice`, with an explicit baseline override only when needed.
- `trialToPaid = newPaid / trialsStarted`, guarded against zero.
- `downloadToPaid = newPaid / newDownloads`, guarded against zero.
- `grossARPPU = grossSales / (newPaid + renewals)`, guarded against zero.
- `churn = cancellations / priorActivePaid`, guarded against zero.
- Cash received and accrued revenue are separate and must not be confused.

### Cash and runway

- Weekly planned inflows include founder funding and conservative planned subscription cash.
- Replit is a recurring monthly cost, not an every-four-weeks approximation in the long-term application. Preserve imported workbook plan values, but use actual billing dates for future projections.
- `totalPlannedSpend = sum(planned expense categories)`
- `reserveTransfer = max(0, min(reserveTransferTarget, availableCashAfterSpend - minimumOperatingCashFloor))`
- `plannedEndingOperatingCash = priorOperatingCash + plannedInflows - plannedSpend - plannedReserveTransfer`
- `actualEndingOperatingCash = priorActualOperatingCash + actualIncomeAndRefundIn - actualExpensesAndRefundOut - actualReserveTransfers`
- `actualReserve = priorReserve + reserveTransfers`
- `variance = actualEndingOperatingCash - plannedEndingOperatingCash`
- Do not count a transaction until its type and clearing logic are valid.

### Scoring and performance rules

- Risk score: Low = 1, Medium = 2, High = 3; score equals likelihood × impact.
- Product backlog score: impact / effort, guarded against zero.
- Content priority score from the workbook: hook strength + usefulness + conversion fit + seasonal fit - production effort.
- Ad and creator metrics: CTR, CPC, CPI, activation rate, cost per paid user, revenue-to-spend, and payback, all guarded against division by zero.
- Revenue experiment conversion: paying / prospects, plus price × paying for calculated revenue where appropriate.
- Dashboards should aggregate from source records, not copy stale summary values.

## Exact baseline calculation tests

Create automated tests proving that the imported default assumptions produce these values:

- Replit planning cost: `20 × 129.36 = KES 2,587.20`.
- Fuel cost per kilometre: `214 ÷ 12 = KES 17.833333...`, displayed as KES 17.83 where appropriate.
- A 120 km planned field trip uses 10 litres and has estimated fuel cost of KES 2,140.
- Adding KES 360 field contingency gives a KES 2,500 field budget.
- Protected first-week spend equals Replit 2,587.20 + field 2,500 + product/data 750 + content 750 + admin 400 = KES 6,987.20.
- With KES 10,000 funding, a KES 2,500 cash floor, and KES 1,500 reserve target, the permitted reserve transfer is KES 512.80 and ending operating cash is KES 2,500.

Also test:

- Previous active paid 10 + new paid 3 - cancellations 1 = 12 active paid.
- Gross sales 3,000 - fees 450 - refunds 100 = KES 2,450 net accrued revenue.
- Re-importing the same workbook does not create duplicates.
- Editing a synced task changes the existing calendar event rather than creating a duplicate.
- A Content-role user cannot view restricted finance records.
- A Road Data Verifier cannot confirm a road record without evidence.
- Ads and creator spend show a blocking warning when cash or readiness gates are not met.

## Google Calendar and reminder integration

Implement one-way application-to-Google-Calendar sync first. Do not attempt full two-way sync in the MVP.

Use Replit’s Google Workspace connector for Google Calendar when available. If it is not available on the current plan, use a standard Google OAuth 2.0 implementation and the least-privilege Calendar scope required to create, update, and delete the user’s events.

Requirements:

- The platform remains fully usable if Google Calendar is disconnected.
- Store the external calendar ID and event ID on the local record.
- Use stable event identifiers or idempotency logic to prevent duplicate events.
- Create, update, and delete the matching Google event when the local scheduled record changes.
- Display sync status, last synced time, errors, and a retry action.
- Do not delete a user’s unrelated calendar events.
- Only add teammates as attendees when the organizer requests it and the teammate has opted in.

Calendar-enabled record types:

- Friday funding and cash review
- Sunday weekly review
- Replit and other recurring payments
- task due dates
- field trips
- content filming, editing, review, scheduling, and publication
- user interview follow-ups
- partnership follow-ups
- compliance deadlines
- SOP reviews
- campaign moments
- experiment start and end dates

Default reminders, all editable:

- Payments: five days and one day before.
- Field trips: one day and one hour before.
- Content publication: one day and two hours before.
- Tasks: one day before.
- Weekly review: two hours before.

Use scheduled jobs to process reminders, weekly digests, failed calendar sync retries, recurring-task creation, and backups. All scheduled jobs must use Africa/Nairobi, be idempotent, log success/failure, and avoid sending duplicate reminders.

## Simple founder experience

The founder found the full workbook overwhelming. The application must solve that problem rather than reproduce it.

Default navigation:

1. Home
2. This Week
3. Money
4. Users & Revenue
5. Tasks
6. Content
7. Field & Road Data
8. More

The “More” section contains growth, creators, ads, partnerships, experiments, compliance, risks, SOPs, team, sources, imports, reports, and settings.

Home must show:

- one sentence describing the current business priority;
- money currently available, reserve, and next mandatory payment;
- active paid subscribers, MRR, and latest cash received;
- today’s and this week’s tasks;
- next content item;
- next field trip;
- overdue items;
- no more than three rule-based recommendations.

Use progressive disclosure, sensible defaults, clean empty states, and plain language. Every metric should have a tooltip explaining where it comes from. Derived values should be visually distinct from inputs.

The design must be responsive and practical on a phone because field records, receipts, and quick updates may be entered away from a desk.

## Setup wizard after first login

After the owner logs in for the first time:

1. Upload or confirm the attached workbook.
2. Show the workbook mapping and import preview.
3. Ask for current baseline downloads.
4. Ask for current active paid subscribers.
5. Ask for current subscription price and current MRR if known.
6. Ask for opening operating cash and reserve.
7. Confirm weekly founder funding and first funding date.
8. Confirm fuel price and vehicle efficiency.
9. Ask for the next real Replit billing date and the current planning exchange rate.
10. Offer Google Calendar connection.
11. Import the workbook and show a reconciliation report.
12. Open the “This Week” page with the current operating week already selected.

Do not force the founder to complete every optional field before using the application.

## Import behavior and data preservation

- Use a dry-run import preview before committing.
- Detect header rows rather than assuming every sheet begins at row 1.
- Read displayed values, formulas, data types, dates, dropdown values, hyperlinks, and source URLs.
- Preserve formulas in the raw import archive for traceability, while calculating live values through application rules.
- Seed application enums from the `Lists` sheet but allow owner-managed values later.
- Preserve rich text as plain text if exact rich formatting is not supported.
- Import source URLs into the source library.
- Import content bank records, calendar rows, hooks, CTAs, scripts, themes, audiences, safety rules, and operating records rather than summarizing them away.
- Use stable workbook IDs such as transaction, task, content, road, creator, partner, risk, SOP, or experiment IDs for upsert matching where present.
- For rows without stable IDs, derive a deterministic import key from sheet name and source row plus a content hash.
- On repeat import, show created, updated, unchanged, skipped, and conflict counts.
- Allow the owner to resolve conflicts and roll back an import batch.
- Never delete newer application data merely because an imported workbook cell is blank.

## Authentication, security, and privacy

- The application is private and internal.
- No open public sign-up.
- Bootstrap the first owner securely.
- Validate authentication and permissions server-side on every sensitive endpoint.
- Store secrets only in platform secrets/environment variables.
- Restrict file types and sizes; scan or reject unsafe uploads where supported.
- Protect against unauthorized object access, injection, cross-site scripting, request forgery where applicable, and mass assignment.
- Use rate limits for authentication, imports, and calendar actions.
- Do not store raw passwords.
- Do not expose Google tokens to the client.
- Keep an audit log with before/after values for sensitive changes.
- Create privacy-aware defaults for user research and road evidence.
- Do not expose personal contacts, receipts, exact internal finances, or evidence files to roles that do not need them.

## Reliability and operational safeguards

- Use database transactions for imports, reconciliations, and multi-record updates.
- Add migration scripts and seed scripts.
- Add health checks and structured logging.
- Handle failed calendar syncs and scheduled jobs with retries and visible errors.
- Add a database backup/export procedure.
- Create `RUNBOOK.md` covering deployment, secrets, database migrations, backup, restore, calendar reconnection, failed imports, and owner recovery.
- Create `README.md` with local development, testing, deployment, and feature overview.
- Do not hardcode secret keys, user IDs, production URLs, or billing dates.

## Required UI states

Every important page must include:

- loading state;
- empty state;
- error state;
- permission-denied state;
- filters and search where appropriate;
- pagination or virtualization for large libraries;
- mobile layout;
- confirmation for destructive actions;
- undo or recovery where feasible;
- accessible labels and keyboard navigation.

## Acceptance criteria

The first production-ready release is accepted only when:

1. The owner can sign in and other people cannot self-register.
2. The attached workbook can be uploaded, previewed, imported, reconciled, and re-imported without duplication.
3. Every workbook sheet is accounted for in the inventory and mapping documentation.
4. The baseline formula tests pass exactly.
5. The founder can log the Friday KES 10,000 funding and immediately see updated cash and runway.
6. The founder can log Replit, fuel, product, content, and admin expenses with receipts and see planned-versus-actual variance.
7. The founder can enter weekly subscription metrics and see active paid, MRR, conversion, churn, accrued revenue, and cash received update automatically.
8. The founder can plan a trip and see fuel and total trip cost calculate automatically.
9. The founder can link a trip to road records and content.
10. The founder can manage the four weekly core content items without navigating the full idea library.
11. A task or content item can create a Google Calendar event and later update or delete that same event without duplication.
12. The owner can invite a team member, assign a role and task, and verify permission restrictions.
13. The application produces useful Friday and Sunday workflows and overdue reminders.
14. Financial, verification, permission, and import changes appear in the audit log.
15. The application is responsive and usable on both desktop and phone.
16. Automated tests pass and the critical Playwright flows are documented.
17. No changes are made to the live consumer application.

## Phased implementation plan

Do not attempt the entire product in one unreviewed coding pass.

### Phase 0 — Analysis and foundation

- Inspect the workbook.
- Produce workbook inventory, formula map, data model, architecture, and implementation plan.
- Configure project structure, database, migrations, authentication, owner bootstrap, storage, audit logging, and test framework.
- Create the import dry-run and raw archive.

### Phase 1 — Essential Founder Mode

Build and fully test:

- Home
- This Week
- Money
- Users & Revenue
- Tasks
- Content essentials
- Field & Fuel
- Settings
- Workbook import
- basic reports

This phase should reflect the simple daily-use tracker while being powered by a proper database and calculation engine.

### Phase 2 — Full operating system

Add:

- road verification history;
- product backlog;
- user research CRM;
- full content library and production system;
- growth experiments;
- ads and creator trackers;
- partnerships;
- revenue experiments;
- competitor watch;
- compliance;
- risks;
- SOPs;
- hiring and office gates;
- sources and advanced reports.

### Phase 3 — Calendar, reminders, and team

Add:

- Google Calendar connection;
- one-way event sync;
- scheduled reminders and digests;
- invitations, roles, permissions, assignments, comments, mentions, workload, and activity feed;
- backup jobs and retry monitoring.

### Phase 4 — Optional integrations and intelligence

Only after the core system is stable:

- app-store or RevenueCat adapters;
- app analytics integration;
- bank or M-PESA reconciliation adapters where legally and technically appropriate;
- offline field drafts;
- evidence-based founder summaries;
- anomaly detection and forecast suggestions.

Any AI-generated recommendation must cite the application records that caused it and must never make an irreversible decision automatically.

## Agent working behavior

- Begin by reading the attached workbook and this complete specification.
- Do not invent missing production credentials or consumer-app schemas.
- Make sensible technical decisions without repeatedly asking minor questions.
- When a truly blocking choice is unknown, implement a secure configurable default and document it.
- Keep a visible checklist in `docs/implementation-status.md`.
- After each phase, run migrations, type checks, linting, unit tests, integration tests, and the critical browser tests.
- Fix failures before claiming completion.
- Show me the completed pages and a concise import/calculation/test report.
- Never claim a feature is complete if it is mocked, hardcoded, disconnected, or untested.

## Start now

Start with **Phase 0 and Phase 1**. Create the workbook inventory and formula map first, then implement the database-backed Essential Founder Mode. Stop after Phase 1 is working and tested, and present:

1. the workbook mapping summary;
2. the database schema summary;
3. imported record counts and warnings by sheet;
4. formula test results;
5. security and permission status;
6. the exact steps I must take to connect Google Calendar in Phase 3;
7. a short demo checklist for me to verify the app without risking the live Msafiri consumer app.
