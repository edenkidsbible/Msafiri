import { useState, useEffect, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListTasks,
  useGetTaskStats,
  useUpdateTask,
  useReorderTasks,
  getListTasksQueryKey,
  getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import type { Task } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, Search, LayoutList, List, AlertCircle } from "lucide-react";
import { TaskForm } from "@/components/forms/TaskForm";
import { TaskStatusSelect } from "@/components/ui/status-select";
import type { TaskStatus } from "@/components/ui/status-select";
import { AssigneeSelect } from "@/components/ui/assignee-badge";
import {
  DndContext,
  DragOverlay,
  closestCorners,
  useDroppable,
  PointerSensor,
  useSensor,
  useSensors,
} from "@dnd-kit/core";
import type { DragStartEvent, DragEndEvent, DragOverEvent } from "@dnd-kit/core";
import {
  SortableContext,
  useSortable,
  verticalListSortingStrategy,
  arrayMove,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

const PRIORITY_DOT: Record<string, string> = {
  critical: "bg-destructive",
  high: "bg-primary",
  medium: "bg-amber-500",
  low: "bg-muted-foreground/50",
};

const MODULE_TABS = [
  { key: "", label: "All" },
  { key: "product", label: "Product" },
  { key: "compliance", label: "Compliance" },
  { key: "risk", label: "Risk" },
  { key: "growth", label: "Growth" },
  { key: "content", label: "Content" },
  { key: "partnership", label: "Partners" },
  { key: "finance", label: "Finance" },
];

const KANBAN_COLS = ["backlog", "todo", "in_progress", "done"];
const KANBAN_LABELS: Record<string, string> = {
  backlog: "Backlog",
  todo: "To Do",
  in_progress: "In Progress",
  done: "Done",
};

// --- Kanban DnD sub-components ---

function SortableTaskCard({
  task,
  onEdit,
  onStatusChange,
  onAssigneeChange,
  isUpdating,
  knownAssignees,
}: {
  task: Task;
  onEdit: (t: Task) => void;
  onStatusChange: (t: Task, s: TaskStatus) => void;
  onAssigneeChange: (t: Task, name: string | null) => void;
  isUpdating: boolean;
  knownAssignees: string[];
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
    cursor: isDragging ? "grabbing" : "grab",
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      {...attributes}
      {...listeners}
      className={`transition-colors touch-none select-none ${
        task.status === "done" ? "opacity-60" : "hover:border-primary/40"
      }`}
    >
      <CardContent className="p-3 space-y-2">
        <div className="flex items-start gap-2">
          <div
            className={`shrink-0 w-2 h-2 mt-1.5 rounded-full ${
              PRIORITY_DOT[task.priority] ?? PRIORITY_DOT.low
            }`}
          />
          <p
            className={`text-sm font-medium leading-snug flex-1 ${
              task.status === "done"
                ? "line-through text-muted-foreground"
                : ""
            }`}
            onPointerDown={(e) => e.stopPropagation()}
            onClick={(e) => {
              e.stopPropagation();
              onEdit(task);
            }}
            style={{ cursor: "pointer" }}
          >
            {task.title}
          </p>
        </div>
        <div
          className="flex items-center justify-between gap-2"
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
        >
          <TaskStatusSelect
            value={task.status as TaskStatus}
            onChange={(v) => onStatusChange(task, v)}
            disabled={isUpdating}
          />
          <span className="text-[10px] text-muted-foreground capitalize bg-secondary px-1.5 py-0.5 rounded">
            {task.module}
          </span>
        </div>
        {/* Assignee row */}
        <div
          onPointerDown={(e) => e.stopPropagation()}
          onClick={(e) => e.stopPropagation()}
          className="pt-0.5 border-t border-border/40"
        >
          <AssigneeSelect
            current={task.assignedTo}
            knownNames={knownAssignees}
            onSave={(name) => onAssigneeChange(task, name)}
            disabled={isUpdating}
          />
        </div>
      </CardContent>
    </Card>
  );
}

function TaskCardGhost({ task }: { task: Task }) {
  return (
    <Card className="shadow-xl border-primary/40 opacity-95 rotate-1">
      <CardContent className="p-3 space-y-2">
        <div className="flex items-start gap-2">
          <div
            className={`shrink-0 w-2 h-2 mt-1.5 rounded-full ${
              PRIORITY_DOT[task.priority] ?? PRIORITY_DOT.low
            }`}
          />
          <p className="text-sm font-medium leading-snug flex-1">{task.title}</p>
        </div>
        <span className="text-[10px] text-muted-foreground capitalize bg-secondary px-1.5 py-0.5 rounded">
          {task.module}
        </span>
      </CardContent>
    </Card>
  );
}

function DroppableColumn({
  col,
  label,
  tasks,
  onEdit,
  onStatusChange,
  onAssigneeChange,
  updatingIds,
  activeId,
  knownAssignees,
}: {
  col: string;
  label: string;
  tasks: Task[];
  onEdit: (t: Task) => void;
  onStatusChange: (t: Task, s: TaskStatus) => void;
  onAssigneeChange: (t: Task, name: string | null) => void;
  updatingIds: Set<number>;
  activeId: number | null;
  knownAssignees: string[];
}) {
  const { setNodeRef, isOver } = useDroppable({ id: col });
  const taskIds = tasks.map((t) => t.id);

  return (
    <div
      className={`flex-1 min-w-[260px] flex flex-col gap-2 p-3 rounded-lg border transition-colors ${
        isOver
          ? "bg-primary/10 border-primary/40 ring-2 ring-primary/30"
          : "bg-muted/30"
      }`}
    >
      <div className="flex items-center justify-between px-1 mb-1">
        <h3 className="font-semibold text-sm">{label}</h3>
        <Badge variant="secondary" className="px-1.5 min-w-6 justify-center text-xs">
          {tasks.length}
        </Badge>
      </div>
      <div ref={setNodeRef} className="flex-1 overflow-y-auto min-h-[80px]">
        <SortableContext items={taskIds} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {tasks.map((task) => (
              <SortableTaskCard
                key={task.id}
                task={task}
                onEdit={onEdit}
                onStatusChange={onStatusChange}
                onAssigneeChange={onAssigneeChange}
                isUpdating={updatingIds.has(task.id)}
                knownAssignees={knownAssignees}
              />
            ))}
          </div>
        </SortableContext>
        {tasks.length === 0 && activeId === null && (
          <div className="h-20 border-2 border-dashed border-muted rounded-lg flex items-center justify-center text-muted-foreground text-xs">
            Empty
          </div>
        )}
        {tasks.length === 0 && activeId !== null && (
          <div
            className={`h-20 border-2 border-dashed rounded-lg flex items-center justify-center text-xs transition-colors ${
              isOver
                ? "border-primary/60 text-primary"
                : "border-muted text-muted-foreground"
            }`}
          >
            Drop here
          </div>
        )}
      </div>
    </div>
  );
}

// --- Main Tasks page ---

export default function Tasks() {
  const qc = useQueryClient();
  const [view, setView] = useState<"list" | "kanban">("list");
  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | undefined>(undefined);
  const [filter, setFilter] = useState("");
  const [activeModule, setActiveModule] = useState("");
  const [updatingIds, setUpdatingIds] = useState<Set<number>>(new Set());
  const [activeDragId, setActiveDragId] = useState<number | null>(null);

  // Local column order state (maps status → ordered task id array)
  // This is used to drive the kanban UI and gets updated optimistically on drag.
  const [columnOrders, setColumnOrders] = useState<Record<string, number[]>>({});

  const { data: tasks, isLoading: loadingTasks } = useListTasks();
  const { data: stats } = useGetTaskStats();
  const updateTask = useUpdateTask();
  const reorderTasks = useReorderTasks();

  const allItems = tasks?.items ?? [];

  // Track whether a reorder mutation is in flight so we don't overwrite
  // the optimistic column order before the server confirms the new positions.
  const pendingReorderRef = useRef(false);
  const isDragging = activeDragId !== null;

  useEffect(() => {
    // Don't reset while dragging or while a reorder is being persisted.
    // Once the mutation settles it will clear pendingReorderRef and
    // invalidate the query, which triggers a fresh server-data sync.
    if (isDragging || pendingReorderRef.current) return;
    const orders: Record<string, number[]> = {};
    for (const col of KANBAN_COLS) {
      orders[col] = allItems
        .filter((t) => t.status === col)
        .sort((a, b) => (a.position ?? 0) - (b.position ?? 0))
        .map((t) => t.id);
    }
    setColumnOrders(orders);
  }, [allItems, isDragging]);

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 5 } })
  );

  const openCreate = () => {
    setEditingTask(undefined);
    setFormOpen(true);
  };
  const openEdit = (task: Task) => {
    setEditingTask(task);
    setFormOpen(true);
  };
  const handleClose = () => {
    setFormOpen(false);
    setEditingTask(undefined);
  };

  const handleStatusChange = (task: Task, newStatus: TaskStatus) => {
    if (task.status === newStatus) return;
    setUpdatingIds((s) => new Set(s).add(task.id));
    updateTask.mutate(
      { id: task.id, data: { status: newStatus } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListTasksQueryKey() });
          qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        },
        onSettled: () =>
          setUpdatingIds((s) => {
            const n = new Set(s);
            n.delete(task.id);
            return n;
          }),
      }
    );
  };

  const handleAssigneeChange = (task: Task, name: string | null) => {
    updateTask.mutate(
      { id: task.id, data: { assignedTo: name ?? "" } },
      { onSuccess: () => qc.invalidateQueries({ queryKey: getListTasksQueryKey() }) }
    );
  };

  // Which column owns a given task id (from the current columnOrders)
  const findColumn = (taskId: number): string | undefined => {
    for (const col of KANBAN_COLS) {
      if (columnOrders[col]?.includes(taskId)) return col;
    }
    return undefined;
  };

  const handleDragStart = (event: DragStartEvent) => {
    setActiveDragId(event.active.id as number);
  };

  const handleDragOver = (event: DragOverEvent) => {
    const { active, over } = event;
    if (!over) return;

    const activeId = active.id as number;
    const overId = over.id;

    const activeCol = findColumn(activeId);
    // over.id can be a column string or a task id number
    const overCol = KANBAN_COLS.includes(overId as string)
      ? (overId as string)
      : findColumn(overId as number);

    if (!activeCol || !overCol || activeCol === overCol) return;

    // Moving to a different column — update local order immediately for live feedback
    setColumnOrders((prev) => {
      const activeItems = prev[activeCol]?.filter((id) => id !== activeId) ?? [];
      const overItems = [...(prev[overCol] ?? [])];

      if (KANBAN_COLS.includes(overId as string)) {
        // Dropped onto the column itself → append
        overItems.push(activeId);
      } else {
        // Dropped onto a card in the target column → insert before it
        const overIndex = overItems.indexOf(overId as number);
        overItems.splice(overIndex >= 0 ? overIndex : overItems.length, 0, activeId);
      }

      return { ...prev, [activeCol]: activeItems, [overCol]: overItems };
    });
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveDragId(null);
    if (!over) return;

    const activeId = active.id as number;
    const overId = over.id;

    // Find which column the task ended up in (after onDragOver updates)
    const finalCol = KANBAN_COLS.includes(overId as string)
      ? (overId as string)
      : findColumn(overId as number);

    const activeTask = allItems.find((t) => t.id === activeId);
    if (!activeTask || !finalCol) return;

    const isCrossColumn = activeTask.status !== finalCol;

    if (isCrossColumn) {
      // Cross-column move: update status on server (server assigns position at end of column)
      const queryKey = getListTasksQueryKey();
      const previousData = qc.getQueryData(queryKey);

      qc.setQueryData(queryKey, (old: any) => {
        if (!old?.items) return old;
        return {
          ...old,
          items: old.items.map((t: Task) =>
            t.id === activeId ? { ...t, status: finalCol } : t
          ),
        };
      });

      setUpdatingIds((s) => new Set(s).add(activeId));
      updateTask.mutate(
        { id: activeId, data: { status: finalCol as TaskStatus } },
        {
          onSuccess: () => {
            qc.invalidateQueries({ queryKey: getListTasksQueryKey() });
            qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
          },
          onError: () => {
            qc.setQueryData(queryKey, previousData);
          },
          onSettled: () =>
            setUpdatingIds((s) => {
              const n = new Set(s);
              n.delete(activeId);
              return n;
            }),
        }
      );
    } else {
      // Within-column reorder
      const colIds = columnOrders[finalCol] ?? [];
      const oldIndex = colIds.indexOf(activeId);

      // Determine new index from the over target
      let newIndex: number;
      if (KANBAN_COLS.includes(overId as string)) {
        newIndex = colIds.length - 1;
      } else {
        newIndex = colIds.indexOf(overId as number);
      }

      if (oldIndex === -1 || oldIndex === newIndex) return;

      const reordered = arrayMove(colIds, oldIndex, newIndex);

      // Optimistic update of local order
      setColumnOrders((prev) => ({ ...prev, [finalCol]: reordered }));

      // Persist new positions to server.
      // Guard the optimistic order against the useEffect sync until the
      // mutation settles and fresh server data arrives.
      const reorderPayload = reordered.map((id, index) => ({ id, position: index }));
      pendingReorderRef.current = true;
      reorderTasks.mutate(
        { data: { items: reorderPayload } },
        {
          onSettled: () => {
            pendingReorderRef.current = false;
            qc.invalidateQueries({ queryKey: getListTasksQueryKey() });
          },
        }
      );
    }
  };

  if (loadingTasks) {
    return (
      <div className="p-8 space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const filtered = allItems.filter((t) => {
    if (activeModule && t.module !== activeModule) return false;
    if (filter && !t.title.toLowerCase().includes(filter.toLowerCase())) return false;
    return true;
  });

  // For the list view, sort by position within status group, then fall back to priority/date
  const filteredSorted = [...filtered].sort((a, b) => {
    if (a.status !== b.status) return 0; // don't reorder across statuses in list view
    return (a.position ?? 0) - (b.position ?? 0);
  });

  // For kanban view, derive per-column tasks from columnOrders (preserves drag order)
  const getColTasks = (col: string): Task[] => {
    const ids = columnOrders[col] ?? [];
    const taskMap = new Map(allItems.map((t) => [t.id, t]));
    return ids
      .map((id) => taskMap.get(id))
      .filter((t): t is Task => t !== undefined && filtered.includes(t));
  };

  const moduleCounts: Record<string, number> = {};
  allItems.forEach((t) => {
    moduleCounts[t.module] = (moduleCounts[t.module] || 0) + 1;
  });

  const knownAssignees = [
    ...new Set(
      allItems.map((t) => t.assignedTo).filter((n): n is string => !!n?.trim())
    ),
  ];

  return (
    <div className="space-y-6 animate-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Tasks</h1>
          <p className="text-muted-foreground mt-1">
            {allItems.length} tasks across {Object.keys(moduleCounts).length} modules
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center bg-muted rounded-md p-1 border">
            <button
              className={`p-1.5 rounded-sm transition-colors ${view === "list" ? "bg-background shadow-sm" : "text-muted-foreground"}`}
              onClick={() => setView("list")}
              title="List"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              className={`p-1.5 rounded-sm transition-colors ${view === "kanban" ? "bg-background shadow-sm" : "text-muted-foreground"}`}
              onClick={() => setView("kanban")}
              title="Kanban"
            >
              <LayoutList className="w-4 h-4" />
            </button>
          </div>
          <Button onClick={openCreate}>
            <PlusCircle className="w-4 h-4 mr-2" /> Add Task
          </Button>
        </div>
      </div>

      {/* Overdue alert */}
      {(stats?.totalOverdue ?? 0) > 0 && (
        <div className="bg-destructive/10 border border-destructive/20 text-destructive px-4 py-3 rounded-lg flex items-center gap-3">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span className="font-medium">
            {stats!.totalOverdue} overdue{" "}
            {stats!.totalOverdue === 1 ? "task" : "tasks"} — address before
            planning new work.
          </span>
        </div>
      )}

      {/* Module tabs + search */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="flex items-center gap-1 flex-wrap">
          {MODULE_TABS.map((tab) => (
            <button
              key={tab.key}
              onClick={() => setActiveModule(tab.key)}
              className={`px-3 py-1.5 rounded-md text-sm font-medium transition-colors ${
                activeModule === tab.key
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted/50 text-muted-foreground hover:bg-muted hover:text-foreground"
              }`}
            >
              {tab.label}
              {tab.key && moduleCounts[tab.key] ? (
                <span className="ml-1.5 text-xs opacity-70">
                  {moduleCounts[tab.key]}
                </span>
              ) : null}
            </button>
          ))}
        </div>
        <div className="relative sm:ml-auto">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search…"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="h-9 w-full sm:w-64 pl-9 pr-4 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </div>

      {/* List view */}
      {view === "list" ? (
        <div className="bg-card border rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b">
              <tr>
                <th className="text-left font-medium p-3 text-muted-foreground w-10" />
                <th className="text-left font-medium p-3 text-muted-foreground">Task</th>
                <th className="text-left font-medium p-3 text-muted-foreground w-36">Status</th>
                <th className="text-left font-medium p-3 text-muted-foreground w-32 hidden md:table-cell">Assignee</th>
                <th className="text-left font-medium p-3 text-muted-foreground w-28 hidden sm:table-cell">Module</th>
                <th className="text-right font-medium p-3 text-muted-foreground w-24 hidden md:table-cell">Due</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((task) => (
                <tr
                  key={task.id}
                  className="border-b last:border-0 hover:bg-muted/10"
                >
                  <td className="p-3">
                    <div
                      className={`w-2.5 h-2.5 rounded-full ${PRIORITY_DOT[task.priority] ?? PRIORITY_DOT.low}`}
                      title={task.priority}
                    />
                  </td>
                  <td className="p-3 cursor-pointer" onClick={() => openEdit(task)}>
                    <span
                      className={`font-medium ${
                        task.status === "done" || task.status === "cancelled"
                          ? "line-through text-muted-foreground"
                          : ""
                      }`}
                    >
                      {task.title}
                    </span>
                    {task.acceptanceCriteria && (
                      <p className="text-xs text-muted-foreground mt-0.5 break-words">
                        {task.acceptanceCriteria}
                      </p>
                    )}
                  </td>
                  <td className="p-3" onClick={(e) => e.stopPropagation()}>
                    <TaskStatusSelect
                      value={task.status as TaskStatus}
                      onChange={(v) => handleStatusChange(task, v)}
                      disabled={updatingIds.has(task.id)}
                    />
                  </td>
                  <td
                    className="p-3 hidden md:table-cell"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <AssigneeSelect
                      current={task.assignedTo}
                      knownNames={knownAssignees}
                      onSave={(name) => handleAssigneeChange(task, name)}
                    />
                  </td>
                  <td className="p-3 text-muted-foreground capitalize hidden sm:table-cell">
                    <span className="text-xs bg-secondary px-1.5 py-0.5 rounded">
                      {task.module}
                    </span>
                  </td>
                  <td className="p-3 text-right text-muted-foreground text-xs hidden md:table-cell">
                    {task.dueDate
                      ? new Date(task.dueDate).toLocaleDateString(undefined, {
                          month: "short",
                          day: "numeric",
                        })
                      : "—"}
                  </td>
                </tr>
              ))}
              {!filtered.length && (
                <tr>
                  <td
                    colSpan={6}
                    className="p-10 text-center text-muted-foreground"
                  >
                    {filter || activeModule
                      ? "No tasks match your filter."
                      : "No tasks yet — add one to get started."}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      ) : (
        /* Kanban view */
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
        >
          <div className="flex gap-4 overflow-x-auto pb-4 min-h-[480px]">
            {KANBAN_COLS.map((col) => (
              <DroppableColumn
                key={col}
                col={col}
                label={KANBAN_LABELS[col]}
                tasks={getColTasks(col)}
                onEdit={openEdit}
                onStatusChange={handleStatusChange}
                onAssigneeChange={handleAssigneeChange}
                updatingIds={updatingIds}
                activeId={activeDragId}
                knownAssignees={knownAssignees}
              />
            ))}
          </div>
          <DragOverlay>
            {activeDragId !== null &&
              (() => {
                const task = allItems.find((t) => t.id === activeDragId);
                return task ? <TaskCardGhost task={task} /> : null;
              })()}
          </DragOverlay>
        </DndContext>
      )}

      <TaskForm open={formOpen} onClose={handleClose} task={editingTask} />
    </div>
  );
}
