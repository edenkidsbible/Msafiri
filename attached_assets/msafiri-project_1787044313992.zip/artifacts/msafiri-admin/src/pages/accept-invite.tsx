import { useState, useEffect } from 'react';
import { useSearch, useLocation } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';

interface InviteInfo {
  email: string;
  role: string;
  departmentId: number | null;
}

type Status = 'loading' | 'ready' | 'invalid' | 'submitting' | 'done';

export default function AcceptInvite() {
  const search = useSearch();
  const token = new URLSearchParams(search).get('token') ?? '';
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();

  const [status, setStatus] = useState<Status>('loading');
  const [invite, setInvite] = useState<InviteInfo | null>(null);
  const [invalidMsg, setInvalidMsg] = useState('');

  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [formError, setFormError] = useState('');

  // Look up the invitation on mount
  useEffect(() => {
    if (!token) {
      setInvalidMsg('No invitation token found in the link.');
      setStatus('invalid');
      return;
    }
    fetch(`/api/auth/invite?token=${encodeURIComponent(token)}`, {
      credentials: 'include',
    })
      .then(async (res) => {
        if (!res.ok) {
          const d = await res.json().catch(() => ({}));
          setInvalidMsg(d.error ?? 'This invitation link is invalid or has expired.');
          setStatus('invalid');
          return;
        }
        const d: InviteInfo = await res.json();
        setInvite(d);
        setStatus('ready');
      })
      .catch(() => {
        setInvalidMsg('Network error — please try again.');
        setStatus('invalid');
      });
  }, [token]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setFormError('');

    if (!firstName.trim()) { setFormError('First name is required'); return; }
    if (password.length < 8) { setFormError('Password must be at least 8 characters'); return; }
    if (password !== confirm) { setFormError('Passwords do not match'); return; }

    setStatus('submitting');
    try {
      const res = await fetch('/api/auth/accept-invite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ token, firstName, lastName, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setFormError(data.error ?? 'Something went wrong');
        setStatus('ready');
        return;
      }
      await queryClient.invalidateQueries({ queryKey: ['getCurrentAuthUser'] });
      setStatus('done');
      navigate('/');
    } catch {
      setFormError('Network error — please try again');
      setStatus('ready');
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
      {/* Kenyan flag stripe */}
      <div className="fixed top-0 inset-x-0 h-1 flex">
        <div className="flex-1 bg-[#006600]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#CE1126]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#006600]" />
      </div>

      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center gap-3 mb-2">
          <img
            src="/logo.png"
            alt="Msafiri"
            className="w-16 h-16 rounded-2xl object-contain bg-white shadow"
          />
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight">Join Msafiri</h1>
            <p className="text-sm text-muted-foreground mt-1">Create your account to get started</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl shadow-sm p-6">
          {/* Loading */}
          {status === 'loading' && (
            <p className="text-sm text-muted-foreground text-center py-4 animate-pulse">
              Verifying invitation…
            </p>
          )}

          {/* Invalid */}
          {status === 'invalid' && (
            <div className="space-y-4 text-center">
              <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-3">
                {invalidMsg}
              </p>
              <p className="text-xs text-muted-foreground">
                Ask your admin to resend the invitation.
              </p>
            </div>
          )}

          {/* Form */}
          {(status === 'ready' || status === 'submitting') && invite && (
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Invited-as badge */}
              <div className="rounded-lg bg-muted px-3 py-2.5 text-sm">
                <span className="text-muted-foreground">Invited as </span>
                <span className="font-medium">{invite.email}</span>
                <span className="ml-2 text-xs bg-primary/10 text-primary rounded-full px-2 py-0.5 capitalize">
                  {invite.role}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-sm font-medium" htmlFor="firstName">
                    First name <span className="text-destructive">*</span>
                  </label>
                  <input
                    id="firstName"
                    type="text"
                    autoComplete="given-name"
                    required
                    value={firstName}
                    onChange={(e) => setFirstName(e.target.value)}
                    placeholder="Amina"
                    className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-sm font-medium" htmlFor="lastName">
                    Last name
                  </label>
                  <input
                    id="lastName"
                    type="text"
                    autoComplete="family-name"
                    value={lastName}
                    onChange={(e) => setLastName(e.target.value)}
                    placeholder="Mwangi"
                    className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium" htmlFor="password">
                  Password <span className="text-destructive">*</span>
                </label>
                <input
                  id="password"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="At least 8 characters"
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-sm font-medium" htmlFor="confirm">
                  Confirm password <span className="text-destructive">*</span>
                </label>
                <input
                  id="confirm"
                  type="password"
                  autoComplete="new-password"
                  required
                  value={confirm}
                  onChange={(e) => setConfirm(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                />
              </div>

              {formError && (
                <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">
                  {formError}
                </p>
              )}

              <button
                type="submit"
                disabled={status === 'submitting'}
                className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold hover:bg-primary/90 active:scale-[0.98] transition disabled:opacity-60"
              >
                {status === 'submitting' ? 'Creating account…' : 'Create account'}
              </button>
            </form>
          )}

          {/* Done */}
          {status === 'done' && (
            <p className="text-sm text-center text-muted-foreground py-4 animate-pulse">
              Account created — taking you in…
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
