import { useState, useEffect, useRef, useCallback } from "react";
import { useLocation, useSearch, useParams } from "wouter";
import { useGetCurrentAuthUser } from "@workspace/api-client-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { formatDistanceToNow } from "date-fns";
import { Send, Hash, MessageCircle, Users, ChevronLeft, MessageSquare, Plus, X, Search } from "lucide-react";
import { cn } from "@/lib/utils";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useChatSocket } from "@/hooks/use-chat-socket";

const BASE = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, "") ?? "";

// ─── Types ─────────────────────────────────────────────────────────────────────

interface ConversationItem {
  id: number;
  type: "all_team" | "department" | "direct";
  name: string | null;
  departmentId: number | null;
  departmentName: string | null;
  unreadCount: number;
  lastMessage: {
    id: number;
    body: string;
    createdAt: string;
    senderFirst: string | null;
    senderLast: string | null;
  } | null;
  otherUser: {
    id: string;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
    lastSeenAt: string | null;
  } | null;
}

interface MessageItem {
  id: number;
  conversationId: number;
  body: string;
  createdAt: string | Date;
  senderId: string;
  senderFirstName: string | null;
  senderLastName: string | null;
  senderProfileImageUrl: string | null;
}

interface ConversationMember {
  id: string;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  role: string;
  lastSeenAt: string | null;
  isOnline: boolean;
}

// ─── Helpers ───────────────────────────────────────────────────────────────────

function initials(first?: string | null, last?: string | null) {
  return [(first ?? "")[0], (last ?? "")[0]].filter(Boolean).join("").toUpperCase() || "?";
}



function isOnline(lastSeenAt: string | null | undefined): boolean {
  if (!lastSeenAt) return false;
  return Date.now() - new Date(lastSeenAt).getTime() < 5 * 60 * 1000;
}

function convLabel(conv: ConversationItem, myId: string): string {
  if (conv.type === "all_team") return "All Team";
  if (conv.type === "department") return conv.departmentName ?? conv.name ?? "Department";
  if (conv.type === "direct" && conv.otherUser) {
    return displayName(conv.otherUser.firstName, conv.otherUser.lastName, conv.otherUser.id);
  }
  return "Direct Message";
}

// ─── API helpers ───────────────────────────────────────────────────────────────

async function apiFetch(path: string, opts?: RequestInit) {
  const res = await fetch(`${BASE}/api${path}`, { credentials: "include", ...opts });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

// ─── Main Component ────────────────────────────────────────────────────────────

export default function ChatPage() {
  const { data: auth } = useGetCurrentAuthUser();
  const queryClient = useQueryClient();
  const myId = auth?.id ?? "";
  const [, setLocation] = useLocation();
  const search = useSearch();
  const params = useParams<{ conversationId?: string }>();

  // Derive activeId from the URL — this makes the conversation deep-linkable
  // and persists it across page refreshes.
  const activeId = params.conversationId ? parseInt(params.conversationId, 10) || null : null;

  const [showMemberPanel, setShowMemberPanel] = useState(false);
  const [showConvList, setShowConvList] = useState(!params.conversationId); // for mobile
  const [showPeoplePicker, setShowPeoplePicker] = useState(false);
  const [peopleSearch, setPeopleSearch] = useState("");
  const [startingDm, setStartingDm] = useState(false);
  const messageEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const pickerInputRef = useRef<HTMLInputElement>(null);

  // Conversations list
  const { data: conversations, isLoading: loadingConvs } = useQuery<ConversationItem[]>({
    queryKey: ["chat", "conversations"],
    queryFn: () => apiFetch("/chat/conversations"),
    refetchInterval: 30_000,
    enabled: !!myId,
  });

  // Messages for active conversation
  const { data: messages, isLoading: loadingMessages } = useQuery<MessageItem[]>({
    queryKey: ["chat", "messages", activeId],
    queryFn: () => apiFetch(`/chat/conversations/${activeId}/messages`),
    enabled: activeId != null,
    staleTime: 0,
  });

  // Team members for the people picker
  interface TeamMember {
    userId: string;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
    role: string | null;
  }
  const { data: teamMembers } = useQuery<TeamMember[]>({
    queryKey: ["team", "members"],
    queryFn: () => apiFetch("/team/members"),
    enabled: showPeoplePicker,
    staleTime: 60_000,
  });

  // Members of active conversation
  const { data: convMembers } = useQuery<ConversationMember[]>({
    queryKey: ["chat", "members", activeId],
    queryFn: () => apiFetch(`/chat/conversations/${activeId}/members`),
    enabled: activeId != null && showMemberPanel,
    refetchInterval: 30_000,
  });

  // WebSocket
  useChatSocket({ enabled: !!myId, activeConversationId: activeId });

  // Auto-scroll to bottom when messages load or new messages arrive
  useEffect(() => {
    messageEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Auto-select conversation from ?dm= URL param (set by Team page "Message" button)
  useEffect(() => {
    if (!conversations) return;
    const searchParams = new URLSearchParams(search);
    const dmId = searchParams.get("dm");
    if (!dmId) return;
    const convId = parseInt(dmId);
    if (!isNaN(convId)) {
      setShowConvList(false);
      // Navigate to the conversation URL (replaces the ?dm= param)
      setLocation(`/chat/${convId}`, { replace: true });
    }
  }, [search, conversations, setLocation]);

  // Mark as read when opening a conversation
  useEffect(() => {
    if (!activeId || !myId) return;
    apiFetch(`/chat/conversations/${activeId}/read`, { method: "POST" }).then(() => {
      queryClient.invalidateQueries({ queryKey: ["chat", "conversations"] });
      queryClient.invalidateQueries({ queryKey: ["chat", "unread"] });
    }).catch(() => {});
  }, [activeId, myId, queryClient]);

  const activeConv = conversations?.find((c) => c.id === activeId) ?? null;

  const handleSelectConv = (id: number) => {
    setShowConvList(false); // mobile: go to message view
    setLocation(`/chat/${id}`);
  };

  // Start a DM (shared by right-panel and people picker)
  const startPanelDm = useCallback(async (targetUserId: string) => {
    try {
      const data = await apiFetch("/chat/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participantUserId: targetUserId }),
      });
      // Refresh conversation list then select the new/existing DM
      await queryClient.invalidateQueries({ queryKey: ["chat", "conversations"] });
      setShowConvList(false);
      setLocation(`/chat/${data.id}`);
    } catch {
      // silently ignore — user stays in current conv
    }
  }, [queryClient, setLocation]);

  // Start a DM from the people picker
  const startPickerDm = useCallback(async (targetUserId: string) => {
    if (startingDm) return;
    setStartingDm(true);
    try {
      const data = await apiFetch("/chat/conversations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participantUserId: targetUserId }),
      });
      await queryClient.invalidateQueries({ queryKey: ["chat", "conversations"] });
      setShowConvList(false);
      setShowPeoplePicker(false);
      setPeopleSearch("");
      setLocation(`/chat/${data.id}`);
    } catch {
      // silently ignore
    } finally {
      setStartingDm(false);
    }
  }, [queryClient, startingDm, setLocation]);

  // Send message
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);

  const sendMessage = useCallback(async () => {
    if (!draft.trim() || !activeId || sending) return;
    setSending(true);
    const body = draft.trim();
    setDraft("");
    try {
      const msg = await apiFetch(`/chat/conversations/${activeId}/messages`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ body }),
      });
      // Optimistic: WS will also push it, but add immediately for snappy UX
      queryClient.setQueryData(["chat", "messages", activeId], (old: MessageItem[] | undefined) =>
        old ? [...old, msg] : [msg],
      );
      queryClient.invalidateQueries({ queryKey: ["chat", "conversations"] });
    } catch {
      setDraft(body); // restore on error
    } finally {
      setSending(false);
      textareaRef.current?.focus();
    }
  }, [draft, activeId, sending, queryClient]);

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  // ─── Render ─────────────────────────────────────────────────────────────────

  return (
    <div className="flex h-[calc(100vh-8rem)] md:h-[calc(100vh-4rem)] -m-4 md:-m-8 overflow-hidden">
      
      {/* ── Left panel: conversation list ──────────────────────────────────── */}
      <div className={cn(
        "w-full md:w-72 lg:w-80 border-r bg-muted/30 flex flex-col",
        !showConvList && "hidden md:flex",
      )}>
        <div className="p-4 border-b">
          <h2 className="font-semibold text-lg">Messages</h2>
        </div>

        <ScrollArea className="flex-1">
          {loadingConvs ? (
            <div className="p-4 space-y-3">
              {[1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-14 w-full rounded-lg" />)}
            </div>
          ) : (
            <div className="p-2 space-y-0.5">
              {/* Section: group channels */}
              {(conversations?.filter((c) => c.type !== "direct").length ?? 0) > 0 && (
                <>
                  <p className="px-3 pt-3 pb-1 text-xs font-semibold text-muted-foreground uppercase tracking-wider">Channels</p>
                  {conversations!
                    .filter((c) => c.type !== "direct")
                    .map((conv) => (
                      <ConvRow key={conv.id} conv={conv} myId={myId} active={activeId === conv.id} onClick={() => handleSelectConv(conv.id)} />
                    ))}
                </>
              )}

              {/* Section: DMs — always rendered so the + button is always accessible */}
              <>
                <div className="flex items-center justify-between px-3 pt-4 pb-1">
                  <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Direct Messages</p>
                  <button
                    title="New direct message"
                    onClick={() => {
                      setShowPeoplePicker((v) => !v);
                      setPeopleSearch("");
                      if (!showPeoplePicker) {
                        setTimeout(() => pickerInputRef.current?.focus(), 50);
                      }
                    }}
                    className="p-0.5 rounded hover:bg-accent text-muted-foreground hover:text-foreground transition-colors"
                  >
                    {showPeoplePicker ? <X className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  </button>
                </div>

                {/* People picker */}
                {showPeoplePicker && (
                  <div className="mx-2 mb-2 rounded-lg border bg-card shadow-sm overflow-hidden">
                    <div className="flex items-center gap-2 px-3 py-2 border-b">
                      <Search className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                      <input
                        ref={pickerInputRef}
                        type="text"
                        placeholder="Search teammates…"
                        value={peopleSearch}
                        onChange={(e) => setPeopleSearch(e.target.value)}
                        className="flex-1 text-sm bg-transparent focus:outline-none placeholder:text-muted-foreground"
                      />
                      {peopleSearch && (
                        <button onClick={() => setPeopleSearch("")} className="text-muted-foreground hover:text-foreground">
                          <X className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                    <div className="max-h-48 overflow-y-auto">
                      {!teamMembers ? (
                        <div className="p-3 space-y-2">
                          {[1, 2, 3].map((i) => <Skeleton key={i} className="h-8 w-full" />)}
                        </div>
                      ) : (() => {
                        const q = peopleSearch.trim().toLowerCase();
                        const filtered = teamMembers.filter((m) => {
                          if (m.userId === myId) return false;
                          if (!q) return true;
                          const full = [m.firstName, m.lastName].filter(Boolean).join(" ").toLowerCase();
                          return full.includes(q);
                        });
                        if (filtered.length === 0) {
                          return (
                            <p className="p-3 text-xs text-center text-muted-foreground">No teammates found</p>
                          );
                        }
                        return filtered.map((m) => (
                          <button
                            key={m.userId}
                            disabled={startingDm}
                            onClick={() => startPickerDm(m.userId)}
                            className="w-full flex items-center gap-2 px-3 py-2 hover:bg-accent text-left transition-colors disabled:opacity-50"
                          >
                            <Avatar className="w-6 h-6 shrink-0">
                              <AvatarImage src={m.profileImageUrl ?? ""} />
                              <AvatarFallback className="text-[10px]">{initials(m.firstName, m.lastName)}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm truncate">{[m.firstName, m.lastName].filter(Boolean).join(" ") || "Unknown"}</span>
                          </button>
                        ));
                      })()}
                    </div>
                  </div>
                )}

                {(conversations?.filter((c) => c.type === "direct").length ?? 0) === 0 && !showPeoplePicker && (
                  <p className="px-3 py-2 text-xs text-muted-foreground">No direct messages yet</p>
                )}

                {conversations?.filter((c) => c.type === "direct").map((conv) => (
                  <ConvRow key={conv.id} conv={conv} myId={myId} active={activeId === conv.id} onClick={() => handleSelectConv(conv.id)} />
                ))}
              </>
            </div>
          )}
        </ScrollArea>
      </div>

      {/* ── Center panel: message thread ───────────────────────────────────── */}
      <div className={cn(
        "flex-1 flex flex-col min-w-0",
        showConvList && "hidden md:flex",
      )}>
        {!activeConv ? (
          <div className="flex-1 flex flex-col items-center justify-center text-muted-foreground gap-3">
            <MessageCircle className="w-12 h-12 opacity-20" />
            <p className="text-sm">Select a conversation to start messaging</p>
          </div>
        ) : (
          <>
            {/* Header */}
            <div className="flex items-center gap-3 px-4 py-3 border-b bg-card">
              <Button variant="ghost" size="icon" className="md:hidden" onClick={() => setShowConvList(true)}>
                <ChevronLeft className="w-4 h-4" />
              </Button>
              {activeConv.type === "direct" && activeConv.otherUser ? (
                <div className="relative">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={activeConv.otherUser.profileImageUrl ?? ""} />
                    <AvatarFallback className="text-xs">{initials(activeConv.otherUser.firstName, activeConv.otherUser.lastName)}</AvatarFallback>
                  </Avatar>
                  <span className={cn("absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-card", isOnline(activeConv.otherUser.lastSeenAt) ? "bg-green-500" : "bg-muted")} />
                </div>
              ) : (
                <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                  <Hash className="w-4 h-4 text-primary" />
                </div>
              )}
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-sm truncate">{convLabel(activeConv, myId)}</p>
                {activeConv.type === "direct" && activeConv.otherUser && (
                  <p className="text-xs text-muted-foreground">
                    {isOnline(activeConv.otherUser.lastSeenAt)
                      ? "Online"
                      : activeConv.otherUser.lastSeenAt
                        ? `Last seen ${formatDistanceToNow(new Date(activeConv.otherUser.lastSeenAt), { addSuffix: true })}`
                        : "Offline"}
                  </p>
                )}
              </div>
              <Button variant="ghost" size="icon" onClick={() => setShowMemberPanel((v) => !v)}>
                <Users className="w-4 h-4" />
              </Button>
            </div>

            {/* Messages */}
            <ScrollArea className="flex-1 px-4 py-4">
              {loadingMessages ? (
                <div className="space-y-4">
                  {[1, 2, 3].map((i) => <Skeleton key={i} className="h-12 w-3/4" />)}
                </div>
              ) : !messages?.length ? (
                <div className="flex flex-col items-center justify-center h-full gap-2 text-muted-foreground">
                  <MessageCircle className="w-8 h-8 opacity-20" />
                  <p className="text-sm">No messages yet. Say hello!</p>
                </div>
              ) : (
                <div className="space-y-1">
                  {messages.map((msg, i) => {
                    const prev = messages[i - 1];
                    const isMe = msg.senderId === myId;
                    const sameSender = prev?.senderId === msg.senderId;
                    const dt = new Date(msg.createdAt);
                    return (
                      <MessageBubble key={msg.id} msg={msg} isMe={isMe} sameSender={sameSender} dt={dt} />
                    );
                  })}
                  <div ref={messageEndRef} />
                </div>
              )}
            </ScrollArea>

            {/* Composer */}
            <div className="border-t p-3 bg-card">
              <div className="flex items-end gap-2">
                <textarea
                  ref={textareaRef}
                  value={draft}
                  onChange={(e) => setDraft(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder={`Message ${convLabel(activeConv, myId)}… (Enter to send, Shift+Enter for newline)`}
                  rows={1}
                  style={{ resize: "none" }}
                  className="flex-1 min-h-[40px] max-h-32 overflow-y-auto rounded-lg border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                  onInput={(e) => {
                    const el = e.currentTarget;
                    el.style.height = "auto";
                    el.style.height = `${Math.min(el.scrollHeight, 128)}px`;
                  }}
                />
                <Button size="icon" onClick={sendMessage} disabled={!draft.trim() || sending} className="shrink-0">
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </>
        )}
      </div>

      {/* ── Right panel: members ───────────────────────────────────────────── */}
      {showMemberPanel && activeConv && (
        <div className="hidden lg:flex w-60 border-l bg-muted/30 flex-col">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-semibold text-sm">Members</h3>
            <Button variant="ghost" size="icon" className="w-6 h-6" onClick={() => setShowMemberPanel(false)}>
              <ChevronLeft className="w-3 h-3" />
            </Button>
          </div>
          <ScrollArea className="flex-1 p-3">
            <div className="space-y-1">
              {convMembers?.map((m) => (
                <div key={m.id} className="group flex items-center gap-2 px-2 py-1.5 rounded-md hover:bg-accent">
                  <div className="relative shrink-0">
                    <Avatar className="w-7 h-7">
                      <AvatarImage src={m.profileImageUrl ?? ""} />
                      <AvatarFallback className="text-[10px]">{initials(m.firstName, m.lastName)}</AvatarFallback>
                    </Avatar>
                    <span className={cn("absolute bottom-0 right-0 w-2 h-2 rounded-full border border-background", m.isOnline ? "bg-green-500" : "bg-muted")} />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-xs font-medium truncate">{displayName(m.firstName, m.lastName)}</p>
                    {!m.isOnline && m.lastSeenAt && (
                      <p className="text-[10px] text-muted-foreground truncate">
                        {formatDistanceToNow(new Date(m.lastSeenAt), { addSuffix: true })}
                      </p>
                    )}
                  </div>
                  {m.id !== myId && (
                    <button
                      title={`Message ${displayName(m.firstName, m.lastName)}`}
                      onClick={() => startPanelDm(m.id)}
                      className="shrink-0 opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-primary/10 text-muted-foreground hover:text-primary"
                    >
                      <MessageSquare className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              ))}
            </div>
          </ScrollArea>
        </div>
      )}
    </div>
  );
}

// ─── Sub-components ────────────────────────────────────────────────────────────

function fmtName(first?: string | null, last?: string | null, fallback = "Unknown") {
  return [first, last].filter(Boolean).join(" ") || fallback;
}

function displayName(first?: string | null, last?: string | null, _fallback?: string): string {
  return [first, last].filter(Boolean).join(" ") || "Unknown";
}

function ConvRow({ conv, myId, active, onClick }: { conv: ConversationItem; myId: string; active: boolean; onClick: () => void }) {
  const label = conv.type === "all_team" ? "All Team"
    : conv.type === "department" ? (conv.departmentName ?? conv.name ?? "Department")
    : fmtName(conv.otherUser?.firstName, conv.otherUser?.lastName, "DM");

  const subtitle = conv.lastMessage
    ? `${conv.lastMessage.senderFirst ? conv.lastMessage.senderFirst + ": " : ""}${conv.lastMessage.body}`
    : "No messages yet";

  const time = conv.lastMessage?.createdAt
    ? formatDistanceToNow(new Date(conv.lastMessage.createdAt), { addSuffix: false })
    : null;

  return (
    <button
      onClick={onClick}
      className={cn(
        "w-full flex items-start gap-3 px-3 py-2.5 rounded-lg text-left transition-colors",
        active ? "bg-primary/10 text-primary" : "hover:bg-accent",
      )}
    >
      {conv.type === "direct" && conv.otherUser ? (
        <div className="relative shrink-0 mt-0.5">
          <Avatar className="w-8 h-8">
            <AvatarImage src={conv.otherUser.profileImageUrl ?? ""} />
            <AvatarFallback className="text-xs">{initials(conv.otherUser.firstName, conv.otherUser.lastName)}</AvatarFallback>
          </Avatar>
          <span className={cn("absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-background", isOnline(conv.otherUser.lastSeenAt) ? "bg-green-500" : "bg-muted")} />
        </div>
      ) : (
        <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5">
          <Hash className="w-3.5 h-3.5 text-primary" />
        </div>
      )}
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between gap-1">
          <span className="text-sm font-medium truncate">{label}</span>
          {time && <span className="text-[10px] text-muted-foreground shrink-0">{time}</span>}
        </div>
        <p className="text-xs text-muted-foreground truncate">{subtitle}</p>
      </div>
      {conv.unreadCount > 0 && (
        <span className="shrink-0 mt-1 min-w-[18px] h-[18px] rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center px-1">
          {conv.unreadCount > 99 ? "99+" : conv.unreadCount}
        </span>
      )}
    </button>
  );
}

function MessageBubble({ msg, isMe, sameSender, dt }: { msg: MessageItem; isMe: boolean; sameSender: boolean; dt: Date }) {
  return (
    <div className={cn("flex gap-2.5", isMe ? "flex-row-reverse" : "flex-row", sameSender ? "mt-0.5" : "mt-4")}>
      {!sameSender && !isMe ? (
        <Avatar className="w-7 h-7 shrink-0 mt-0.5">
          <AvatarImage src={msg.senderProfileImageUrl ?? ""} />
          <AvatarFallback className="text-[10px]">{initials(msg.senderFirstName, msg.senderLastName)}</AvatarFallback>
        </Avatar>
      ) : !isMe ? (
        <div className="w-7 h-7 shrink-0" />
      ) : null}
      <div className={cn("max-w-[70%] space-y-0.5", isMe && "items-end flex flex-col")}>
        {!sameSender && (
          <div className={cn("flex items-baseline gap-2 text-xs text-muted-foreground", isMe && "flex-row-reverse")}>
            <span className="font-medium">{isMe ? "You" : fmtName(msg.senderFirstName, msg.senderLastName)}</span>
            <span title={dt.toLocaleString()}>{formatDistanceToNow(dt, { addSuffix: true })}</span>
          </div>
        )}
        <div
          className={cn(
            "px-3 py-2 rounded-2xl text-sm whitespace-pre-wrap break-words",
            isMe
              ? "bg-primary text-primary-foreground rounded-tr-sm"
              : "bg-card border rounded-tl-sm",
          )}
        >
          {msg.body}
        </div>
      </div>
    </div>
  );
}


