import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetWeeklyContent, useListContentItems, useGetCurrentWeek,
  useUpdateContentItem,
  getListContentItemsQueryKey, getGetWeeklyContentQueryKey, getGetDashboardSummaryQueryKey,
} from "@workspace/api-client-react";
import type { ContentItem } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, AlertTriangle, Lightbulb, Anchor, Megaphone, Tv2, Search } from "lucide-react";
import { ContentForm } from "@/components/forms/ContentForm";
import { ContentStatusSelect } from "@/components/ui/status-select";
import type { ContentStatus } from "@/components/ui/status-select";

const PIPELINE_COLS: ContentStatus[] = ["idea", "selected", "brief", "script", "film", "edit", "review", "schedule", "posted"];

type LibTab = "pipeline" | "ideas" | "hooks" | "ctas" | "series";

const PILLAR_COLORS: Record<string, string> = {
  "Road Intelligence": "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300",
  "Product / Feature Proof": "bg-primary/10 text-primary",
  "Education / Safety": "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300",
  "Kenyan Driving Reality": "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-300",
  "Founder / BTS": "bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300",
  "Community / UGC": "bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-300",
  "Seasonal Campaign": "bg-amber-100 text-amber-700 dark:bg-amber-900/30 dark:text-amber-300",
  "Debate / Mythbusters": "bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300",
};

function pillarBadge(pillar?: string | null) {
  if (!pillar) return null;
  const base = Object.keys(PILLAR_COLORS).find(k => pillar.startsWith(k));
  return (
    <span className={`inline-block text-[10px] font-medium px-1.5 py-0.5 rounded uppercase tracking-wide ${base ? PILLAR_COLORS[base] : "bg-secondary text-secondary-foreground"}`}>
      {pillar.replace(/^(Hook Bank — |CTA Bank — |Series Playbook$)/, "")}
    </span>
  );
}

export default function Content() {
  const qc = useQueryClient();
  const [tab, setTab] = useState<LibTab>("pipeline");
  const [formOpen, setFormOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ContentItem | undefined>(undefined);
  const [search, setSearch] = useState("");
  const [pillarFilter, setPillarFilter] = useState("");
  const [updatingIds, setUpdatingIds] = useState<Set<number>>(new Set());

  const { data: currentWeek } = useGetCurrentWeek();
  const weekId = currentWeek?.id ?? 1;
  const { data: weeklyContent, isLoading: loadingWeek } = useGetWeeklyContent(weekId);
  const { data: allContent, isLoading: loadingAll } = useListContentItems({ limit: 2000 } as any);
  const updateContent = useUpdateContentItem();

  const openCreate = () => { setEditingItem(undefined); setFormOpen(true); };
  const openEdit = (item: ContentItem) => { setEditingItem(item); setFormOpen(true); };
  const handleClose = () => { setFormOpen(false); setEditingItem(undefined); };

  const handleStatusChange = (item: ContentItem, newStatus: ContentStatus) => {
    if (item.status === newStatus) return;
    setUpdatingIds(s => new Set(s).add(item.id));
    updateContent.mutate(
      { id: item.id, data: { status: newStatus } },
      {
        onSuccess: () => {
          qc.invalidateQueries({ queryKey: getListContentItemsQueryKey() });
          qc.invalidateQueries({ queryKey: getGetWeeklyContentQueryKey(weekId) });
          qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
        },
        onSettled: () => setUpdatingIds(s => { const n = new Set(s); n.delete(item.id); return n; }),
      }
    );
  };

  if (loadingWeek || loadingAll) {
    return <div className="p-8 space-y-4"><Skeleton className="h-10 w-48" /><Skeleton className="h-64 w-full" /></div>;
  }

  const items = (allContent as any)?.items ?? allContent ?? [];
  const coreCount = weeklyContent?.coreItems?.length ?? 0;

  // Partition by pillar prefix
  const ideaBank = items.filter((c: ContentItem) => c.weekId == null && !c.pillar?.startsWith("Hook Bank") && !c.pillar?.startsWith("CTA Bank") && !c.pillar?.startsWith("Series Playbook") && c.status === "idea");
  const hookBank = items.filter((c: ContentItem) => c.pillar?.startsWith("Hook Bank"));
  const ctaBank  = items.filter((c: ContentItem) => c.pillar?.startsWith("CTA Bank"));
  const series   = items.filter((c: ContentItem) => c.pillar?.startsWith("Series Playbook"));

  // Unique pillars for idea bank filter
  const ideaPillars = [...new Set<string>(ideaBank.map((c: ContentItem) => c.pillar ?? "").filter(Boolean))].sort();

  const filterItems = (list: ContentItem[]) =>
    list.filter(c => {
      const matchSearch = !search || c.title.toLowerCase().includes(search.toLowerCase()) || c.hook?.toLowerCase().includes(search.toLowerCase());
      const matchPillar = !pillarFilter || c.pillar === pillarFilter;
      return matchSearch && matchPillar;
    });

  const TABS: { key: LibTab; label: string; icon: React.ReactNode; count: number }[] = [
    { key: "pipeline", label: "Pipeline", icon: <Tv2 className="w-3.5 h-3.5" />, count: items.filter((c: ContentItem) => c.weekId != null || (c.status !== "idea" && !c.pillar?.startsWith("Hook") && !c.pillar?.startsWith("CTA") && !c.pillar?.startsWith("Series"))).length },
    { key: "ideas",    label: "Idea Bank", icon: <Lightbulb className="w-3.5 h-3.5" />, count: ideaBank.length },
    { key: "hooks",    label: "Hook Bank", icon: <Anchor className="w-3.5 h-3.5" />, count: hookBank.length },
    { key: "ctas",     label: "CTA Bank", icon: <Megaphone className="w-3.5 h-3.5" />, count: ctaBank.length },
    { key: "series",   label: "Series", icon: <Tv2 className="w-3.5 h-3.5" />, count: series.length },
  ];

  return (
    <div className="space-y-6 animate-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Content</h1>
          <p className="text-muted-foreground mt-1">
            {ideaBank.length} ideas · {hookBank.length} hooks · {ctaBank.length} CTAs · {series.length} series
          </p>
        </div>
        <Button onClick={openCreate}><PlusCircle className="w-4 h-4 mr-2" /> Add Content</Button>
      </div>

      {/* This-week core strip */}
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader className="py-3 px-4 border-b border-primary/10 flex flex-row items-center justify-between">
          <CardTitle className="text-sm font-semibold text-primary">Week {currentWeek?.weekNumber ?? 1} — Core Pieces (limit 4)</CardTitle>
          <Badge variant={coreCount >= 4 ? "destructive" : "secondary"} className="text-xs">{coreCount} / 4</Badge>
        </CardHeader>
        <CardContent className="p-0 divide-y divide-primary/10">
          {weeklyContent?.coreItems?.map((item, i) => (
            <div key={item.id} className="flex items-center gap-3 px-4 py-2.5 hover:bg-primary/5 cursor-pointer" onClick={() => openEdit(item)}>
              <span className="w-6 h-6 rounded-full bg-primary/10 text-primary text-xs font-bold flex items-center justify-center shrink-0">{i + 1}</span>
              <div className="flex-1">
                <p className="text-sm font-medium break-words">{item.title}</p>
                {item.pillar && <p className="text-[10px] text-muted-foreground">{item.pillar}</p>}
              </div>
              <div className="flex items-center gap-2 shrink-0" onClick={e => e.stopPropagation()}>
                {item.hasComplianceWarning && <span title="Compliance note"><AlertTriangle className="w-3.5 h-3.5 text-amber-500" /></span>}
                <ContentStatusSelect value={item.status as ContentStatus} onChange={v => handleStatusChange(item, v)} disabled={updatingIds.has(item.id)} />
              </div>
            </div>
          ))}
          {(!weeklyContent?.coreItems || weeklyContent.coreItems.length === 0) && (
            <p className="px-4 py-4 text-sm text-muted-foreground">No core content selected this week. <button className="text-primary underline" onClick={openCreate}>Add one</button></p>
          )}
        </CardContent>
      </Card>

      {/* Tab bar */}
      <div className="flex items-center gap-1 border-b pb-0 overflow-x-auto">
        {TABS.map(t => (
          <button
            key={t.key}
            onClick={() => { setTab(t.key); setSearch(""); setPillarFilter(""); }}
            className={`flex items-center gap-1.5 px-3 py-2 text-sm font-medium border-b-2 transition-colors whitespace-nowrap -mb-px ${
              tab === t.key ? "border-primary text-foreground" : "border-transparent text-muted-foreground hover:text-foreground"
            }`}
          >
            {t.icon}{t.label}
            <span className="text-xs opacity-60 ml-0.5">{t.count}</span>
          </button>
        ))}
      </div>

      {/* Search + pillar filter */}
      {tab !== "pipeline" && (
        <div className="flex gap-2 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <input
              type="text"
              placeholder={tab === "hooks" ? "Search hooks…" : tab === "ctas" ? "Search CTAs…" : "Search ideas…"}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full h-9 pl-9 pr-4 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            />
          </div>
          {tab === "ideas" && ideaPillars.length > 0 && (
            <select
              value={pillarFilter}
              onChange={e => setPillarFilter(e.target.value)}
              className="h-9 px-3 rounded-md border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-ring"
            >
              <option value="">All pillars</option>
              {ideaPillars.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          )}
        </div>
      )}

      {/* Pipeline tab */}
      {tab === "pipeline" && (
        <div className="flex gap-4 overflow-x-auto pb-6">
          {PIPELINE_COLS.map(col => {
            const colItems = items
              .filter((c: ContentItem) => c.status === col && !c.pillar?.startsWith("Hook Bank") && !c.pillar?.startsWith("CTA Bank") && !c.pillar?.startsWith("Series Playbook"))
              // Chronological: items with a weekId sort by week ascending (closer first); then by id
              .sort((a: ContentItem, b: ContentItem) => {
                const wa = a.weekId ?? 9999;
                const wb = b.weekId ?? 9999;
                if (wa !== wb) return wa - wb;
                return a.id - b.id;
              });
            return (
              <div key={col} className="min-w-[240px] w-[240px] shrink-0 bg-muted/30 border rounded-lg p-3 flex flex-col max-h-[600px]">
                <div className="flex justify-between items-center mb-3 px-1">
                  <h3 className="font-medium text-sm capitalize">{col}</h3>
                  <Badge variant="secondary" className="px-1.5 text-xs">{colItems.length}</Badge>
                </div>
                <div className="flex-1 overflow-y-auto space-y-2">
                  {colItems.map((item: ContentItem) => (
                    <Card key={item.id} className="cursor-pointer hover:border-primary/40 transition-colors" onClick={() => openEdit(item)}>
                      <CardContent className="p-3 space-y-2">
                        <div className="flex justify-between items-start gap-2">
                          <p className="text-xs font-medium leading-snug flex-1">{item.title}</p>
                          {item.isCore && <div className="w-2 h-2 rounded-full bg-primary shrink-0 mt-1" title="Core" />}
                        </div>
                        <div className="flex items-center justify-between gap-2" onClick={e => e.stopPropagation()}>
                          {pillarBadge(item.pillar)}
                          <ContentStatusSelect value={item.status as ContentStatus} onChange={v => handleStatusChange(item, v)} disabled={updatingIds.has(item.id)} />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                  {!colItems.length && (
                    <div className="h-16 border-2 border-dashed border-muted rounded-lg flex items-center justify-center text-muted-foreground text-xs">Empty</div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Idea Bank tab */}
      {tab === "ideas" && (
        <IdeaGrid items={filterItems(ideaBank)} onEdit={openEdit} onStatusChange={handleStatusChange} updatingIds={updatingIds} />
      )}

      {/* Hook Bank tab */}
      {tab === "hooks" && (
        <ReferenceTable
          items={filterItems(hookBank)}
          emptyText="No hooks found."
          labelHeader="Category"
          getLabel={c => c.pillar?.replace("Hook Bank — ", "") ?? ""}
          getMain={c => c.hook ?? c.title}
          getSub={c => c.notes ?? ""}
        />
      )}

      {/* CTA Bank tab */}
      {tab === "ctas" && (
        <ReferenceTable
          items={filterItems(ctaBank)}
          emptyText="No CTAs found."
          labelHeader="Funnel Stage"
          getLabel={c => c.pillar?.replace("CTA Bank — ", "") ?? ""}
          getMain={c => c.cta ?? c.title}
          getSub={c => c.notes ?? ""}
        />
      )}

      {/* Series tab */}
      {tab === "series" && (
        <div className="space-y-4">
          {filterItems(series).map(item => (
            <Card key={item.id} className="cursor-pointer hover:border-primary/40" onClick={() => openEdit(item)}>
              <CardContent className="p-4">
                <p className="font-semibold">{item.title.replace("[Series] ", "")}</p>
                <p className="text-sm text-muted-foreground mt-1 whitespace-pre-line line-clamp-4">{item.notes}</p>
              </CardContent>
            </Card>
          ))}
          {!filterItems(series).length && <p className="text-sm text-muted-foreground text-center py-8">No series found.</p>}
        </div>
      )}

      <ContentForm open={formOpen} onClose={handleClose} item={editingItem} currentWeekId={weekId} />
    </div>
  );
}

/* ── Idea grid ── */
function IdeaGrid({ items, onEdit, onStatusChange, updatingIds }: {
  items: ContentItem[];
  onEdit: (i: ContentItem) => void;
  onStatusChange: (i: ContentItem, s: ContentStatus) => void;
  updatingIds: Set<number>;
}) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
      {items.map(item => (
        <Card key={item.id} className="cursor-pointer hover:border-primary/40 transition-colors flex flex-col" onClick={() => onEdit(item)}>
          <CardContent className="p-4 flex flex-col gap-2 flex-1">
            <div className="flex items-start justify-between gap-2">
              {pillarBadge(item.pillar)}
              {item.hasComplianceWarning && <span title="Compliance note"><AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" /></span>}
            </div>
            <p className="text-sm font-medium leading-snug flex-1">{item.title}</p>
            {item.hook && item.hook !== item.title && (
              <p className="text-xs text-muted-foreground line-clamp-2">{item.hook}</p>
            )}
            {item.format && <p className="text-[10px] text-muted-foreground uppercase tracking-wide">{item.format}</p>}
            <div className="flex items-center justify-between mt-auto pt-2" onClick={e => e.stopPropagation()}>
              <ContentStatusSelect value={item.status as ContentStatus} onChange={v => onStatusChange(item, v)} disabled={updatingIds.has(item.id)} />
              {item.cta && <span className="text-[10px] text-primary truncate max-w-[120px]" title={item.cta}>{item.cta}</span>}
            </div>
          </CardContent>
        </Card>
      ))}
      {!items.length && <p className="col-span-3 text-sm text-muted-foreground text-center py-12">No ideas match your filter.</p>}
    </div>
  );
}

/* ── Reference table (hooks / CTAs) ── */
function ReferenceTable({ items, emptyText, labelHeader, getLabel, getMain, getSub }: {
  items: ContentItem[];
  emptyText: string;
  labelHeader: string;
  getLabel: (c: ContentItem) => string;
  getMain: (c: ContentItem) => string;
  getSub: (c: ContentItem) => string;
}) {
  const grouped: Record<string, ContentItem[]> = {};
  items.forEach(item => {
    const key = getLabel(item) || "General";
    if (!grouped[key]) grouped[key] = [];
    grouped[key].push(item);
  });

  if (!items.length) return <p className="text-sm text-muted-foreground text-center py-12">{emptyText}</p>;

  return (
    <div className="space-y-6">
      {Object.entries(grouped).map(([group, groupItems]) => (
        <div key={group}>
          <h3 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mb-3">{group}</h3>
          <div className="bg-card border rounded-lg overflow-hidden">
            {groupItems.map((item, idx) => (
              <div key={item.id} className={`px-4 py-3 ${idx !== groupItems.length - 1 ? "border-b" : ""}`}>
                <p className="text-sm font-medium">{getMain(item)}</p>
                {getSub(item) && <p className="text-xs text-muted-foreground mt-1">{getSub(item)}</p>}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}
