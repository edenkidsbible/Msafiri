import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import { 
  useGetTransactionSummary, 
  useListTransactions, 
  useListRecurringExpenses 
} from "@workspace/api-client-react";
import type { Transaction, WeekCashRow } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { formatKes } from "@/lib/utils";
import { PlusCircle, Wallet, RefreshCw, Pencil, ArrowRight, Landmark, Smartphone, TrendingUp, TrendingDown, ChevronDown, ChevronRight, SquarePen } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { TransactionForm } from "@/components/forms/TransactionForm";

// WeekCashRow as returned by the backend includes weekId (not in codegen type)
type ExtWeekRow = WeekCashRow & { weekId: number };

// ── Per-week transaction breakdown ────────────────────────────────────────────

interface WeekTx {
  id: number; date: string; type: string;
  description: string; categoryName: string | null;
  amountKes: string; cleared: boolean;
}

function useWeekTransactions(weekId: number | null) {
  return useQuery<{ items: WeekTx[]; total: number }>({
    queryKey: ["transactions", "week", weekId],
    queryFn: async () => {
      const r = await fetch(`/api/transactions?weekId=${weekId}&limit=100`);
      if (!r.ok) throw new Error("Failed to fetch week transactions");
      return r.json();
    },
    enabled: weekId !== null,
  });
}

function WeekBreakdown({ weekId }: { weekId: number }) {
  const { data, isLoading } = useWeekTransactions(weekId);

  if (isLoading) {
    return (
      <tr>
        <td colSpan={7} className="px-6 py-3 bg-muted/20 border-b">
          <p className="text-xs text-muted-foreground animate-pulse">Loading transactions…</p>
        </td>
      </tr>
    );
  }

  const items = data?.items ?? [];
  const income  = items.filter(t => t.type === "income"  || t.type === "refund_in");
  const expenses = items.filter(t => t.type === "expense" || t.type === "refund_out");
  const reserves = items.filter(t => t.type === "reserve_transfer");

  if (!items.length) {
    return (
      <tr>
        <td colSpan={7} className="px-6 py-3 bg-muted/20 border-b text-xs text-muted-foreground">
          No transactions logged for this week yet.
        </td>
      </tr>
    );
  }

  const TxList = ({ rows, color }: { rows: WeekTx[]; color: "emerald" | "rose" | "blue" }) => {
    const amtClass = color === "emerald" ? "text-emerald-700 dark:text-emerald-400"
      : color === "rose" ? "text-rose-600" : "text-blue-600";
    return (
      <div className="space-y-1.5">
        {rows.map(tx => (
          <div key={tx.id} className="flex items-center justify-between gap-2 text-xs">
            <div className="flex items-center gap-1.5 min-w-0">
              <span
                className={`w-1.5 h-1.5 rounded-full shrink-0 ${tx.cleared
                  ? color === "emerald" ? "bg-emerald-500" : color === "rose" ? "bg-rose-500" : "bg-blue-500"
                  : "bg-muted-foreground/30"}`}
                title={tx.cleared ? "Cleared" : "Pending"}
              />
              <span className="truncate text-foreground/80">{tx.description}</span>
              {tx.categoryName && (
                <Badge variant="outline" className="text-[10px] px-1 py-0 shrink-0 font-normal">
                  {tx.categoryName}
                </Badge>
              )}
            </div>
            <span className={`font-mono font-medium shrink-0 ${amtClass}`}>{formatKes(tx.amountKes)}</span>
          </div>
        ))}
      </div>
    );
  };

  return (
    <tr>
      <td colSpan={7} className="bg-muted/20 border-b">
        <div className="px-6 py-3 grid grid-cols-1 md:grid-cols-3 gap-5">
          {income.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-emerald-600 mb-2">
                Income ({income.filter(t => t.cleared).length} cleared · {income.filter(t => !t.cleared).length} pending)
              </p>
              <TxList rows={income} color="emerald" />
            </div>
          )}
          {expenses.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-rose-500 mb-2">
                Expenses ({expenses.filter(t => t.cleared).length} cleared · {expenses.filter(t => !t.cleared).length} pending)
              </p>
              <TxList rows={expenses} color="rose" />
            </div>
          )}
          {reserves.length > 0 && (
            <div>
              <p className="text-[10px] font-semibold uppercase tracking-wider text-blue-500 mb-2">
                Reserve Transfers
              </p>
              <TxList rows={reserves} color="blue" />
            </div>
          )}
        </div>
        <div className="px-6 pb-2 flex items-center gap-3 text-[10px] text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block"/>Cleared</span>
          <span className="flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-muted-foreground/30 inline-block"/>Pending / Planned</span>
        </div>
      </td>
    </tr>
  );
}

// ── Cash position types + hook ────────────────────────────────────────────────

interface AccountBalance { account: string; balanceKes: string; }
interface CategoryTotal { category: string; totalKes: string; }
interface CashPosition {
  byAccount: AccountBalance[];
  byIncomeSource: CategoryTotal[];
  byExpenseCategory: CategoryTotal[];
}

function useCashPosition() {
  return useQuery<CashPosition>({
    queryKey: ["cash-position"],
    queryFn: async () => {
      const r = await fetch("/api/transactions/cash-position");
      if (!r.ok) throw new Error("Cash position fetch failed");
      return r.json();
    },
    refetchInterval: 30_000,
  });
}

// Account display helpers
const ACCOUNT_ICONS: Record<string, React.ReactNode> = {
  bank: <Landmark className="w-4 h-4" />,
  mpesa: <Smartphone className="w-4 h-4" />,
  "mpesa till": <Smartphone className="w-4 h-4" />,
  cash: <Wallet className="w-4 h-4" />,
};
function accountIcon(name: string) {
  return ACCOUNT_ICONS[name.toLowerCase()] ?? <Wallet className="w-4 h-4" />;
}
function accountLabel(name: string) {
  const m: Record<string, string> = { bank: "Bank", mpesa: "M-PESA", "mpesa till": "M-PESA Till", cash: "Cash" };
  return m[name.toLowerCase()] ?? name;
}

// ── Budget edit dialog ────────────────────────────────────────────────────────

interface BudgetDialogProps {
  weekId: number;
  weekNumber: number;
  initial: { plannedIn: string | null; plannedOut: string | null; plannedEnding: string | null };
  onClose: () => void;
  onSaved: () => void;
}

function BudgetDialog({ weekId, weekNumber, initial, onClose, onSaved }: BudgetDialogProps) {
  const [plannedIn, setPlannedIn] = useState(initial.plannedIn ?? "");
  const [plannedOut, setPlannedOut] = useState(initial.plannedOut ?? "");
  const [plannedEnding, setPlannedEnding] = useState(initial.plannedEnding ?? "");
  const [saving, setSaving] = useState(false);

  const save = async () => {
    setSaving(true);
    try {
      await fetch(`/api/weeks/${weekId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          plannedCashInKes: plannedIn !== "" ? parseFloat(plannedIn) : null,
          plannedCashOutKes: plannedOut !== "" ? parseFloat(plannedOut) : null,
          plannedEndingCashKes: plannedEnding !== "" ? parseFloat(plannedEnding) : null,
        }),
      });
      onSaved();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={open => !open && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Week {weekNumber} — Budget Targets</DialogTitle>
        </DialogHeader>
        <p className="text-sm text-muted-foreground -mt-2">
          Set the planned cash figures for this week. These are your targets before the week begins — actual figures come from logged transactions.
        </p>
        <div className="space-y-4 pt-1">
          <div className="space-y-1.5">
            <Label>Planned Cash In (KES)</Label>
            <Input
              type="number"
              placeholder="e.g. 10000"
              value={plannedIn}
              onChange={e => setPlannedIn(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Planned Cash Out (KES)</Label>
            <Input
              type="number"
              placeholder="e.g. 8000"
              value={plannedOut}
              onChange={e => setPlannedOut(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Target Ending Cash (KES)</Label>
            <Input
              type="number"
              placeholder="e.g. 2000"
              value={plannedEnding}
              onChange={e => setPlannedEnding(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter className="pt-2">
          <Button variant="outline" onClick={onClose} disabled={saving}>Cancel</Button>
          <Button onClick={save} disabled={saving}>{saving ? "Saving…" : "Save targets"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function Money() {
  const qc = useQueryClient();
  const [activeTab, setActiveTab] = useState<'income' | 'expense' | 'reserve'>('expense');
  const [formOpen, setFormOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | undefined>(undefined);
  const [expandedWeekId, setExpandedWeekId] = useState<number | null>(null);
  const [budgetWeek, setBudgetWeek] = useState<ExtWeekRow | null>(null);
  const [formDefaults, setFormDefaults] = useState<{
    defaultAmount?: string;
    defaultType?: any;
    defaultDescription?: string;
  }>({});
  
  const { data: summary, isLoading: loadingSummary } = useGetTransactionSummary();
  const { data: transactions, isLoading: loadingTx } = useListTransactions();
  const { data: recurring, isLoading: loadingRec } = useListRecurringExpenses();
  const { data: cashPos } = useCashPosition();

  const openFridayFunding = () => {
    setEditingTx(undefined);
    setFormDefaults({
      defaultAmount: "10000",
      defaultType: "income",
      defaultDescription: "Friday Funding",
    });
    setFormOpen(true);
  };

  const openCreate = () => {
    setEditingTx(undefined);
    setFormDefaults({});
    setFormOpen(true);
  };

  const openEdit = (tx: Transaction) => {
    setEditingTx(tx);
    setFormDefaults({});
    setFormOpen(true);
  };

  const handleClose = () => {
    setFormOpen(false);
    setEditingTx(undefined);
    setFormDefaults({});
  };

  if (loadingSummary || loadingTx) {
    return <div className="p-8 space-y-6"><Skeleton className="h-10 w-48"/><Skeleton className="h-64 w-full"/></div>;
  }

  const chartData = summary?.weeks.map(w => ({
    name: `W${w.weekNumber}`,
    actualOut: parseFloat(w.actualOutKes || "0"),
    actualIn: parseFloat(w.actualInKes || "0")
  })) || [];

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const isCurrentWeek = (row: WeekCashRow): boolean => {
    const start = new Date(row.startDate);
    start.setHours(0, 0, 0, 0);
    const end = new Date(start);
    end.setDate(end.getDate() + 7);
    return today >= start && today < end;
  };

  const fmt = (val: string | null | undefined) =>
    val ? formatKes(val) : <span className="text-muted-foreground/50">—</span>;

  const variance = (row: WeekCashRow) => {
    if (!row.varianceKes) return null;
    const v = parseFloat(row.varianceKes);
    return v;
  };

  return (
    <div className="space-y-8 animate-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Money</h1>
          <p className="text-muted-foreground mt-1">Cash operating center.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="text-primary border-primary/30 hover:bg-primary/5" onClick={openFridayFunding}>
            <Wallet className="w-4 h-4 mr-2" />
            Friday Funding (KES 10k)
          </Button>
          <Button onClick={openCreate}><PlusCircle className="w-4 h-4 mr-2" /> Log Transaction</Button>
        </div>
      </div>

      {/* ── Top KPI cards ── */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Operating Cash</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-mono text-primary">{formatKes(summary?.operatingCashKes)}</div>
            <p className="text-xs text-muted-foreground mt-1">Available for use</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Reserve Cash</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold font-mono">{formatKes(summary?.reserveCashKes)}</div>
            <p className="text-xs text-muted-foreground mt-1">Do not touch</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Runway</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{summary?.runwayWeeks ?? '--'} weeks</div>
            <p className="text-xs text-muted-foreground mt-1">Based on recent burn</p>
          </CardContent>
        </Card>
      </div>

      {/* ── Cash position: where money is + revenue sources + expense breakdown ── */}
      {cashPos && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

          {/* Where money sits */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Landmark className="w-4 h-4 text-muted-foreground" />
                Where Your Money Is
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {cashPos.byAccount.length === 0 ? (
                <p className="text-sm text-muted-foreground">No cleared transactions with payment method set.</p>
              ) : (
                <div className="space-y-2">
                  {cashPos.byAccount.map(a => {
                    const bal = parseFloat(a.balanceKes);
                    return (
                      <div key={a.account} className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 text-muted-foreground">
                          {accountIcon(a.account)}
                          <span className="text-sm">{accountLabel(a.account)}</span>
                        </div>
                        <span className={`font-mono font-semibold text-sm ${bal < 0 ? "text-destructive" : bal === 0 ? "text-muted-foreground" : ""}`}>
                          {formatKes(a.balanceKes)}
                        </span>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Revenue by source */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-emerald-600" />
                Revenue by Source
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {cashPos.byIncomeSource.length === 0 ? (
                <p className="text-sm text-muted-foreground">No cleared income recorded yet.</p>
              ) : (
                <div className="space-y-2">
                  {cashPos.byIncomeSource.map(s => (
                    <div key={s.category} className="flex items-center justify-between gap-2">
                      <span className="text-sm text-muted-foreground truncate">{s.category}</span>
                      <span className="font-mono font-semibold text-sm text-emerald-700 dark:text-emerald-400 shrink-0">
                        {formatKes(s.totalKes)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Expenses by category */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <TrendingDown className="w-4 h-4 text-rose-500" />
                Expenses by Category
              </CardTitle>
            </CardHeader>
            <CardContent className="pt-0">
              {cashPos.byExpenseCategory.length === 0 ? (
                <p className="text-sm text-muted-foreground">No cleared expenses recorded yet.</p>
              ) : (
                <div className="space-y-2">
                  {cashPos.byExpenseCategory.map(e => (
                    <div key={e.category} className="flex items-center justify-between gap-2">
                      <span className="text-sm text-muted-foreground truncate">{e.category}</span>
                      <span className="font-mono font-semibold text-sm text-rose-600 shrink-0">
                        {formatKes(e.totalKes)}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

        </div>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Cash Flow Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 12 }} tickFormatter={(val) => `KES ${(val/1000).toFixed(0)}k`} />
                <Tooltip cursor={{ fill: '#f3f4f6' }} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                <Legend />
                <Bar dataKey="actualIn" name="Cash In" fill="hsl(150, 60%, 40%)" radius={[4, 4, 0, 0]} />
                <Bar dataKey="actualOut" name="Cash Out" fill="hsl(0, 70%, 50%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Weekly Cash Summary</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 border-b">
                <tr>
                  <th className="text-left font-medium p-3 text-muted-foreground">Week</th>
                  <th className="text-right font-medium p-3 text-muted-foreground">Planned In</th>
                  <th className="text-right font-medium p-3 text-muted-foreground">Planned Out</th>
                  <th className="text-right font-medium p-3 text-muted-foreground">Actual In</th>
                  <th className="text-right font-medium p-3 text-muted-foreground">Actual Out</th>
                  <th className="text-right font-medium p-3 text-muted-foreground">Variance</th>
                  <th className="w-8 p-3"></th>
                </tr>
              </thead>
              <tbody>
                {(summary?.weeks as ExtWeekRow[] | undefined)?.map(row => {
                  const isCurrent = isCurrentWeek(row);
                  const v = variance(row);
                  const isExpanded = expandedWeekId === row.weekId;
                  const toggle = () => setExpandedWeekId(isExpanded ? null : row.weekId);
                  return (
                    <>
                      <tr
                        key={row.weekNumber}
                        className={`border-b transition-colors cursor-pointer select-none ${isCurrent ? 'bg-primary/5' : 'hover:bg-muted/20'} ${isExpanded ? 'bg-muted/30' : ''}`}
                        onClick={toggle}
                      >
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            {isExpanded
                              ? <ChevronDown className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                              : <ChevronRight className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                            }
                            {isCurrent && (
                              <span className="inline-block w-2 h-2 rounded-full bg-primary flex-shrink-0" />
                            )}
                            <span className={`font-medium ${isCurrent ? 'text-primary' : ''}`}>
                              Week {row.weekNumber}
                            </span>
                            <span className="text-xs text-muted-foreground hidden sm:inline">
                              {new Date(row.startDate).toLocaleDateString('en-KE', { month: 'short', day: 'numeric' })}
                            </span>
                            {isCurrent && (
                              <Badge variant="outline" className="text-xs border-primary/40 text-primary px-1.5 py-0">
                                current
                              </Badge>
                            )}
                          </div>
                        </td>
                        <td
                          className="p-3 text-right font-mono group/budget cursor-pointer hover:text-primary transition-colors"
                          onClick={e => { e.stopPropagation(); setBudgetWeek(row); }}
                          title="Click to set budget targets"
                        >
                          <span className="inline-flex items-center gap-1 justify-end">
                            {fmt(row.plannedInKes)}
                            <SquarePen className="w-3 h-3 opacity-0 group-hover/budget:opacity-60 transition-opacity shrink-0" />
                          </span>
                        </td>
                        <td
                          className="p-3 text-right font-mono group/budget2 cursor-pointer hover:text-primary transition-colors"
                          onClick={e => { e.stopPropagation(); setBudgetWeek(row); }}
                          title="Click to set budget targets"
                        >
                          <span className="inline-flex items-center gap-1 justify-end">
                            {fmt(row.plannedOutKes)}
                            <SquarePen className="w-3 h-3 opacity-0 group-hover/budget2:opacity-60 transition-opacity shrink-0" />
                          </span>
                        </td>
                        <td className="p-3 text-right font-mono text-emerald-600">{fmt(row.actualInKes)}</td>
                        <td className="p-3 text-right font-mono text-rose-600">{fmt(row.actualOutKes)}</td>
                        <td className="p-3 text-right font-mono">
                          {v !== null ? (
                            <span className={v >= 0 ? 'text-emerald-600' : 'text-rose-600'}>
                              {v >= 0 ? '+' : ''}{formatKes(row.varianceKes!)}
                            </span>
                          ) : (
                            <span className="text-muted-foreground/50">—</span>
                          )}
                        </td>
                        <td className="p-3" onClick={e => e.stopPropagation()}>
                          <Link
                            href="/this-week"
                            className="flex items-center justify-center w-6 h-6 rounded hover:bg-muted text-muted-foreground hover:text-foreground transition-colors"
                            title={`Go to Week ${row.weekNumber}`}
                          >
                            <ArrowRight className="w-3.5 h-3.5" />
                          </Link>
                        </td>
                      </tr>
                      {isExpanded && <WeekBreakdown weekId={row.weekId} />}
                    </>
                  );
                })}
                {!summary?.weeks.length && (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-muted-foreground">
                      No weekly data available.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center gap-4 border-b">
            {(['expense', 'income', 'reserve'] as const).map(tab => (
              <button 
                key={tab}
                className={`pb-2 text-sm font-medium border-b-2 transition-colors capitalize ${activeTab === tab ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
                onClick={() => setActiveTab(tab)}
              >
                {tab === 'reserve' ? 'Reserves' : tab === 'income' ? 'Income' : 'Expenses'}
              </button>
            ))}
          </div>

          <div className="bg-card border rounded-lg overflow-hidden">
            <table className="w-full text-sm table-auto">
              <thead className="bg-muted/50 border-b">
                <tr>
                  <th className="text-left font-medium p-3 text-muted-foreground whitespace-nowrap">Date</th>
                  <th className="text-left font-medium p-3 text-muted-foreground">Description</th>
                  <th className="text-left font-medium p-3 text-muted-foreground whitespace-nowrap">Category</th>
                  <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap">Amount</th>
                  <th className="w-10 p-3"></th>
                </tr>
              </thead>
              <tbody>
                {transactions?.items
                  .filter(t => t.type.includes(activeTab))
                  .slice(0, 10)
                  .map(tx => (
                  <tr key={tx.id} className="border-b last:border-0 hover:bg-muted/20 group">
                    <td className="p-3 text-muted-foreground">{new Date(tx.date).toLocaleDateString()}</td>
                    <td className="p-3 font-medium">{tx.description}</td>
                    <td className="p-3"><Badge variant="outline">{tx.categoryName}</Badge></td>
                    <td className={`p-3 text-right font-mono font-medium ${tx.type.includes('income') ? 'text-emerald-600' : ''}`}>
                      {formatKes(tx.amountKes)}
                    </td>
                    <td className="p-3">
                      <button
                        onClick={() => openEdit(tx)}
                        className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-muted"
                        title="Edit"
                      >
                        <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                      </button>
                    </td>
                  </tr>
                ))}
                {!transactions?.items.filter(t => t.type.includes(activeTab)).length && (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-muted-foreground">
                      No {activeTab} transactions found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <RefreshCw className="w-4 h-4" />
                Recurring Expenses
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recurring?.map(rec => (
                  <div key={rec.id} className="flex justify-between items-start border-b last:border-0 pb-3 last:pb-0">
                    <div>
                      <p className="font-medium text-sm">{rec.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{rec.frequency} &bull; {rec.categoryName}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-mono text-sm font-medium">{formatKes(rec.amountKes)}</p>
                      {rec.currencyType === 'USD' && (
                        <p className="text-xs text-muted-foreground">USD {rec.amountUsd}</p>
                      )}
                    </div>
                  </div>
                ))}
                {!recurring?.length && (
                  <p className="text-sm text-muted-foreground text-center py-4">No recurring expenses configured.</p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <TransactionForm
        open={formOpen}
        onClose={handleClose}
        transaction={editingTx}
        {...formDefaults}
      />

      {budgetWeek && (
        <BudgetDialog
          weekId={budgetWeek.weekId}
          weekNumber={budgetWeek.weekNumber}
          initial={{
            plannedIn: budgetWeek.plannedInKes ?? null,
            plannedOut: budgetWeek.plannedOutKes ?? null,
            plannedEnding: (budgetWeek as any).plannedEndingKes ?? null,
          }}
          onClose={() => setBudgetWeek(null)}
          onSaved={() => {
            setBudgetWeek(null);
            qc.invalidateQueries({ queryKey: ["/api/transactions/summary"] });
          }}
        />
      )}
    </div>
  );
}
