import { useState } from 'react';
import { useLocation } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';

export default function Login() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ email, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error ?? 'Login failed');
        return;
      }
      // Invalidate auth query so AuthGate picks up the new session
      await queryClient.invalidateQueries({ queryKey: ['getCurrentAuthUser'] });
      navigate('/');
    } catch {
      setError('Network error — please try again');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
      {/* Kenyan flag stripe */}
      <div className="fixed top-0 inset-x-0 h-1 flex">
        <div className="flex-1 bg-[#006600]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#CE1126]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#006600]" />
      </div>

      <div className="w-full max-w-sm space-y-6">
        {/* Logo + title */}
        <div className="flex flex-col items-center gap-3 mb-2">
          <img
            src="/logo.png"
            alt="Msafiri"
            className="w-16 h-16 rounded-2xl object-contain bg-white shadow"
          />
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight">Msafiri Founder OS</h1>
            <p className="text-sm text-muted-foreground mt-1">Internal command center</p>
          </div>
        </div>

        {/* Login card */}
        <div className="bg-card border border-border rounded-2xl shadow-sm p-6 space-y-4">
          <h2 className="text-base font-semibold">Sign in to your account</h2>

          <form onSubmit={handleSubmit} className="space-y-3">
            <div className="space-y-1">
              <label className="text-sm font-medium text-foreground" htmlFor="email">
                Email
              </label>
              <input
                id="email"
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
              />
            </div>

            <div className="space-y-1">
              <label className="text-sm font-medium text-foreground" htmlFor="password">
                Password
              </label>
              <input
                id="password"
                type="password"
                autoComplete="current-password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
              />
            </div>

            {error && (
              <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold hover:bg-primary/90 active:scale-[0.98] transition disabled:opacity-60"
            >
              {loading ? 'Signing in…' : 'Sign in'}
            </button>
          </form>

          <div className="flex flex-col gap-1.5 text-xs text-muted-foreground text-center pt-1">
            <a href="/forgot-password" className="text-primary font-medium hover:underline">
              Forgot your password?
            </a>
            <span>
              No account?{' '}
              <span className="text-foreground font-medium">Ask your admin to invite you.</span>
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
