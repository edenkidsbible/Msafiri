import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { useQueryClient } from '@tanstack/react-query';

const BASE_URL = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, '') ?? '';

function getToken(): string | null {
  const params = new URLSearchParams(window.location.search);
  return params.get('token');
}

export default function ResetPassword() {
  const [, navigate] = useLocation();
  const queryClient = useQueryClient();

  const [token] = useState(() => getToken());
  const [email, setEmail] = useState<string | null>(null);
  const [validating, setValidating] = useState(true);
  const [tokenError, setTokenError] = useState('');

  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (!token) {
      setTokenError('No reset token found. Please use the link from your email.');
      setValidating(false);
      return;
    }
    fetch(`${BASE_URL}/api/auth/validate-reset/${encodeURIComponent(token)}`)
      .then(async (res) => {
        if (!res.ok) {
          const data = await res.json().catch(() => ({}));
          setTokenError(data.error ?? 'This reset link is invalid or has expired.');
        } else {
          const data = await res.json();
          setEmail(data.email);
        }
      })
      .catch(() => setTokenError('Could not validate the reset link. Check your connection.'))
      .finally(() => setValidating(false));
  }, [token]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');

    if (password.length < 8) {
      setError('Password must be at least 8 characters');
      return;
    }
    if (password !== confirm) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/auth/reset-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        credentials: 'include',
        body: JSON.stringify({ token, password }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) {
        setError(data.error ?? 'Failed to reset password. Please try again.');
        return;
      }
      setDone(true);
      await queryClient.invalidateQueries({ queryKey: ['getCurrentAuthUser'] });
      setTimeout(() => navigate('/'), 1500);
    } catch {
      setError('Network error — please try again');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
      {/* Kenyan flag stripe */}
      <div className="fixed top-0 inset-x-0 h-1 flex">
        <div className="flex-1 bg-[#006600]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#CE1126]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#006600]" />
      </div>

      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center gap-3 mb-2">
          <img src="/logo.png" alt="Msafiri" className="w-16 h-16 rounded-2xl object-contain bg-white shadow" />
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight">Msafiri Founder OS</h1>
            <p className="text-sm text-muted-foreground mt-1">Set your password</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl shadow-sm p-6 space-y-4">
          {validating && (
            <p className="text-sm text-muted-foreground text-center py-4 animate-pulse">Validating link…</p>
          )}

          {!validating && tokenError && (
            <div className="space-y-4 text-center">
              <div className="w-12 h-12 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
                <svg className="w-6 h-6 text-destructive" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <p className="font-semibold">Link invalid or expired</p>
              <p className="text-sm text-muted-foreground">{tokenError}</p>
              <Link href="/forgot-password" className="text-sm text-primary font-medium hover:underline block">
                Request a new link
              </Link>
            </div>
          )}

          {!validating && !tokenError && !done && (
            <>
              <div>
                <h2 className="text-base font-semibold">Set a new password</h2>
                {email && (
                  <p className="text-sm text-muted-foreground mt-1">for <strong>{email}</strong></p>
                )}
              </div>

              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-foreground" htmlFor="password">
                    New password
                  </label>
                  <input
                    id="password"
                    type="password"
                    autoComplete="new-password"
                    required
                    minLength={8}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Min. 8 characters"
                    className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-sm font-medium text-foreground" htmlFor="confirm">
                    Confirm password
                  </label>
                  <input
                    id="confirm"
                    type="password"
                    autoComplete="new-password"
                    required
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    placeholder="Re-enter password"
                    className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                  />
                </div>

                {error && (
                  <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold hover:bg-primary/90 active:scale-[0.98] transition disabled:opacity-60"
                >
                  {loading ? 'Saving…' : 'Set password & sign in'}
                </button>
              </form>
            </>
          )}

          {done && (
            <div className="space-y-4 text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto">
                <svg className="w-6 h-6 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="font-semibold">Password set!</p>
              <p className="text-sm text-muted-foreground">Signing you in…</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
