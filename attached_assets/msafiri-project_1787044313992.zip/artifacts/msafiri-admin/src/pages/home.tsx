import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useUpdateTask, useUpdateContentItem, useUpdateFieldTrip } from "@workspace/api-client-react";
import { Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatKes } from "@/lib/utils";
import {
  AlertTriangle, CheckCircle2, MapPin, PlayCircle,
  Lightbulb, Wallet, CalendarDays, Clock, TrendingUp, ChevronRight, Zap,
  Landmark, Smartphone, ArrowRight,
} from "lucide-react";
import { AssigneeBadge } from "@/components/ui/assignee-badge";
import { TaskStatusSelect, ContentStatusSelect, TripStatusSelect } from "@/components/ui/status-select";
import type { TaskStatus, ContentStatus, TripStatus } from "@/components/ui/status-select";
import { TransactionForm } from "@/components/forms/TransactionForm";
import { TaskForm } from "@/components/forms/TaskForm";

// ── Cash position (shared with money page) ────────────────────────────────────

interface AccountBalance { account: string; balanceKes: string; }
interface CategoryTotal { category: string; totalKes: string; }
interface CashPosition {
  byAccount: AccountBalance[];
  byIncomeSource: CategoryTotal[];
  byExpenseCategory: CategoryTotal[];
}

function useCashPosition() {
  return useQuery<CashPosition>({
    queryKey: ["cash-position"],
    queryFn: async () => {
      const r = await fetch("/api/transactions/cash-position");
      if (!r.ok) throw new Error("Cash position fetch failed");
      return r.json();
    },
    refetchInterval: 60_000,
    staleTime: 30_000,
  });
}

const ACCOUNT_LABELS: Record<string, string> = {
  bank: "Bank", mpesa: "M-PESA", "mpesa till": "M-PESA Till", cash: "Cash",
};
function accountLabel(n: string) { return ACCOUNT_LABELS[n.toLowerCase()] ?? n; }
function accountIcon(n: string) {
  const key = n.toLowerCase();
  if (key === "bank") return <Landmark className="w-3.5 h-3.5" />;
  if (key === "mpesa" || key === "mpesa till") return <Smartphone className="w-3.5 h-3.5" />;
  return <Wallet className="w-3.5 h-3.5" />;
}

// ── Types ─────────────────────────────────────────────────────────────────────

interface FocusTask {
  id: number; title: string; priority: string; status: string;
  dueDate?: string | null; module?: string | null; assignedTo?: string | null;
}
interface FocusTrip {
  id: number; purpose: string; corridor?: string | null;
  date: string; status: string; totalTripCostKes?: string | null;
}
interface FocusContent {
  id: number; title: string; pillar?: string | null;
  scheduledDate?: string | null; status: string;
  angle?: string | null; hook?: string | null; isCore?: boolean | null;
}
interface FocusData {
  today: string; weekNumber: number;
  weekObjective?: string | null; weekOutcomes?: string[];
  cashKes: string; cashFloor: string; cashLow: boolean;
  overdueTasks: FocusTask[]; todayTasks: FocusTask[];
  upcomingTasks: FocusTask[]; weekTasks: FocusTask[];
  upcomingTrips: FocusTrip[]; contentDueSoon: FocusContent[];
  contentSuggestions: FocusContent[];
  nextPayment?: { name: string; amountKes: string; dueDate: string } | null;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

const PRI_COLOR: Record<string, string> = {
  critical: "bg-destructive", high: "bg-orange-500", medium: "bg-yellow-400", low: "bg-muted-foreground",
};
const PRI_LABEL: Record<string, string> = {
  critical: "Critical", high: "High", medium: "Medium", low: "Low",
};

function dayLabel(dateStr: string, today: string): string {
  const t = new Date(today + "T00:00:00");
  const d = new Date(dateStr + "T00:00:00");
  const diff = Math.round((d.getTime() - t.getTime()) / 86400000);
  if (diff === 0) return "Today";
  if (diff === 1) return "Tomorrow";
  if (diff === -1) return "Yesterday";
  if (diff < 0) return `${Math.abs(diff)}d overdue`;
  return d.toLocaleDateString("en-KE", { weekday: "short", month: "short", day: "numeric" });
}

// ── Task row with full inline status select ───────────────────────────────────

function TaskRow({ task, today, onStatusChange }: {
  task: FocusTask;
  today: string;
  onStatusChange: (id: number, status: TaskStatus) => void;
}) {
  const done = task.status === "done" || task.status === "cancelled";
  return (
    <div className={`flex items-start gap-3 py-2.5 px-1 rounded-md transition-colors ${done ? "opacity-40" : "hover:bg-accent/40"}`}>
      {/* Inline status badge — full dropdown */}
      <div className="shrink-0 mt-0.5" onClick={e => e.stopPropagation()}>
        <TaskStatusSelect
          value={task.status as TaskStatus}
          onChange={v => onStatusChange(task.id, v)}
        />
      </div>
      <div className="flex-1 min-w-0">
        <p className={`text-sm font-medium leading-snug ${done ? "line-through text-muted-foreground" : ""}`}>{task.title}</p>
        <div className="flex items-center gap-2 mt-0.5 flex-wrap">
          {task.dueDate && (
            <span className="text-xs text-muted-foreground">{dayLabel(task.dueDate, today)}</span>
          )}
          {task.module && (
            <span className="text-xs text-muted-foreground capitalize">{task.module}</span>
          )}
          {task.assignedTo && (
            <AssigneeBadge name={task.assignedTo} showName size="sm" />
          )}
        </div>
      </div>
      <div className={`mt-1.5 w-2 h-2 rounded-full shrink-0 ${PRI_COLOR[task.priority] ?? "bg-muted"}`} aria-label={PRI_LABEL[task.priority]} />
    </div>
  );
}

// ── Section header ────────────────────────────────────────────────────────────

function SectionHead({ icon, label, count, urgent }: { icon: React.ReactNode; label: string; count?: number; urgent?: boolean }) {
  return (
    <div className={`flex items-center gap-2 mb-2 pb-1.5 border-b ${urgent ? "border-destructive/30" : "border-border"}`}>
      <span className={urgent ? "text-destructive" : "text-muted-foreground"}>{icon}</span>
      <span className={`text-xs font-semibold uppercase tracking-wider ${urgent ? "text-destructive" : "text-muted-foreground"}`}>{label}</span>
      {count !== undefined && count > 0 && (
        <Badge variant={urgent ? "destructive" : "secondary"} className="ml-auto text-[10px] h-4 px-1.5">{count}</Badge>
      )}
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function Home() {
  const qc = useQueryClient();
  const [txFormOpen, setTxFormOpen] = useState(false);
  const [taskFormOpen, setTaskFormOpen] = useState(false);
  const updateTask = useUpdateTask();
  const updateContent = useUpdateContentItem();
  const updateTrip = useUpdateFieldTrip();

  const invalidateFocus = () => qc.invalidateQueries({ queryKey: ["dashboard-focus"] });

  const { data: focus, isLoading } = useQuery<FocusData>({
    queryKey: ["dashboard-focus"],
    queryFn: async () => {
      const r = await fetch("/api/dashboard/focus");
      if (!r.ok) throw new Error("Failed to load focus board");
      return r.json();
    },
    refetchInterval: 60_000,
  });

  const handleTaskStatus = (id: number, status: TaskStatus) => {
    updateTask.mutate({ id, data: { status } }, { onSuccess: invalidateFocus });
  };

  const handleContentStatus = (id: number, status: ContentStatus) => {
    updateContent.mutate({ id, data: { status } }, { onSuccess: invalidateFocus });
  };

  const handleTripStatus = (id: number, status: TripStatus) => {
    updateTrip.mutate({ id, data: { status } }, { onSuccess: invalidateFocus });
  };

  // Must be before any early return to satisfy Rules of Hooks
  const { data: cashPos } = useCashPosition();

  if (isLoading || !focus) {
    return (
      <div className="space-y-6 animate-in">
        <Skeleton className="h-12 w-64" />
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {[...Array(4)].map((_, i) => <Skeleton key={i} className="h-20" />)}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="lg:col-span-2 h-96" />
          <Skeleton className="h-96" />
        </div>
      </div>
    );
  }

  const {
    today, weekNumber, weekObjective, cashKes, cashFloor, cashLow,
    overdueTasks, todayTasks, upcomingTasks, weekTasks,
    upcomingTrips, contentDueSoon, contentSuggestions, nextPayment,
  } = focus;

  const totalActionable = overdueTasks.length + todayTasks.length;
  const dateLabel = new Date(today + "T00:00:00").toLocaleDateString("en-KE", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });

  return (
    <div className="space-y-6 animate-in">

      {/* ── Header ── */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-3 border-b pb-4">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-2xl font-bold tracking-tight">Week {weekNumber}</h1>
            {totalActionable > 0 && (
              <Badge variant="destructive" className="text-xs">{totalActionable} need action</Badge>
            )}
          </div>
          <p className="text-sm text-muted-foreground mt-0.5">{dateLabel}</p>
          {weekObjective && (
            <p className="text-xs text-muted-foreground mt-1 italic">
              🎯 {weekObjective}
            </p>
          )}
        </div>
        <div className="flex flex-wrap gap-2 shrink-0">
          <Button size="sm" className="gap-2" onClick={() => setTxFormOpen(true)}>
            <Wallet className="w-4 h-4" />
            Fund KES 10k
          </Button>
          <Button size="sm" variant="outline" className="gap-2" onClick={() => setTaskFormOpen(true)}>
            <Zap className="w-4 h-4" />
            Add Task
          </Button>
        </div>
      </div>

      {/* ── KPI strip ── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <Card className={cashLow ? "border-destructive/40 bg-destructive/5" : ""}>
          <CardHeader className="pb-1 pt-3 px-4">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Cash Balance</CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className={`text-xl font-bold font-mono ${cashLow ? "text-destructive" : ""}`}>{formatKes(cashKes)}</div>
            {cashLow && <p className="text-xs text-destructive mt-0.5">Below floor ({formatKes(cashFloor)})</p>}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-1 pt-3 px-4">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Overdue</CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className={`text-xl font-bold font-mono ${overdueTasks.length > 0 ? "text-destructive" : "text-muted-foreground"}`}>
              {overdueTasks.length}
            </div>
            <p className="text-xs text-muted-foreground">{overdueTasks.length === 0 ? "All caught up" : "tasks past due"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-1 pt-3 px-4">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Due Today</CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            <div className="text-xl font-bold font-mono">{todayTasks.length}</div>
            <p className="text-xs text-muted-foreground">{todayTasks.length === 0 ? "Clear day" : "on your plate"}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-1 pt-3 px-4">
            <CardTitle className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Next Bill</CardTitle>
          </CardHeader>
          <CardContent className="pb-3 px-4">
            {nextPayment ? (
              <>
                <div className="text-sm font-semibold truncate">{nextPayment.name}</div>
                <p className="text-xs text-muted-foreground">
                  {formatKes(nextPayment.amountKes)} · {dayLabel(nextPayment.dueDate, today)}
                </p>
              </>
            ) : (
              <div className="text-sm text-muted-foreground">None upcoming</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* ── Money snapshot ── */}
      {cashPos && (cashPos.byAccount.length > 0 || cashPos.byIncomeSource.length > 0) && (
        <Card className="border-border/60">
          <CardHeader className="py-3 px-4 border-b flex flex-row items-center justify-between">
            <CardTitle className="text-sm font-semibold flex items-center gap-2">
              <Wallet className="w-4 h-4 text-muted-foreground" />
              Money Snapshot
            </CardTitle>
            <Link href="/money" className="text-xs text-primary hover:underline flex items-center gap-0.5">
              Full view <ArrowRight className="w-3 h-3" />
            </Link>
          </CardHeader>
          <CardContent className="p-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">

              {/* Revenue sources */}
              {cashPos.byIncomeSource.length > 0 && (
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3 text-emerald-600" /> Revenue Sources
                  </p>
                  <div className="space-y-1.5">
                    {cashPos.byIncomeSource.map(s => (
                      <div key={s.category} className="flex items-center justify-between gap-4">
                        <span className="text-sm text-muted-foreground truncate">{s.category}</span>
                        <span className="font-mono text-sm font-semibold text-emerald-700 dark:text-emerald-400 shrink-0">
                          {formatKes(s.totalKes)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Where the money is */}
              {cashPos.byAccount.length > 0 && (
                <div>
                  <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-2 flex items-center gap-1">
                    <Landmark className="w-3 h-3" /> Where It Is
                  </p>
                  <div className="space-y-1.5">
                    {cashPos.byAccount.map(a => {
                      const bal = parseFloat(a.balanceKes);
                      return (
                        <div key={a.account} className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-1.5 text-muted-foreground">
                            {accountIcon(a.account)}
                            <span className="text-sm">{accountLabel(a.account)}</span>
                          </div>
                          <span className={`font-mono text-sm font-semibold shrink-0 ${bal < 0 ? "text-destructive" : ""}`}>
                            {formatKes(a.balanceKes)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Main two-column body ── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">

        {/* LEFT — Task checklist */}
        <div className="lg:col-span-2 space-y-6">

          {/* Overdue */}
          {overdueTasks.length > 0 && (
            <Card className="border-destructive/30">
              <CardContent className="pt-4 pb-3 px-4">
                <SectionHead
                  icon={<AlertTriangle className="w-3.5 h-3.5" />}
                  label="Overdue"
                  count={overdueTasks.length}
                  urgent
                />
                <div className="divide-y divide-border/50">
                  {overdueTasks.map(t => (
                    <TaskRow key={t.id} task={t} today={today} onStatusChange={handleTaskStatus} />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Today */}
          <Card>
            <CardContent className="pt-4 pb-3 px-4">
              <SectionHead
                icon={<CalendarDays className="w-3.5 h-3.5" />}
                label="Today"
                count={todayTasks.length}
              />
              {todayTasks.length > 0 ? (
                <div className="divide-y divide-border/50">
                  {todayTasks.map(t => (
                    <TaskRow key={t.id} task={t} today={today} onStatusChange={handleTaskStatus} />
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground py-2">Nothing due today — great position to be in.</p>
              )}
            </CardContent>
          </Card>

          {/* Upcoming 7 days */}
          {(upcomingTasks.length > 0 || weekTasks.length > 0) && (
            <Card>
              <CardContent className="pt-4 pb-3 px-4">
                <SectionHead
                  icon={<Clock className="w-3.5 h-3.5" />}
                  label="Next 7 Days"
                  count={upcomingTasks.length + weekTasks.length}
                />
                <div className="divide-y divide-border/50">
                  {upcomingTasks.map(t => (
                    <TaskRow key={t.id} task={t} today={today} onStatusChange={handleTaskStatus} />
                  ))}
                  {weekTasks.map(t => (
                    <TaskRow key={`wt-${t.id}`} task={t} today={today} onStatusChange={handleTaskStatus} />
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {overdueTasks.length === 0 && todayTasks.length === 0 && upcomingTasks.length === 0 && weekTasks.length === 0 && (
            <Card>
              <CardContent className="py-8 text-center">
                <CheckCircle2 className="w-10 h-10 text-primary mx-auto mb-2" />
                <p className="font-semibold">You're on top of everything</p>
                <p className="text-sm text-muted-foreground mt-1">No pending tasks for the next 7 days.</p>
                <Button size="sm" variant="outline" className="mt-4" onClick={() => setTaskFormOpen(true)}>
                  Plan ahead
                </Button>
              </CardContent>
            </Card>
          )}

          <div className="flex justify-end">
            <Button variant="ghost" size="sm" className="gap-1 text-xs text-muted-foreground" asChild>
              <Link href="/tasks">All tasks <ChevronRight className="w-3 h-3" /></Link>
            </Button>
          </div>
        </div>

        {/* RIGHT — Coming up, content, money */}
        <div className="space-y-4">

          {/* Field trips this week */}
          {upcomingTrips.length > 0 && (
            <Card>
              <CardContent className="pt-4 pb-3 px-4">
                <SectionHead icon={<MapPin className="w-3.5 h-3.5" />} label="Field Trips" count={upcomingTrips.length} />
                <div className="space-y-3">
                  {upcomingTrips.map(trip => (
                    <div key={trip.id} className="text-sm border-b border-border/40 pb-2.5 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-medium leading-snug flex-1">{trip.purpose}</p>
                        <div onClick={e => e.stopPropagation()}>
                          <TripStatusSelect
                            value={trip.status as TripStatus}
                            onChange={v => handleTripStatus(trip.id, v)}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mt-1 text-muted-foreground text-xs flex-wrap">
                        <span>{dayLabel(trip.date, today)}</span>
                        {trip.corridor && <span>· {trip.corridor}</span>}
                        {trip.totalTripCostKes && parseFloat(trip.totalTripCostKes) > 0 && (
                          <span className="ml-auto font-mono">{formatKes(trip.totalTripCostKes)}</span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="ghost" size="sm" className="mt-2 gap-1 text-xs text-muted-foreground w-full justify-end" asChild>
                  <Link href="/field">View all <ChevronRight className="w-3 h-3" /></Link>
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Content due soon */}
          {contentDueSoon.length > 0 && (
            <Card>
              <CardContent className="pt-4 pb-3 px-4">
                <SectionHead icon={<PlayCircle className="w-3.5 h-3.5" />} label="Post Soon" count={contentDueSoon.length} />
                <div className="space-y-3">
                  {contentDueSoon.map(c => (
                    <div key={c.id} className="text-sm border-b border-border/40 pb-2.5 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between gap-2">
                        <p className="font-medium leading-snug flex-1 truncate">{c.title}</p>
                        <div className="shrink-0" onClick={e => e.stopPropagation()}>
                          <ContentStatusSelect
                            value={c.status as ContentStatus}
                            onChange={v => handleContentStatus(c.id, v)}
                          />
                        </div>
                      </div>
                      <div className="flex items-center gap-1.5 mt-1 text-muted-foreground text-xs">
                        {c.scheduledDate && <span>{dayLabel(c.scheduledDate, today)}</span>}
                        {c.pillar && <span className="truncate">· {c.pillar}</span>}
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="ghost" size="sm" className="mt-2 gap-1 text-xs text-muted-foreground w-full justify-end" asChild>
                  <Link href="/content">Content board <ChevronRight className="w-3 h-3" /></Link>
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Content suggestions */}
          {contentSuggestions.length > 0 && (
            <Card>
              <CardContent className="pt-4 pb-3 px-4">
                <SectionHead icon={<Lightbulb className="w-3.5 h-3.5" />} label="Idea Bank Picks" />
                <div className="space-y-3">
                  {contentSuggestions.map(c => (
                    <div key={c.id} className="text-sm border-b border-border/50 pb-2 last:border-0 last:pb-0">
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-1.5 flex-1 min-w-0">
                          {c.isCore && <TrendingUp className="w-3 h-3 text-primary mt-0.5 shrink-0" aria-label="Core content" />}
                          <p className="font-medium leading-snug">{c.title}</p>
                        </div>
                        <div className="shrink-0" onClick={e => e.stopPropagation()}>
                          <ContentStatusSelect
                            value={c.status as ContentStatus}
                            onChange={v => handleContentStatus(c.id, v)}
                          />
                        </div>
                      </div>
                      {c.angle && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{c.angle}</p>}
                      {c.pillar && <span className="text-[10px] text-muted-foreground">{c.pillar}</span>}
                    </div>
                  ))}
                </div>
                <Button variant="ghost" size="sm" className="mt-2 gap-1 text-xs text-muted-foreground w-full justify-end" asChild>
                  <Link href="/content">Idea Bank <ChevronRight className="w-3 h-3" /></Link>
                </Button>
              </CardContent>
            </Card>
          )}

          {/* Cash snapshot */}
          <Card>
            <CardContent className="pt-4 pb-3 px-4">
              <SectionHead icon={<Wallet className="w-3.5 h-3.5" />} label="Cash" />
              <div className="space-y-2 text-sm">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Operating</span>
                  <span className={`font-mono font-semibold ${cashLow ? "text-destructive" : ""}`}>{formatKes(cashKes)}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Safety floor</span>
                  <span className="font-mono text-muted-foreground">{formatKes(cashFloor)}</span>
                </div>
                {nextPayment && (
                  <div className="flex justify-between items-center border-t border-border/50 pt-2 mt-2">
                    <span className="text-muted-foreground truncate pr-2">{nextPayment.name}</span>
                    <span className="font-mono text-xs shrink-0">−{formatKes(nextPayment.amountKes)}</span>
                  </div>
                )}
                <Button
                  size="sm"
                  variant="outline"
                  className="w-full mt-2 gap-1 text-xs"
                  onClick={() => setTxFormOpen(true)}
                >
                  <Wallet className="w-3.5 h-3.5" />
                  Log transaction
                </Button>
              </div>
            </CardContent>
          </Card>

        </div>
      </div>

      {/* Forms */}
      <TransactionForm open={txFormOpen} onClose={() => setTxFormOpen(false)} defaultAmount="10000" defaultType="income" defaultDescription="Friday Funding" />
      <TaskForm open={taskFormOpen} onClose={() => setTaskFormOpen(false)} />
    </div>
  );
}
