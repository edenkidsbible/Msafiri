import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useGetSubscriptionSummary, useListSubscriptionMetrics } from "@workspace/api-client-react";
import type { SubscriptionWeekMetric } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { formatKes, formatNumber } from "@/lib/utils";
import { Users, TrendingUp, UserMinus, PlusCircle, Pencil, RefreshCw, Zap, WifiOff } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { SubscriptionMetricForm } from "@/components/forms/SubscriptionMetricForm";

// ── RC types ──────────────────────────────────────────────────────────────────

interface RcOverview {
  activeTrials: number;
  activeSubscriptions: number;
  mrrUsd: number;
  revenue28dUsd: number;
  mrrKes: number;
  revenue28dKes: number;
  exchangeRate: number;
  newCustomers28d: number;
  activeUsers28d: number;
  updatedAt: string;
}

interface RcBreakdown {
  weeklyPaid: number;
  monthlyPaid: number;
  weeklyTrial: number;
  monthlyTrial: number;
  updatedAt: string;
}

// ── Hooks ─────────────────────────────────────────────────────────────────────

function useRcOverview() {
  return useQuery<RcOverview>({
    queryKey: ["rc-overview"],
    queryFn: async () => {
      const r = await fetch("/api/revenuecat/overview");
      if (!r.ok) throw new Error("RevenueCat overview fetch failed");
      return r.json();
    },
    refetchInterval: 60_000,
    retry: 1,
  });
}

function useRcBreakdown() {
  return useQuery<RcBreakdown>({
    queryKey: ["rc-breakdown"],
    queryFn: async () => {
      const r = await fetch("/api/revenuecat/breakdown");
      if (!r.ok) throw new Error("RevenueCat breakdown fetch failed");
      return r.json();
    },
    refetchInterval: 60_000,
    retry: 1,
  });
}

// ── UI helpers ────────────────────────────────────────────────────────────────

function LiveBadge() {
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wider text-emerald-600 dark:text-emerald-400">
      <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
      Live
    </span>
  );
}

function Stat({ label, value, sub, highlight }: { label: string; value: string | number; sub?: string; highlight?: boolean }) {
  return (
    <div className="space-y-0.5">
      <p className="text-[10px] uppercase tracking-wide font-medium text-muted-foreground">{label}</p>
      <p className={`text-xl font-bold tabular-nums leading-none ${highlight ? "text-emerald-700 dark:text-emerald-400" : ""}`}>
        {typeof value === "number" ? formatNumber(value) : value}
      </p>
      {sub && <p className="text-xs text-muted-foreground">{sub}</p>}
    </div>
  );
}

/** Mini weekly/monthly split indicator */
function DurationSplit({ weekly, monthly, label }: { weekly: number; monthly: number; label: string }) {
  const total = weekly + monthly;
  return (
    <div className="space-y-1">
      <p className="text-[10px] uppercase tracking-wide font-medium text-muted-foreground">{label}</p>
      <div className="flex items-baseline gap-2">
        <span className="text-lg font-bold tabular-nums">{total}</span>
        {total > 0 && (
          <span className="text-xs text-muted-foreground tabular-nums">
            {weekly}w · {monthly}m
          </span>
        )}
      </div>
      {total > 0 && (
        <div className="flex h-1 rounded-full overflow-hidden bg-muted w-24">
          <div
            className="bg-emerald-500 transition-all"
            style={{ width: `${(weekly / total) * 100}%` }}
          />
          <div className="bg-blue-400 flex-1" />
        </div>
      )}
    </div>
  );
}

// ── RC Live Panel ─────────────────────────────────────────────────────────────

function RcLivePanel({ onSyncClick }: { onSyncClick: (rc: RcOverview) => void }) {
  const { data, isLoading, isError, refetch, isFetching } = useRcOverview();
  const { data: breakdown } = useRcBreakdown();

  if (isLoading) {
    return (
      <Card className="border-dashed">
        <CardContent className="p-4 flex items-center gap-3">
          <RefreshCw className="w-4 h-4 animate-spin text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Connecting to RevenueCat…</span>
        </CardContent>
      </Card>
    );
  }

  if (isError || !data) {
    return (
      <Card className="border-dashed border-destructive/30">
        <CardContent className="p-4 flex items-center gap-3">
          <WifiOff className="w-4 h-4 text-destructive/60" />
          <span className="text-sm text-muted-foreground">Could not reach RevenueCat.</span>
          <Button size="sm" variant="ghost" onClick={() => refetch()}>Retry</Button>
        </CardContent>
      </Card>
    );
  }

  const ts = data.updatedAt ? new Date(data.updatedAt).toLocaleTimeString("en-KE", { hour: "2-digit", minute: "2-digit" }) : "";
  const hasBreakdown = breakdown && (breakdown.weeklyPaid + breakdown.monthlyPaid + breakdown.weeklyTrial + breakdown.monthlyTrial) > 0;

  return (
    <Card className="border-emerald-200 dark:border-emerald-900/40 bg-emerald-50/50 dark:bg-emerald-950/20">
      <CardHeader className="py-3 px-4 border-b border-emerald-100 dark:border-emerald-900/30 flex flex-row items-center justify-between">
        <div className="flex items-center gap-2">
          <Zap className="w-4 h-4 text-emerald-600" />
          <CardTitle className="text-sm font-semibold text-emerald-700 dark:text-emerald-400">RevenueCat — Live</CardTitle>
          <LiveBadge />
        </div>
        <div className="flex items-center gap-2">
          {ts && <span className="text-[10px] text-muted-foreground">Updated {ts}</span>}
          <button
            onClick={() => refetch()}
            disabled={isFetching}
            className="p-1 rounded hover:bg-emerald-100 dark:hover:bg-emerald-900/30 text-emerald-600 disabled:opacity-40"
            title="Refresh"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isFetching ? "animate-spin" : ""}`} />
          </button>
        </div>
      </CardHeader>
      <CardContent className="p-4 space-y-4">

        {/* Subscribers + trials — with weekly/monthly split */}
        <div>
          <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">Subscribers &amp; Trials</p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {hasBreakdown ? (
              <>
                <DurationSplit
                  weekly={breakdown!.weeklyPaid}
                  monthly={breakdown!.monthlyPaid}
                  label="Active Paid"
                />
                <DurationSplit
                  weekly={breakdown!.weeklyTrial}
                  monthly={breakdown!.monthlyTrial}
                  label="Active Trials"
                />
              </>
            ) : (
              <>
                <Stat label="Active Paid" value={data.activeSubscriptions} highlight />
                <Stat label="Active Trials" value={data.activeTrials} />
              </>
            )}
            <Stat label="New Customers (28d)" value={data.newCustomers28d} />
            <Stat label="Active Users (28d)" value={data.activeUsers28d} />
          </div>
          {hasBreakdown && (
            <p className="text-[10px] text-muted-foreground mt-2">
              <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 mr-1" />weekly &nbsp;
              <span className="inline-block w-2 h-2 rounded-full bg-blue-400 mr-1" />monthly
            </p>
          )}
        </div>

        {/* Revenue — with KES conversion */}
        <div className="border-t border-emerald-100 dark:border-emerald-900/30 pt-4">
          <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">
            Revenue (28d) · 1 USD = {formatKes(String(data.exchangeRate))}
          </p>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-0.5">
              <p className="text-[10px] uppercase tracking-wide font-medium text-muted-foreground">Gross Revenue</p>
              <p className="text-xl font-bold tabular-nums">{formatKes(String(data.mrrKes))}</p>
              <p className="text-xs text-muted-foreground">${data.mrrUsd.toFixed(2)} · before store cut</p>
            </div>
            <div className="space-y-0.5">
              <p className="text-[10px] uppercase tracking-wide font-medium text-muted-foreground">Net Revenue</p>
              <p className="text-xl font-bold tabular-nums text-emerald-700 dark:text-emerald-400">{formatKes(String(data.revenue28dKes))}</p>
              <p className="text-xs text-muted-foreground">${data.revenue28dUsd.toFixed(2)} · after store cut</p>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between pt-1">
          <p className="text-xs text-muted-foreground">
            iOS + Android combined · Rate from Settings
          </p>
          <Button
            size="sm"
            variant="outline"
            className="border-emerald-300 text-emerald-700 hover:bg-emerald-100 dark:border-emerald-800 dark:text-emerald-400"
            onClick={() => onSyncClick(data)}
          >
            <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
            Pre-fill weekly log
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// ── Page ──────────────────────────────────────────────────────────────────────

export default function Subscriptions() {
  const [formOpen, setFormOpen] = useState(false);
  const [editingMetric, setEditingMetric] = useState<SubscriptionWeekMetric | undefined>(undefined);
  const [prefill, setPrefill] = useState<Partial<{ activePaidEnd: number; trialsStarted: number }>>({});

  const { data: summary, isLoading: loadingSum } = useGetSubscriptionSummary();
  const { data: metrics, isLoading: loadingMetrics } = useListSubscriptionMetrics();
  // Share the same cache key as RcLivePanel — no double-fetch
  const { data: rcLive } = useRcOverview();

  const openCreate = () => {
    setEditingMetric(undefined);
    setPrefill({});
    setFormOpen(true);
  };

  const openEdit = (m: SubscriptionWeekMetric) => {
    setEditingMetric(m);
    setPrefill({});
    setFormOpen(true);
  };

  const handleRcSync = (rc: RcOverview) => {
    setEditingMetric(undefined);
    setPrefill({
      activePaidEnd: rc.activeSubscriptions,
      trialsStarted: rc.activeTrials,
    });
    setFormOpen(true);
  };

  const handleClose = () => {
    setFormOpen(false);
    setEditingMetric(undefined);
    setPrefill({});
  };

  if (loadingSum || loadingMetrics) {
    return <div className="p-8 space-y-6"><Skeleton className="h-10 w-48"/><Skeleton className="h-64 w-full"/></div>;
  }

  const chartData = [...(summary?.trend || [])].reverse().map(w => ({
    name: `W${w.weekNumber}`,
    activePaid: w.activePaidEnd,
    mrr: parseFloat(w.mrrKes || "0")
  }));

  return (
    <div className="space-y-8 animate-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Users & Revenue</h1>
          <p className="text-muted-foreground mt-1">Growth and retention metrics.</p>
        </div>
        <Button onClick={openCreate}><PlusCircle className="w-4 h-4 mr-2" /> Log Weekly Metrics</Button>
      </div>

      {/* Live RevenueCat panel */}
      <RcLivePanel onSyncClick={handleRcSync} />

      {(() => {
        // Prefer DB-logged summary; fall back to live RC data when no weekly metrics exist yet
        const hasLoggedData = (summary?.currentActivePaid ?? 0) > 0 || (summary?.currentMrrKes && parseFloat(summary.currentMrrKes) > 0);
        const activePaid = hasLoggedData ? (summary?.currentActivePaid ?? 0) : (rcLive?.activeSubscriptions ?? 0);
        const mrrKes = hasLoggedData ? summary?.currentMrrKes : (rcLive ? String(rcLive.mrrKes) : undefined);
        const rcSource = !hasLoggedData && !!rcLive;

        return (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Active Paid</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-primary">{formatNumber(activePaid)}</div>
                <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                  <Users className="w-3 h-3" />
                  {rcSource ? "Live from RevenueCat" : "Total active subscriptions"}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Current MRR</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold font-mono">{formatKes(mrrKes)}</div>
                <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                  <TrendingUp className="w-3 h-3" />
                  {rcSource ? "Gross · live from RevenueCat" : "Monthly run rate"}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Latest Churn</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">
                  {summary?.latestChurnRate != null ? `${(summary.latestChurnRate * 100).toFixed(1)}%` : '--'}
                </div>
                <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                  <UserMinus className="w-3 h-3" /> Weekly churn rate
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground uppercase">Cumulative Sales</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold font-mono">{formatKes(summary?.cumulativeGrossSalesKes)}</div>
                <p className="text-xs text-muted-foreground mt-1">All-time gross revenue</p>
              </CardContent>
            </Card>
          </div>
        );
      })()}

      <Card>
        <CardHeader>
          <CardTitle>Active Paid Subscribers Trend</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[350px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e5e7eb" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis yAxisId="left" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} />
                <YAxis yAxisId="right" orientation="right" axisLine={false} tickLine={false} tick={{ fontSize: 12 }} tickFormatter={(val) => `${(val/1000).toFixed(0)}k`} />
                <Tooltip 
                  contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ fontWeight: 'bold', color: '#111827', marginBottom: '4px' }}
                />
                <Legend />
                <Line yAxisId="left" type="monotone" dataKey="activePaid" name="Active Paid" stroke="hsl(16, 100%, 45%)" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                <Line yAxisId="right" type="monotone" dataKey="mrr" name="MRR (KES)" stroke="hsl(150, 60%, 40%)" strokeWidth={2} strokeDasharray="5 5" dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        <h3 className="text-lg font-bold">Weekly Log</h3>
        <div className="bg-card border rounded-lg overflow-x-auto">
          <table className="w-full text-sm min-w-[800px]">
            <thead className="bg-muted/50 border-b">
              <tr>
                <th className="text-left font-medium p-3 text-muted-foreground whitespace-nowrap">Week</th>
                <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap">Downloads</th>
                <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap">Trials</th>
                <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap">New Paid</th>
                <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap">Cancellations</th>
                <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap bg-muted">Active End</th>
                <th className="text-right font-medium p-3 text-muted-foreground whitespace-nowrap">Net Revenue</th>
                <th className="w-10 p-3"></th>
              </tr>
            </thead>
            <tbody>
              {metrics?.map(m => (
                <tr key={m.id} className="border-b last:border-0 hover:bg-muted/20 group">
                  <td className="p-3 font-medium">W{m.weekNumber} <span className="text-xs text-muted-foreground font-normal ml-2">{new Date(m.periodStartDate).toLocaleDateString()}</span></td>
                  <td className="p-3 text-right font-mono">{formatNumber(m.newDownloads)}</td>
                  <td className="p-3 text-right font-mono">{formatNumber(m.trialsStarted)}</td>
                  <td className="p-3 text-right font-mono text-emerald-600">+{formatNumber(m.newPaid)}</td>
                  <td className="p-3 text-right font-mono text-destructive">{m.cancellations ? `-${m.cancellations}` : '0'}</td>
                  <td className="p-3 text-right font-mono font-bold bg-muted/30">{formatNumber(m.activePaidEnd)}</td>
                  <td className="p-3 text-right font-mono text-muted-foreground">{formatKes(m.netAccruedRevenueKes)}</td>
                  <td className="p-3">
                    <button
                      onClick={() => openEdit(m)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-muted"
                      title="Edit"
                    >
                      <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                  </td>
                </tr>
              ))}
              {!metrics?.length && (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-muted-foreground">
                    No weekly metrics recorded yet.{" "}
                    <button className="text-primary underline hover:no-underline" onClick={openCreate}>Log this week</button>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <SubscriptionMetricForm open={formOpen} onClose={handleClose} metric={editingMetric} prefill={prefill} />
    </div>
  );
}
