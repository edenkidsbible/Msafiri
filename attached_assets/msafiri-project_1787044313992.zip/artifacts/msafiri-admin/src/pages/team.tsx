import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { 
  useListTeamMembers, 
  useListDepartments, 
  useDeleteTeamMember, 
  useDeleteDepartment,
  useGetCurrentAuthUser,
  getListTeamMembersQueryKey,
  getListDepartmentsQueryKey,
  type TeamMemberWithUser,
  type Department
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Building, Users, MoreHorizontal, Pencil, Trash2, Mail, Clock, CheckCircle2, MessageSquare, Link2, AlertCircle } from "lucide-react";
import { toast } from "sonner";
import { format } from "date-fns";

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";

import { TeamMemberForm } from "@/components/forms/TeamMemberForm";
import { DepartmentForm } from "@/components/forms/DepartmentForm";
import { InviteForm } from "@/components/forms/InviteForm";

const ROLE_BADGE_COLORS: Record<string, string> = {
  owner: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
  admin: "bg-amber-500 text-white hover:bg-amber-600",
  member: "bg-primary text-primary-foreground hover:bg-primary/90",
  viewer: "bg-muted text-muted-foreground hover:bg-muted/80",
};

// ─── Invitations Tab ──────────────────────────────────────────────────────────

const BASE_URL = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, "") ?? "";

interface InvitationRow {
  id: number;
  email: string;
  role: string;
  departmentId: number | null;
  departmentName: string | null;
  status: string;
  expiresAt: string;
  createdAt: string;
}

function InvitationsTabContent({ onInvite }: { onInvite: () => void }) {
  const [invitations, setInvitations] = useState<InvitationRow[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/invitations`, { credentials: "include" });
      if (res.ok) setInvitations(await res.json());
    } finally {
      setLoading(false);
    }
  };

  const revoke = async (id: number) => {
    await fetch(`${BASE_URL}/api/invitations/${id}`, { method: "DELETE", credentials: "include" });
    setInvitations((prev) => prev.map((i) => i.id === id ? { ...i, status: "revoked" } : i));
  };

  const resend = async (inv: InvitationRow) => {
    // Revoke the existing pending invitation, then create a fresh one (which re-sends the email)
    await fetch(`${BASE_URL}/api/invitations/${inv.id}`, { method: "DELETE", credentials: "include" });
    const res = await fetch(`${BASE_URL}/api/invitations`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email: inv.email, role: inv.role, departmentId: inv.departmentId }),
      credentials: "include",
    });
    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      toast.error(err.error || "Failed to resend invitation");
      return;
    }
    const result = await res.json().catch(() => ({}));
    if (result.emailDelivered === false) {
      toast.warning(`Invitation recreated for ${inv.email}, but email delivery failed. Check RESEND_API_KEY and RESEND_FROM.`, { duration: 8000 });
    } else {
      toast.success(`Invitation resent to ${inv.email}`);
    }
    await load();
  };

  // Load on mount
  useState(() => { load(); });

  if (loading) return <Skeleton className="h-48 w-full" />;

  const STATUS_BADGE: Record<string, string> = {
    pending: "bg-amber-100 text-amber-700",
    accepted: "bg-green-100 text-green-700",
    expired: "bg-muted text-muted-foreground",
    revoked: "bg-muted text-muted-foreground",
  };

  return (
    <div className="space-y-4">
      {invitations.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-16 gap-3 border rounded-lg bg-muted/30">
          <Mail className="w-8 h-8 text-muted-foreground/40" />
          <p className="text-muted-foreground text-sm">No invitations sent yet.</p>
          <Button onClick={onInvite} size="sm">
            <Plus className="w-4 h-4 mr-2" /> Send First Invitation
          </Button>
        </div>
      ) : (
        <Card className="border shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 border-b">
                <tr>
                  <th className="text-left font-medium p-4 text-muted-foreground">Email</th>
                  <th className="text-left font-medium p-4 text-muted-foreground w-28">Role</th>
                  <th className="text-left font-medium p-4 text-muted-foreground w-40">Department</th>
                  <th className="text-left font-medium p-4 text-muted-foreground w-24">Status</th>
                  <th className="text-left font-medium p-4 text-muted-foreground hidden md:table-cell">Sent</th>
                  <th className="text-right font-medium p-4 text-muted-foreground w-16"></th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {invitations.map((inv) => (
                  <tr key={inv.id} className="hover:bg-muted/20 transition-colors">
                    <td className="p-4 font-medium">{inv.email}</td>
                    <td className="p-4">
                      <Badge className={ROLE_BADGE_COLORS[inv.role] || ""} variant="secondary">
                        {inv.role}
                      </Badge>
                    </td>
                    <td className="p-4 text-muted-foreground">{inv.departmentName ?? "—"}</td>
                    <td className="p-4">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_BADGE[inv.status] || ""}`}>
                        {inv.status === "accepted" && <CheckCircle2 className="w-3 h-3" />}
                        {inv.status === "pending" && <Clock className="w-3 h-3" />}
                        {inv.status}
                      </span>
                    </td>
                    <td className="p-4 text-muted-foreground hidden md:table-cell text-xs">
                      {format(new Date(inv.createdAt), "dd MMM yyyy")}
                    </td>
                    <td className="p-4 text-right">
                      {inv.status === "pending" && (
                        <div className="flex items-center justify-end gap-1">
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-muted-foreground hover:text-foreground"
                            onClick={() => resend(inv)}
                            title="Revoke and resend the invitation email"
                          >
                            Resend
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-destructive hover:text-destructive hover:bg-destructive/10"
                            onClick={() => revoke(inv.id)}
                          >
                            Revoke
                          </Button>
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

export default function Team() {
  const queryClient = useQueryClient();
  const { data: auth, isLoading: loadingAuth } = useGetCurrentAuthUser();
  const { data: members, isLoading: loadingMembers } = useListTeamMembers();
  const { data: departments, isLoading: loadingDepartments } = useListDepartments();
  
  const deleteMember = useDeleteTeamMember();
  const deleteDepartment = useDeleteDepartment();

  const [activeTab, setActiveTab] = useState("members");
  
  // Forms state
  const [memberFormOpen, setMemberFormOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<TeamMemberWithUser | undefined>();
  
  const [deptFormOpen, setDeptFormOpen] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | undefined>();

  const [inviteFormOpen, setInviteFormOpen] = useState(false);

  // Delete dialogs state
  const [memberToDelete, setMemberToDelete] = useState<TeamMemberWithUser | null>(null);
  const [deptToDelete, setDeptToDelete] = useState<Department | null>(null);

  const [, setLocation] = useLocation();
  const isOwnerOrAdmin = auth?.role === "owner" || auth?.role === "admin";

  // Generate login link for a user who has no password
  const [generatedLink, setGeneratedLink] = useState<{ name: string; url: string } | null>(null);
  const [generatingFor, setGeneratingFor] = useState<string | null>(null);

  const generateLoginLink = useCallback(async (member: TeamMemberWithUser) => {
    setGeneratingFor(member.userId);
    try {
      const res = await fetch(`${BASE_URL}/api/auth/admin/generate-reset-link`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ userId: member.userId }),
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        toast.error(err.error ?? "Failed to generate link");
        return;
      }
      const { token } = await res.json();
      const origin = window.location.origin;
      const base = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, "") ?? "";
      const url = `${origin}${base}/reset-password?token=${encodeURIComponent(token)}`;
      const displayName = member.firstName ? `${member.firstName} ${member.lastName || ""}`.trim() : (member.email || "User");
      setGeneratedLink({ name: displayName, url });
    } catch {
      toast.error("Network error generating link");
    } finally {
      setGeneratingFor(null);
    }
  }, []);
  const isLoading = loadingAuth || loadingMembers || loadingDepartments;

  const startDm = async (targetUserId: string) => {
    try {
      const res = await fetch(`${BASE_URL}/api/chat/conversations`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participantUserId: targetUserId }),
      });
      if (!res.ok) throw new Error("Failed to start conversation");
      const { id } = await res.json();
      setLocation(`/chat?dm=${id}`);
    } catch {
      toast.error("Could not open conversation");
    }
  };

  const openNewMember = () => {
    setEditingMember(undefined);
    setMemberFormOpen(true);
  };

  const openEditMember = (member: TeamMemberWithUser) => {
    setEditingMember(member);
    setMemberFormOpen(true);
  };

  const openNewDept = () => {
    setEditingDept(undefined);
    setDeptFormOpen(true);
  };

  const openEditDept = (dept: Department) => {
    setEditingDept(dept);
    setDeptFormOpen(true);
  };

  const handleConfirmDeleteMember = () => {
    if (!memberToDelete) return;
    deleteMember.mutate({ id: memberToDelete.id }, {
      onSuccess: () => {
        toast.success("Team member removed");
        queryClient.invalidateQueries({ queryKey: getListTeamMembersQueryKey() });
        setMemberToDelete(null);
      },
      onError: () => {
        toast.error("Failed to remove team member");
        setMemberToDelete(null);
      }
    });
  };

  const handleConfirmDeleteDept = () => {
    if (!deptToDelete) return;
    deleteDepartment.mutate({ id: deptToDelete.id }, {
      onSuccess: () => {
        toast.success("Department deleted");
        queryClient.invalidateQueries({ queryKey: getListDepartmentsQueryKey() });
        setDeptToDelete(null);
      },
      onError: (err: any) => {
        toast.error(err.response?.data?.error || "Failed to delete department");
        setDeptToDelete(null);
      }
    });
  };

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-10 w-[300px]" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const deptCounts = members?.reduce((acc, m) => {
    if (m.departmentId) {
      acc[m.departmentId] = (acc[m.departmentId] || 0) + 1;
    }
    return acc;
  }, {} as Record<number, number>) || {};

  return (
    <div className="space-y-6 animate-in fade-in-50">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Team Management</h1>
          <p className="text-muted-foreground mt-1 flex items-center gap-2">
            Manage organization roster and departments.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {auth?.role && (
            <Badge variant="outline" className="mr-2 border-primary/20 text-primary bg-primary/5">
              You are {auth.role.charAt(0).toUpperCase() + auth.role.slice(1)}
            </Badge>
          )}
          {isOwnerOrAdmin && activeTab === "members" && (
            <Button onClick={openNewMember} variant="outline">
              <Plus className="w-4 h-4 mr-2" /> Add Existing
            </Button>
          )}
          {isOwnerOrAdmin && (activeTab === "members" || activeTab === "invitations") && (
            <Button onClick={() => setInviteFormOpen(true)}>
              <Mail className="w-4 h-4 mr-2" /> Invite by Email
            </Button>
          )}
          {isOwnerOrAdmin && activeTab === "departments" && (
            <Button onClick={openNewDept}>
              <Plus className="w-4 h-4 mr-2" /> Add Department
            </Button>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full space-y-6">
        <TabsList className="grid w-full max-w-lg grid-cols-3">
          <TabsTrigger value="members" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Members
          </TabsTrigger>
          <TabsTrigger value="departments" className="flex items-center gap-2">
            <Building className="w-4 h-4" />
            Departments
          </TabsTrigger>
          {isOwnerOrAdmin && (
            <TabsTrigger value="invitations" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Invitations
            </TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="members" className="m-0">
          <Card className="border shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b">
                  <tr>
                    <th className="text-left font-medium p-4 text-muted-foreground">Team Member</th>
                    <th className="text-left font-medium p-4 text-muted-foreground w-32">Role</th>
                    <th className="text-left font-medium p-4 text-muted-foreground w-40">Department</th>
                    <th className="text-left font-medium p-4 text-muted-foreground w-28">Status</th>
                    <th className="text-left font-medium p-4 text-muted-foreground hidden lg:table-cell">Added</th>
                    <th className="text-right font-medium p-4 text-muted-foreground w-16"></th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {members?.map((member) => {
                    const displayName = member.firstName ? `${member.firstName} ${member.lastName || ''}`.trim() : (member.username || member.email || "Unknown");
                    const roleColor = ROLE_BADGE_COLORS[member.role] || ROLE_BADGE_COLORS.viewer;
                    
                    return (
                      <tr key={member.id} className="hover:bg-muted/30 transition-colors">
                        <td className="p-4">
                          <div className="flex items-center gap-3">
                            <Avatar className="h-9 w-9">
                              <AvatarImage src={member.profileImageUrl || ""} alt={displayName} />
                              <AvatarFallback>{displayName.charAt(0).toUpperCase()}</AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">{displayName}</div>
                              <div className="text-xs text-muted-foreground truncate max-w-[200px] sm:max-w-[300px]">
                                {member.email || `@${member.username}`}
                              </div>
                            </div>
                          </div>
                        </td>
                        <td className="p-4">
                          <Badge variant="secondary" className={roleColor}>
                            {member.role.charAt(0).toUpperCase() + member.role.slice(1)}
                          </Badge>
                        </td>
                        <td className="p-4 text-muted-foreground">
                          {member.departmentName ? (
                            <span className="inline-flex items-center rounded-full bg-secondary px-2 py-1 text-xs font-medium">
                              {member.departmentName}
                            </span>
                          ) : (
                            "—"
                          )}
                        </td>
                        <td className="p-4">
                          <Badge variant={member.isActive ? "default" : "secondary"} className={!member.isActive ? "opacity-50" : "bg-emerald-500 hover:bg-emerald-600"}>
                            {member.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </td>
                        <td className="p-4 text-muted-foreground text-xs hidden lg:table-cell">
                          {member.createdAt ? format(new Date(member.createdAt), "MMM d, yyyy") : "—"}
                        </td>
                        <td className="p-4 text-right">
                          <div className="flex items-center justify-end gap-1">
                            {auth?.role !== "viewer" && auth?.id !== member.userId && (
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 gap-1.5 text-muted-foreground hover:text-primary"
                                onClick={() => startDm(member.userId)}
                              >
                                <MessageSquare className="h-3.5 w-3.5" />
                                <span className="hidden sm:inline">Message</span>
                              </Button>
                            )}
                            {isOwnerOrAdmin && (
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" className="h-8 w-8 p-0">
                                    <span className="sr-only">Open menu</span>
                                    <MoreHorizontal className="h-4 w-4" />
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuLabel>Actions</DropdownMenuLabel>
                                  <DropdownMenuItem onClick={() => openEditMember(member)}>
                                    <Pencil className="mr-2 h-4 w-4" /> Edit details
                                  </DropdownMenuItem>
                                  <DropdownMenuItem
                                    onClick={() => generateLoginLink(member)}
                                    disabled={generatingFor === member.userId}
                                  >
                                    <Link2 className="mr-2 h-4 w-4" />
                                    {generatingFor === member.userId ? "Generating…" : "Generate login link"}
                                  </DropdownMenuItem>
                                  <DropdownMenuSeparator />
                                  <DropdownMenuItem 
                                    className="text-destructive focus:text-destructive"
                                    onClick={() => setMemberToDelete(member)}
                                    disabled={auth?.id === member.userId} // Can't delete self
                                  >
                                    <Trash2 className="mr-2 h-4 w-4" /> Remove member
                                  </DropdownMenuItem>
                                </DropdownMenuContent>
                              </DropdownMenu>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {!members?.length && (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-muted-foreground">
                        No team members found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="departments" className="m-0">
          <Card className="border shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 border-b">
                  <tr>
                    <th className="text-left font-medium p-4 text-muted-foreground">Department</th>
                    <th className="text-left font-medium p-4 text-muted-foreground w-28">Status</th>
                    <th className="text-right font-medium p-4 text-muted-foreground w-24">Members</th>
                    <th className="text-right font-medium p-4 text-muted-foreground hidden sm:table-cell w-32">Updated</th>
                    {isOwnerOrAdmin && <th className="text-right font-medium p-4 text-muted-foreground w-16"></th>}
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {departments?.map((dept) => (
                    <tr key={dept.id} className="hover:bg-muted/30 transition-colors">
                      <td className="p-4">
                        <div className="font-medium text-base">{dept.name}</div>
                        {dept.description && (
                          <div className="text-xs text-muted-foreground mt-1 truncate max-w-md">
                            {dept.description}
                          </div>
                        )}
                      </td>
                      <td className="p-4">
                        <Badge variant={dept.isActive ? "default" : "secondary"} className={!dept.isActive ? "opacity-50" : ""}>
                          {dept.isActive ? "Active" : "Inactive"}
                        </Badge>
                      </td>
                      <td className="p-4 text-right font-medium">
                        {deptCounts[dept.id] || 0}
                      </td>
                      <td className="p-4 text-right text-muted-foreground text-xs hidden sm:table-cell">
                        {dept.updatedAt ? format(new Date(dept.updatedAt), "MMM d") : "—"}
                      </td>
                      {isOwnerOrAdmin && (
                        <td className="p-4 text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" className="h-8 w-8 p-0">
                                <span className="sr-only">Open menu</span>
                                <MoreHorizontal className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEditDept(dept)}>
                                <Pencil className="mr-2 h-4 w-4" /> Edit department
                              </DropdownMenuItem>
                              <DropdownMenuSeparator />
                              <DropdownMenuItem 
                                className="text-destructive focus:text-destructive"
                                onClick={() => setDeptToDelete(dept)}
                                disabled={(deptCounts[dept.id] || 0) > 0}
                              >
                                <Trash2 className="mr-2 h-4 w-4" /> Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      )}
                    </tr>
                  ))}
                  {!departments?.length && (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-muted-foreground">
                        No departments found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </Card>
        </TabsContent>

        {isOwnerOrAdmin && (
          <TabsContent value="invitations" className="m-0">
            <InvitationsTabContent onInvite={() => setInviteFormOpen(true)} />
          </TabsContent>
        )}
      </Tabs>

      {/* Forms */}
      <TeamMemberForm 
        open={memberFormOpen} 
        onClose={() => setMemberFormOpen(false)} 
        member={editingMember} 
      />
      <DepartmentForm 
        open={deptFormOpen} 
        onClose={() => setDeptFormOpen(false)} 
        department={editingDept} 
      />
      <InviteForm
        open={inviteFormOpen}
        onClose={() => setInviteFormOpen(false)}
      />

      {/* Generated Login Link Dialog */}
      <Dialog open={!!generatedLink} onOpenChange={(open) => !open && setGeneratedLink(null)}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Link2 className="w-5 h-5 text-primary" />
              Login link for {generatedLink?.name}
            </DialogTitle>
            <DialogDescription>
              Copy this link and send it to them. It expires in 24 hours and can only be used once.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-3">
            <div className="flex items-center gap-2 bg-muted rounded-lg p-3">
              <code className="text-xs flex-1 break-all select-all">{generatedLink?.url}</code>
            </div>
            <div className="flex gap-2">
              <Button
                className="flex-1"
                onClick={() => {
                  if (generatedLink?.url) {
                    navigator.clipboard.writeText(generatedLink.url);
                    toast.success("Link copied to clipboard");
                  }
                }}
              >
                Copy link
              </Button>
              <Button variant="outline" onClick={() => setGeneratedLink(null)}>
                Close
              </Button>
            </div>
            <p className="text-xs text-muted-foreground flex items-start gap-1.5">
              <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" />
              If email delivery is working, you can also use "Forgot password?" on the login page — it sends a link automatically.
            </p>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Member Confirm */}
      <AlertDialog open={!!memberToDelete} onOpenChange={(open) => !open && setMemberToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove team member?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove {memberToDelete?.username || 'this user'} from the team? 
              They will lose access to team resources.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteMember.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={(e) => { e.preventDefault(); handleConfirmDeleteMember(); }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteMember.isPending}
            >
              {deleteMember.isPending ? "Removing..." : "Remove"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Delete Department Confirm */}
      <AlertDialog open={!!deptToDelete} onOpenChange={(open) => !open && setDeptToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete department?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete the "{deptToDelete?.name}" department?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={deleteDepartment.isPending}>Cancel</AlertDialogCancel>
            <AlertDialogAction 
              onClick={(e) => { e.preventDefault(); handleConfirmDeleteDept(); }}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteDepartment.isPending}
            >
              {deleteDepartment.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
