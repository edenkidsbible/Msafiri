import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "wouter";
import {
  useGetCurrentWeek,
  useGetWeeklyPlan,
  useGetWeeklyReview,
  useListWeeks,
  useListTransactions,
  getListTransactionsQueryKey,
  useUpsertWeeklyPlan,
  useUpsertWeeklyReview,
  getGetWeeklyPlanQueryKey,
  getGetWeeklyReviewQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetDashboardActivityQueryKey,
} from "@workspace/api-client-react";
import type { OperatingWeek, Transaction } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Target,
  Flag,
  CircleDollarSign,
  Edit3,
  BookOpen,
  Wallet,
  Loader2,
  Plus,
  Trash2,
  ChevronDown,
  Lightbulb,
  Pencil,
  ArrowRight,
  Check,
  Zap,
  Package2,
  Users2,
  MapPin,
  FileText,
} from "lucide-react";
import { formatKes } from "@/lib/utils";
import { TransactionForm } from "@/components/forms/TransactionForm";

// ── Plan edit sheet ──────────────────────────────────────────────────────────

interface PlanSheetProps {
  open: boolean;
  onClose: () => void;
  weekId: number;
  weekNumber: number;
  initial?: {
    mainObjective?: string | null;
    requiredOutcomes?: string[];
    cashDecision?: string | null;
    productPriority?: string | null;
    userPriority?: string | null;
    fieldSprint?: string | null;
    contentPlan?: string | null;
  };
}

function PlanSheet({ open, onClose, weekId, weekNumber, initial }: PlanSheetProps) {
  const qc = useQueryClient();
  const upsert = useUpsertWeeklyPlan();

  const blankForm = {
    mainObjective: "",
    cashDecision: "",
    productPriority: "",
    userPriority: "",
    fieldSprint: "",
    contentPlan: "",
    requiredOutcomes: [""],
  };

  const [form, setForm] = useState(blankForm);

  useEffect(() => {
    if (open) {
      setForm({
        mainObjective: initial?.mainObjective ?? "",
        cashDecision: initial?.cashDecision ?? "",
        productPriority: initial?.productPriority ?? "",
        userPriority: initial?.userPriority ?? "",
        fieldSprint: initial?.fieldSprint ?? "",
        contentPlan: initial?.contentPlan ?? "",
        requiredOutcomes:
          initial?.requiredOutcomes && initial.requiredOutcomes.length > 0
            ? [...initial.requiredOutcomes, ""]
            : [""],
      });
    }
  }, [open]);

  const setOutcome = (i: number, val: string) => {
    setForm((f) => {
      const next = [...f.requiredOutcomes];
      next[i] = val;
      return { ...f, requiredOutcomes: next };
    });
  };

  const addOutcome = () => {
    if (form.requiredOutcomes.length >= 7) return;
    setForm((f) => ({ ...f, requiredOutcomes: [...f.requiredOutcomes, ""] }));
  };

  const removeOutcome = (i: number) => {
    setForm((f) => ({
      ...f,
      requiredOutcomes: f.requiredOutcomes.filter((_, idx) => idx !== i),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const outcomes = form.requiredOutcomes
      .map((o) => o.trim())
      .filter(Boolean);
    await upsert.mutateAsync({
      weekId,
      data: {
        mainObjective: form.mainObjective.trim() || undefined,
        cashDecision: form.cashDecision.trim() || undefined,
        productPriority: form.productPriority.trim() || undefined,
        userPriority: form.userPriority.trim() || undefined,
        fieldSprint: form.fieldSprint.trim() || undefined,
        contentPlan: form.contentPlan.trim() || undefined,
        requiredOutcomes: outcomes,
      },
    });
    qc.invalidateQueries({ queryKey: getGetWeeklyPlanQueryKey(weekId) });
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardActivityQueryKey() });
    onClose();
  };

  return (
    <FormDialog
      open={open}
      onClose={onClose}
      title={`Edit Week ${weekNumber} Plan`}
      width="max-w-xl"
    >
        <form onSubmit={handleSubmit} className="space-y-5">
          {/* Main objective */}
          <div className="space-y-1.5">
            <Label htmlFor="mainObj" className="flex items-center gap-1.5">
              <Target className="w-3.5 h-3.5 text-primary" />
              Main Objective
            </Label>
            <Textarea
              id="mainObj"
              rows={2}
              placeholder="The single most important thing to accomplish this week…"
              value={form.mainObjective}
              onChange={(e) => setForm((f) => ({ ...f, mainObjective: e.target.value }))}
            />
          </div>

          {/* Required outcomes */}
          <div className="space-y-2">
            <Label className="flex items-center gap-1.5">
              <Flag className="w-3.5 h-3.5 text-muted-foreground" />
              Required Outcomes
              <span className="text-xs text-muted-foreground ml-auto">
                {form.requiredOutcomes.filter(Boolean).length}/7
              </span>
            </Label>
            <div className="space-y-2">
              {form.requiredOutcomes.map((outcome, i) => (
                <div key={i} className="flex gap-2">
                  <Input
                    value={outcome}
                    onChange={(e) => setOutcome(i, e.target.value)}
                    placeholder={`Outcome ${i + 1}`}
                  />
                  {form.requiredOutcomes.length > 1 && (
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      className="shrink-0 text-muted-foreground hover:text-destructive"
                      onClick={() => removeOutcome(i)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
            {form.requiredOutcomes.length < 7 && (
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="text-muted-foreground"
                onClick={addOutcome}
              >
                <Plus className="w-3.5 h-3.5 mr-1" />
                Add outcome
              </Button>
            )}
          </div>

          {/* Cash decision */}
          <div className="space-y-1.5">
            <Label htmlFor="cashDecision" className="flex items-center gap-1.5">
              <CircleDollarSign className="w-3.5 h-3.5 text-emerald-600" />
              Cash Decision
            </Label>
            <Textarea
              id="cashDecision"
              rows={2}
              placeholder="Key cash allocation decision for this week…"
              value={form.cashDecision}
              onChange={(e) => setForm((f) => ({ ...f, cashDecision: e.target.value }))}
            />
          </div>

          {/* 2-col grid for priorities */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="productPri">Product Priority</Label>
              <Input
                id="productPri"
                placeholder="e.g. Driver app GPS"
                value={form.productPriority}
                onChange={(e) => setForm((f) => ({ ...f, productPriority: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="userPri">User Priority</Label>
              <Input
                id="userPri"
                placeholder="e.g. Onboard 5 drivers"
                value={form.userPriority}
                onChange={(e) => setForm((f) => ({ ...f, userPriority: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="fieldSprint">Field Sprint</Label>
              <Input
                id="fieldSprint"
                placeholder="e.g. Nairobi CBD loop"
                value={form.fieldSprint}
                onChange={(e) => setForm((f) => ({ ...f, fieldSprint: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="contentPlan">Content Plan</Label>
              <Input
                id="contentPlan"
                placeholder="e.g. 2 reels + thread"
                value={form.contentPlan}
                onChange={(e) => setForm((f) => ({ ...f, contentPlan: e.target.value }))}
              />
            </div>
          </div>

          <FormDialogFooter>
            <div />
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={upsert.isPending}>
                {upsert.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Plan
              </Button>
            </div>
          </FormDialogFooter>
        </form>
    </FormDialog>
  );
}

// ── Review sheet ──────────────────────────────────────────────────────────────

interface ReviewSheetProps {
  open: boolean;
  onClose: () => void;
  weekId: number;
  weekNumber: number;
  initial?: {
    whatWorked?: string | null;
    whatDidntWork?: string | null;
    keyLearning?: string | null;
    nextWeekFocus?: string | null;
  };
}

function ReviewSheet({ open, onClose, weekId, weekNumber, initial }: ReviewSheetProps) {
  const qc = useQueryClient();
  const upsert = useUpsertWeeklyReview();

  const blankForm = {
    whatWorked: "",
    whatDidntWork: "",
    keyLearning: "",
    nextWeekFocus: "",
  };

  const [form, setForm] = useState(blankForm);

  useEffect(() => {
    if (open) {
      setForm({
        whatWorked: initial?.whatWorked ?? "",
        whatDidntWork: initial?.whatDidntWork ?? "",
        keyLearning: initial?.keyLearning ?? "",
        nextWeekFocus: initial?.nextWeekFocus ?? "",
      });
    }
  }, [open]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await upsert.mutateAsync({
      weekId,
      data: {
        whatWorked: form.whatWorked.trim() || undefined,
        whatDidntWork: form.whatDidntWork.trim() || undefined,
        keyLearning: form.keyLearning.trim() || undefined,
        nextWeekFocus: form.nextWeekFocus.trim() || undefined,
      },
    });
    qc.invalidateQueries({ queryKey: getGetWeeklyReviewQueryKey(weekId) });
    onClose();
  };

  return (
    <FormDialog
      open={open}
      onClose={onClose}
      title={`Week ${weekNumber} — Sunday Review`}
      width="max-w-xl"
    >
        <form onSubmit={handleSubmit} className="space-y-5">
          <div className="space-y-1.5">
            <Label htmlFor="whatWorked">✅ What worked?</Label>
            <Textarea
              id="whatWorked"
              rows={3}
              placeholder="What went well this week?"
              value={form.whatWorked}
              onChange={(e) => setForm((f) => ({ ...f, whatWorked: e.target.value }))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="whatDidntWork">❌ What didn't work?</Label>
            <Textarea
              id="whatDidntWork"
              rows={3}
              placeholder="What fell short or caused friction?"
              value={form.whatDidntWork}
              onChange={(e) => setForm((f) => ({ ...f, whatDidntWork: e.target.value }))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="keyLearning" className="flex items-center gap-1.5">
              <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              Key learning
            </Label>
            <Textarea
              id="keyLearning"
              rows={2}
              placeholder="The one thing you're taking into next week…"
              value={form.keyLearning}
              onChange={(e) => setForm((f) => ({ ...f, keyLearning: e.target.value }))}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="nextWeekFocus">Next week focus</Label>
            <Textarea
              id="nextWeekFocus"
              rows={2}
              placeholder="What must you protect time for next week?"
              value={form.nextWeekFocus}
              onChange={(e) => setForm((f) => ({ ...f, nextWeekFocus: e.target.value }))}
            />
          </div>

          <FormDialogFooter>
            <div />
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={upsert.isPending}>
                {upsert.isPending && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                Save Review
              </Button>
            </div>
          </FormDialogFooter>
        </form>
    </FormDialog>
  );
}

// ── Review display card ───────────────────────────────────────────────────────

function ReviewCard({
  weekId,
  weekNumber,
}: {
  weekId: number;
  weekNumber: number;
}) {
  const [reviewOpen, setReviewOpen] = useState(false);
  const { data: review } = useGetWeeklyReview(weekId, {
    query: { enabled: !!weekId, queryKey: getGetWeeklyReviewQueryKey(weekId) },
  });

  const hasReview =
    review?.whatWorked ||
    review?.whatDidntWork ||
    review?.keyLearning ||
    review?.nextWeekFocus;

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span className="flex items-center gap-2">
              <BookOpen className="w-5 h-5 text-muted-foreground" />
              Sunday Review
            </span>
            <Button
              size="sm"
              variant="ghost"
              className="text-xs"
              onClick={() => setReviewOpen(true)}
            >
              <Edit3 className="w-3.5 h-3.5 mr-1" />
              {hasReview ? "Edit" : "Start Review"}
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          {hasReview ? (
            <div className="space-y-3 text-sm">
              {review?.whatWorked && (
                <div>
                  <p className="text-xs uppercase text-muted-foreground mb-1">What worked</p>
                  <p className="leading-relaxed">{review.whatWorked}</p>
                </div>
              )}
              {review?.whatDidntWork && (
                <div>
                  <p className="text-xs uppercase text-muted-foreground mb-1">What didn't work</p>
                  <p className="leading-relaxed">{review.whatDidntWork}</p>
                </div>
              )}
              {review?.keyLearning && (
                <div>
                  <p className="text-xs uppercase text-muted-foreground mb-1">Key learning</p>
                  <p className="leading-relaxed">{review.keyLearning}</p>
                </div>
              )}
              {review?.nextWeekFocus && (
                <div>
                  <p className="text-xs uppercase text-muted-foreground mb-1">Next week focus</p>
                  <p className="leading-relaxed">{review.nextWeekFocus}</p>
                </div>
              )}
              {review?.reviewedAt && (
                <p className="text-xs text-muted-foreground pt-1 border-t">
                  Reviewed {new Date(review.reviewedAt).toLocaleDateString()}
                </p>
              )}
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">
              No review recorded yet. Use Sundays to reflect on the week.
            </p>
          )}
        </CardContent>
      </Card>

      <ReviewSheet
        open={reviewOpen}
        onClose={() => setReviewOpen(false)}
        weekId={weekId}
        weekNumber={weekNumber}
        initial={review}
      />
    </>
  );
}

// ── Content plan formatter ────────────────────────────────────────────────────

function parseContentPlan(text: string): string[] {
  // Split on ". " before a capital letter, or on explicit newlines
  const normalized = text.replace(/\n+/g, ". ").replace(/\.\s{2,}/g, ". ");
  const parts = normalized
    .split(/(?<=\.)\s+(?=[A-Z])/)
    .map(s => s.trim().replace(/\.$/, ""))
    .filter(s => s.length > 4);
  return parts.length > 1 ? parts : [text.trim()];
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function ThisWeek() {
  const { data: currentWeek, isLoading: weekLoading } = useGetCurrentWeek();
  const { data: allWeeks } = useListWeeks();

  const [selectedWeekId, setSelectedWeekId] = useState<number | null>(null);
  const [planOpen, setPlanOpen] = useState(false);
  const [fundingOpen, setFundingOpen] = useState(false);
  const [editTx, setEditTx] = useState<Transaction | null>(null);
  const [editTxOpen, setEditTxOpen] = useState(false);

  // Resolve selected week — fall back to current
  const activeWeekId = selectedWeekId ?? currentWeek?.id ?? null;
  const activeWeek =
    allWeeks?.find((w) => w.id === activeWeekId) ??
    (activeWeekId === currentWeek?.id ? currentWeek : null);

  const { data: plan, isLoading: planLoading } = useGetWeeklyPlan(
    activeWeekId ?? 0,
    {
      query: {
        enabled: !!activeWeekId,
        queryKey: getGetWeeklyPlanQueryKey(activeWeekId ?? 0),
      },
    }
  );

  const weekTxParams = activeWeekId ? { weekId: activeWeekId } : undefined;
  const { data: weekTxData, isLoading: txLoading } = useListTransactions(
    weekTxParams,
    {
      query: {
        enabled: !!activeWeekId,
        queryKey: getListTransactionsQueryKey(weekTxParams),
      },
    }
  );

  // Sync selected week to current when it arrives
  useEffect(() => {
    if (currentWeek?.id && selectedWeekId === null) {
      setSelectedWeekId(currentWeek.id);
    }
  }, [currentWeek?.id]);

  // ── Outcome checklist state ─────────────────────────────────────────────────
  const [localCompleted, setLocalCompleted] = useState<string[]>([]);

  useEffect(() => {
    setLocalCompleted((plan as any)?.completedOutcomes ?? []);
  }, [plan]);

  const toggleOutcome = async (outcome: string) => {
    const prev = localCompleted;
    const next = prev.includes(outcome)
      ? prev.filter(o => o !== outcome)
      : [...prev, outcome];
    setLocalCompleted(next); // optimistic
    if (!activeWeekId) return;
    try {
      await fetch(`/api/weeks/${activeWeekId}/plan/outcomes-done`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ completedOutcomes: next }),
      });
    } catch {
      setLocalCompleted(prev); // revert on failure
    }
  };

  if (weekLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (!currentWeek) {
    return (
      <div className="p-12 text-center border border-dashed rounded-lg bg-muted/50">
        <p className="text-muted-foreground">No active operating week found.</p>
      </div>
    );
  }

  const isCurrentWeek = activeWeek?.id === currentWeek.id;

  // Sorted weeks for the selector (Week 1 → Week 24)
  const sortedWeeks = allWeeks
    ? [...allWeeks].sort((a, b) => a.weekNumber - b.weekNumber)
    : [];

  return (
    <div className="space-y-8 animate-in">
      {/* Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b pb-4">
        <div>
          <div className="flex items-center gap-3 flex-wrap">
            <h1 className="text-3xl font-bold tracking-tight">
              Week {activeWeek?.weekNumber ?? currentWeek.weekNumber}
            </h1>
            {isCurrentWeek && <Badge variant="success">Current</Badge>}
            {/* Week selector */}
            {sortedWeeks.length > 0 && (
              <Select
                value={String(activeWeekId)}
                onValueChange={(v) => setSelectedWeekId(Number(v))}
              >
                <SelectTrigger className="h-7 text-xs w-auto gap-1 border-dashed">
                  <ChevronDown className="w-3 h-3" />
                  <SelectValue placeholder="Change week" />
                </SelectTrigger>
                <SelectContent>
                  {sortedWeeks.map((w) => (
                    <SelectItem key={w.id} value={String(w.id)}>
                      Week {w.weekNumber}
                      {w.id === currentWeek.id ? " (current)" : ""}
                      {" · "}
                      {new Date(w.startDate).toLocaleDateString("en-GB", {
                        day: "numeric",
                        month: "short",
                      })}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>
          {activeWeek && (
            <p className="text-muted-foreground mt-1">
              {new Date(activeWeek.startDate).toLocaleDateString()} –{" "}
              {new Date(activeWeek.endDate).toLocaleDateString()}
            </p>
          )}
        </div>
        <div className="flex gap-2 flex-wrap">
          <Button
            variant="outline"
            className="text-primary border-primary/30 hover:bg-primary/5"
            onClick={() => setFundingOpen(true)}
          >
            <Wallet className="w-4 h-4 mr-2" />
            Friday Funding (KES 10k)
          </Button>
          <Button variant="outline" onClick={() => setPlanOpen(true)}>
            <Edit3 className="w-4 h-4 mr-2" />
            Edit Plan
          </Button>
        </div>
      </div>

      {planLoading ? (
        <div className="space-y-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: plan details */}
          <div className="lg:col-span-2 space-y-6">
            {/* Main objective */}
            <Card className="bg-primary/5 border-primary/20">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-primary">
                  <Target className="w-5 h-5" />
                  Main Objective
                </CardTitle>
              </CardHeader>
              <CardContent>
                {plan?.mainObjective ? (
                  <p className="text-xl font-medium text-foreground">
                    {plan.mainObjective}
                  </p>
                ) : (
                  <button
                    onClick={() => setPlanOpen(true)}
                    className="text-muted-foreground text-sm hover:text-primary transition-colors text-left"
                  >
                    No main objective set — click Edit Plan to add one.
                  </button>
                )}
              </CardContent>
            </Card>

            {/* Required outcomes — interactive checklist */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Flag className="w-4 h-4 text-muted-foreground" />
                  Required Outcomes
                  {plan?.requiredOutcomes && plan.requiredOutcomes.length > 0 && (
                    <span className="ml-auto text-xs font-normal text-muted-foreground">
                      {localCompleted.length}/{plan.requiredOutcomes.length} done
                    </span>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                {plan?.requiredOutcomes && plan.requiredOutcomes.length > 0 ? (
                  <div>
                    {plan.requiredOutcomes.map((outcome, i) => {
                      const done = localCompleted.includes(outcome);
                      return (
                        <button
                          key={i}
                          onClick={() => toggleOutcome(outcome)}
                          className="w-full flex items-start gap-3 py-2.5 px-2 text-left rounded-md hover:bg-accent/40 transition-colors group"
                        >
                          <span className={`mt-0.5 w-4 h-4 rounded border-2 shrink-0 flex items-center justify-center transition-all ${
                            done
                              ? "bg-primary border-primary"
                              : "border-muted-foreground/40 group-hover:border-primary/60"
                          }`}>
                            {done && <Check className="w-2.5 h-2.5 text-primary-foreground" />}
                          </span>
                          <span className={`text-sm leading-snug ${
                            done ? "line-through text-muted-foreground" : "text-foreground"
                          }`}>
                            {outcome}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <button
                    onClick={() => setPlanOpen(true)}
                    className="text-muted-foreground text-sm hover:text-primary transition-colors text-left"
                  >
                    No outcomes defined — click Edit Plan to add up to 7.
                  </button>
                )}
              </CardContent>
            </Card>

            {/* Sprint Focus — compact single card replacing the 4 separate cards */}
            {(plan?.productPriority || plan?.userPriority || plan?.fieldSprint || plan?.contentPlan) ? (
              <Card>
                <CardHeader className="pb-0">
                  <CardTitle className="flex items-center gap-2 text-base">
                    <Zap className="w-4 h-4 text-amber-500" />
                    Sprint Focus
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0 divide-y">
                  {(
                    [
                      { icon: <Package2 className="w-3.5 h-3.5" />, label: "Product", value: plan?.productPriority },
                      { icon: <Users2 className="w-3.5 h-3.5" />, label: "Users", value: plan?.userPriority },
                      { icon: <MapPin className="w-3.5 h-3.5" />, label: "Field", value: plan?.fieldSprint },
                    ] as { icon: React.ReactNode; label: string; value: string | null | undefined }[]
                  ).filter(r => r.value).map(({ icon, label, value }) => (
                    <div key={label} className="flex items-start gap-3 py-3">
                      <span className="text-muted-foreground mt-0.5 shrink-0">{icon}</span>
                      <div className="min-w-0">
                        <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">{label} Priority</p>
                        <p className="text-sm font-medium mt-0.5 leading-snug">{value}</p>
                      </div>
                    </div>
                  ))}

                  {plan?.contentPlan && (
                    <div className="py-3">
                      <div className="flex items-center gap-2 mb-2.5">
                        <FileText className="w-3.5 h-3.5 text-muted-foreground" />
                        <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Content Plan</p>
                      </div>
                      <ul className="space-y-1.5 ml-5">
                        {parseContentPlan(plan.contentPlan).map((point, i) => (
                          <li key={i} className="flex items-start gap-2 text-sm">
                            <span className="text-muted-foreground shrink-0 mt-1 select-none">·</span>
                            <span className="leading-snug text-foreground/90">{point}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              <button
                onClick={() => setPlanOpen(true)}
                className="w-full border border-dashed rounded-lg p-4 text-sm text-muted-foreground hover:text-primary hover:border-primary/40 transition-colors text-center"
              >
                No sprint focus set — click Edit Plan to add priorities.
              </button>
            )}

            {/* Sunday review */}
            {activeWeekId && (
              <ReviewCard
                weekId={activeWeekId}
                weekNumber={activeWeek?.weekNumber ?? currentWeek.weekNumber}
              />
            )}
          </div>

          {/* Right: cash context */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CircleDollarSign className="w-5 h-5 text-emerald-600" />
                  Cash Context
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <p className="text-xs text-muted-foreground uppercase mb-1">
                    Cash Decision
                  </p>
                  {plan?.cashDecision ? (
                    <p className="text-sm font-medium">{plan.cashDecision}</p>
                  ) : (
                    <button
                      onClick={() => setPlanOpen(true)}
                      className="text-muted-foreground text-sm hover:text-primary transition-colors"
                    >
                      No decision recorded.
                    </button>
                  )}
                </div>
                <div className="pt-4 border-t space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Planned In:</span>
                    <span className="font-mono">
                      {formatKes(activeWeek?.plannedCashInKes)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">Planned Out:</span>
                    <span className="font-mono">
                      {formatKes(activeWeek?.plannedCashOutKes)}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-bold pt-2 border-t">
                    <span>Target Ending:</span>
                    <span className="font-mono">
                      {formatKes(activeWeek?.plannedEndingCashKes)}
                    </span>
                  </div>
                  {activeWeek?.actualEndingCashKes && (
                    <>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Actual In:</span>
                        <span className="font-mono text-emerald-600">
                          {formatKes(activeWeek.actualCashInKes)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Actual Out:</span>
                        <span className="font-mono text-red-500">
                          {formatKes(activeWeek.actualCashOutKes)}
                        </span>
                      </div>
                      <div className="flex justify-between text-sm font-bold">
                        <span>Actual Ending:</span>
                        <span className="font-mono">
                          {formatKes(activeWeek.actualEndingCashKes)}
                        </span>
                      </div>
                      {activeWeek.varianceKes && (
                        <div className="flex justify-between text-xs">
                          <span className="text-muted-foreground">Variance:</span>
                          <span
                            className={`font-mono ${
                              parseFloat(activeWeek.varianceKes) >= 0
                                ? "text-emerald-600"
                                : "text-red-500"
                            }`}
                          >
                            {formatKes(activeWeek.varianceKes)}
                          </span>
                        </div>
                      )}
                    </>
                  )}
                </div>

                {/* This Week's Transactions */}
                <div className="pt-4 border-t">
                  <p className="text-xs text-muted-foreground uppercase mb-3 font-medium">
                    This Week's Transactions
                  </p>
                  {txLoading ? (
                    <div className="space-y-2">
                      {[1, 2, 3].map((i) => (
                        <Skeleton key={i} className="h-9 w-full" />
                      ))}
                    </div>
                  ) : (() => {
                    const txItems = weekTxData?.items ?? [];
                    if (txItems.length === 0) {
                      return (
                        <div className="text-center py-4">
                          <p className="text-sm text-muted-foreground mb-2">
                            No transactions logged this week.
                          </p>
                          <Link
                            href="/money"
                            className="inline-flex items-center gap-1 text-xs text-primary hover:underline"
                          >
                            Go to Money page to log one
                            <ArrowRight className="w-3 h-3" />
                          </Link>
                        </div>
                      );
                    }

                    const income = txItems.filter(
                      (t) => t.type === "income" || t.type === "refund_in"
                    );
                    const expenses = txItems.filter(
                      (t) => t.type === "expense" || t.type === "refund_out"
                    );
                    const reserves = txItems.filter(
                      (t) => t.type === "reserve_transfer"
                    );

                    const renderGroup = (
                      label: string,
                      items: typeof txItems,
                      amountClass: string
                    ) =>
                      items.length > 0 ? (
                        <div className="mb-3">
                          <p className="text-xs font-semibold text-muted-foreground uppercase mb-1">
                            {label}
                          </p>
                          <div className="space-y-1">
                            {items.map((tx) => (
                              <div
                                key={tx.id}
                                className="flex items-center gap-1.5 text-sm group"
                              >
                                <div className="flex-1 min-w-0">
                                  <span className="truncate block leading-tight">
                                    {tx.description}
                                  </span>
                                </div>
                                <span className={`font-mono text-xs shrink-0 ${amountClass}`}>
                                  {formatKes(tx.amountKes)}
                                </span>
                                <span
                                  className={`text-xs px-1 py-0.5 rounded shrink-0 ${
                                    tx.cleared
                                      ? "bg-emerald-100 text-emerald-700"
                                      : "bg-amber-100 text-amber-700"
                                  }`}
                                >
                                  {tx.cleared ? "✓" : "~"}
                                </span>
                                <button
                                  onClick={() => {
                                    setEditTx(tx as Transaction);
                                    setEditTxOpen(true);
                                  }}
                                  className="opacity-0 group-hover:opacity-100 transition-opacity text-primary hover:text-primary/80 shrink-0"
                                  title="Edit"
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      ) : null;

                    return (
                      <>
                        {renderGroup("Income", income, "text-emerald-600")}
                        {renderGroup("Expenses", expenses, "text-red-500")}
                        {renderGroup("Reserves", reserves, "text-blue-600")}
                      </>
                    );
                  })()}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      )}

      {/* Drawers */}
      {activeWeekId && (
        <PlanSheet
          open={planOpen}
          onClose={() => setPlanOpen(false)}
          weekId={activeWeekId}
          weekNumber={activeWeek?.weekNumber ?? currentWeek.weekNumber}
          initial={plan}
        />
      )}

      <TransactionForm
        open={fundingOpen}
        onClose={() => setFundingOpen(false)}
        defaultAmount="10000"
        defaultType="income"
        defaultDescription="Friday Funding"
      />

      <TransactionForm
        open={editTxOpen}
        onClose={() => {
          setEditTxOpen(false);
          setEditTx(null);
        }}
        transaction={editTx ?? undefined}
      />
    </div>
  );
}
