import { useState } from 'react';
import { Link } from 'wouter';

const BASE_URL = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, '') ?? '';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const res = await fetch(`${BASE_URL}/api/auth/forgot-password`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        setError(data.error ?? 'Something went wrong. Please try again.');
        return;
      }
      setSent(true);
    } catch {
      setError('Network error — please try again');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
      {/* Kenyan flag stripe */}
      <div className="fixed top-0 inset-x-0 h-1 flex">
        <div className="flex-1 bg-[#006600]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#CE1126]" />
        <div className="flex-1 bg-white" />
        <div className="flex-1 bg-[#006600]" />
      </div>

      <div className="w-full max-w-sm space-y-6">
        <div className="flex flex-col items-center gap-3 mb-2">
          <img src="/logo.png" alt="Msafiri" className="w-16 h-16 rounded-2xl object-contain bg-white shadow" />
          <div className="text-center">
            <h1 className="text-2xl font-bold tracking-tight">Msafiri Founder OS</h1>
            <p className="text-sm text-muted-foreground mt-1">Password recovery</p>
          </div>
        </div>

        <div className="bg-card border border-border rounded-2xl shadow-sm p-6 space-y-4">
          {sent ? (
            <div className="space-y-4 text-center">
              <div className="w-12 h-12 rounded-full bg-emerald-100 flex items-center justify-center mx-auto">
                <svg className="w-6 h-6 text-emerald-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div>
                <p className="font-semibold text-base">Check your inbox</p>
                <p className="text-sm text-muted-foreground mt-1">
                  If <strong>{email}</strong> has an account, a password reset link has been sent.
                </p>
                <p className="text-xs text-muted-foreground mt-2">
                  Didn't receive it? Ask an owner to generate a login link for you from the Team page.
                </p>
              </div>
              <Link href="/login" className="text-sm text-primary font-medium hover:underline block">
                ← Back to sign in
              </Link>
            </div>
          ) : (
            <>
              <div>
                <h2 className="text-base font-semibold">Forgot your password?</h2>
                <p className="text-sm text-muted-foreground mt-1">
                  Enter your email and we'll send you a reset link.
                </p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-3">
                <div className="space-y-1">
                  <label className="text-sm font-medium text-foreground" htmlFor="email">
                    Email
                  </label>
                  <input
                    id="email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@msafirikenya.com"
                    className="w-full rounded-lg border border-input bg-background px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary transition"
                  />
                </div>

                {error && (
                  <p className="text-sm text-destructive bg-destructive/10 rounded-lg px-3 py-2">{error}</p>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-primary text-primary-foreground rounded-lg py-2.5 text-sm font-semibold hover:bg-primary/90 active:scale-[0.98] transition disabled:opacity-60"
                >
                  {loading ? 'Sending…' : 'Send reset link'}
                </button>
              </form>

              <p className="text-xs text-muted-foreground text-center pt-1">
                <Link href="/login" className="text-foreground font-medium hover:underline">
                  ← Back to sign in
                </Link>
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
