import { useState } from "react";
import { useListFieldTrips, useListRoadRecords } from "@workspace/api-client-react";
import type { FieldTrip, RoadRecord } from "@workspace/api-client-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatKes } from "@/lib/utils";
import { Map, AlertTriangle, MapPin, CheckCircle2, ShieldCheck, AlertCircle, PlusCircle, Pencil } from "lucide-react";
import { FieldTripForm } from "@/components/forms/FieldTripForm";
import { RoadRecordForm } from "@/components/forms/RoadRecordForm";

export default function FieldRoad() {
  const [activeTab, setActiveTab] = useState<'trips' | 'records'>('trips');
  const [tripFormOpen, setTripFormOpen] = useState(false);
  const [editingTrip, setEditingTrip] = useState<FieldTrip | undefined>(undefined);
  const [recordFormOpen, setRecordFormOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<RoadRecord | undefined>(undefined);

  const { data: trips, isLoading: loadingTrips } = useListFieldTrips();
  const { data: records, isLoading: loadingRecords } = useListRoadRecords();

  const openCreateTrip = () => { setEditingTrip(undefined); setTripFormOpen(true); };
  const openEditTrip = (t: FieldTrip) => { setEditingTrip(t); setTripFormOpen(true); };
  const closeTripForm = () => { setTripFormOpen(false); setEditingTrip(undefined); };

  const openCreateRecord = () => { setEditingRecord(undefined); setRecordFormOpen(true); };
  const openEditRecord = (r: RoadRecord) => { setEditingRecord(r); setRecordFormOpen(true); };
  const closeRecordForm = () => { setRecordFormOpen(false); setEditingRecord(undefined); };

  if (loadingTrips || loadingRecords) {
    return <div className="p-8 space-y-6"><Skeleton className="h-10 w-48"/><Skeleton className="h-64 w-full"/></div>;
  }

  const confidenceBadge = (confidence: string) => {
    switch(confidence) {
      case 'A': return <Badge className="bg-emerald-500/15 text-emerald-700 dark:text-emerald-400 border-transparent hover:bg-emerald-500/25"><ShieldCheck className="w-3 h-3 mr-1"/> Confirmed (A)</Badge>;
      case 'B': return <Badge className="bg-blue-500/15 text-blue-700 dark:text-blue-400 border-transparent hover:bg-blue-500/25"><CheckCircle2 className="w-3 h-3 mr-1"/> Strong (B)</Badge>;
      case 'C': return <Badge className="bg-amber-500/15 text-amber-700 dark:text-amber-400 border-transparent hover:bg-amber-500/25"><AlertCircle className="w-3 h-3 mr-1"/> Community (C)</Badge>;
      case 'D': return <Badge className="bg-red-500/15 text-red-700 dark:text-red-400 border-transparent hover:bg-red-500/25"><AlertTriangle className="w-3 h-3 mr-1"/> Unverified (D)</Badge>;
      default: return <Badge variant="outline">{confidence}</Badge>;
    }
  };

  return (
    <div className="space-y-8 animate-in">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Field & Road Data</h1>
          <p className="text-muted-foreground mt-1">Ground truth mapping and trip logistics.</p>
        </div>
        <div className="flex gap-2">
          {activeTab === 'trips' ? (
            <Button onClick={openCreateTrip}><PlusCircle className="w-4 h-4 mr-2" /> Plan Trip</Button>
          ) : (
            <Button onClick={openCreateRecord}><PlusCircle className="w-4 h-4 mr-2" /> Add Road Record</Button>
          )}
        </div>
      </div>

      <div className="flex items-center gap-4 border-b">
        <button 
          className={`pb-2 text-sm font-medium border-b-2 transition-colors ${activeTab === 'trips' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          onClick={() => setActiveTab('trips')}
        >
          Field Trips
        </button>
        <button 
          className={`pb-2 text-sm font-medium border-b-2 transition-colors ${activeTab === 'records' ? 'border-primary text-foreground' : 'border-transparent text-muted-foreground hover:text-foreground'}`}
          onClick={() => setActiveTab('records')}
        >
          Road Database
        </button>
      </div>

      {activeTab === 'trips' && (
        <div className="grid grid-cols-1 gap-4">
          {(trips as FieldTrip[])?.map((trip) => (
            <Card key={trip.id} className="overflow-hidden">
              <div className="flex flex-col md:flex-row">
                <div className="bg-muted/50 p-6 flex flex-col justify-center items-center text-center min-w-[140px] border-b md:border-b-0 md:border-r">
                  <div className="text-2xl font-bold">{new Date(trip.date).getDate()}</div>
                  <div className="text-sm font-medium text-muted-foreground uppercase">
                    {new Date(trip.date).toLocaleString('default', { month: 'short', year: 'numeric' })}
                  </div>
                  <Badge variant="outline" className="mt-3 capitalize">{trip.status.replace('_', ' ')}</Badge>
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start">
                      <h3 className="text-xl font-bold">{trip.purpose}</h3>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center gap-1 text-sm font-medium bg-primary/10 text-primary px-2 py-1 rounded">
                          <MapPin className="w-4 h-4" />
                          {trip.corridor || 'No route specified'}
                        </div>
                        <button
                          onClick={() => openEditTrip(trip)}
                          className="p-1.5 rounded hover:bg-muted transition-colors"
                          title="Edit trip"
                        >
                          <Pencil className="w-4 h-4 text-muted-foreground" />
                        </button>
                      </div>
                    </div>
                    {trip.requiredOutputs && (
                      <p className="text-sm text-muted-foreground mt-2 line-clamp-2">Outputs: {trip.requiredOutputs}</p>
                    )}
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6 pt-4 border-t">
                    <div>
                      <p className="text-xs text-muted-foreground uppercase">Distance</p>
                      <p className="font-semibold">{trip.actualKm || trip.plannedKm || '--'} km</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase">Est. Fuel Cost</p>
                      <p className="font-semibold font-mono text-amber-600 dark:text-amber-500">{formatKes(trip.estimatedFuelCostKes)}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase">Tolls/Parking</p>
                      <p className="font-semibold font-mono">
                        {formatKes((parseFloat(trip.tollsKes||"0") + parseFloat(trip.parkingKes||"0")).toString())}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground uppercase">Total Cost</p>
                      <p className="font-semibold font-mono text-primary">{formatKes(trip.totalTripCostKes)}</p>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
          {!(trips as FieldTrip[])?.length && (
            <div className="p-12 text-center text-muted-foreground border border-dashed rounded-lg bg-muted/10">
              No field trips planned yet.{" "}
              <button className="text-primary underline hover:no-underline" onClick={openCreateTrip}>Plan one</button>
            </div>
          )}
        </div>
      )}

      {activeTab === 'records' && (
        <div className="bg-card border rounded-lg overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 border-b">
              <tr>
                <th className="text-left font-medium p-4 text-muted-foreground">Location</th>
                <th className="text-left font-medium p-4 text-muted-foreground">Type</th>
                <th className="text-left font-medium p-4 text-muted-foreground">Details</th>
                <th className="text-left font-medium p-4 text-muted-foreground">Confidence</th>
                <th className="text-left font-medium p-4 text-muted-foreground">Status</th>
                <th className="w-10 p-4"></th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {(records as RoadRecord[])?.map((record) => (
                <tr key={record.id} className="hover:bg-muted/20 group">
                  <td className="p-4">
                    <p className="font-medium text-foreground">{record.county}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{record.corridor}</p>
                  </td>
                  <td className="p-4">
                    <Badge variant="secondary" className="capitalize">{record.dataType.replace('_', ' ')}</Badge>
                  </td>
                  <td className="p-4">
                    {record.speedLimitKph ? (
                      <span className="inline-flex items-center justify-center w-8 h-8 rounded-full border-2 border-red-500 font-bold text-xs bg-white text-black shrink-0">
                        {record.speedLimitKph}
                      </span>
                    ) : (
                      <span className="text-muted-foreground text-xs truncate max-w-[200px] block">
                        {record.landmark || record.coordinates || 'No details'}
                      </span>
                    )}
                  </td>
                  <td className="p-4">{confidenceBadge(record.confidence)}</td>
                  <td className="p-4 capitalize text-muted-foreground text-xs">{record.status.replace('_', ' ')}</td>
                  <td className="p-4">
                    <button
                      onClick={() => openEditRecord(record)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-muted"
                      title="Edit"
                    >
                      <Pencil className="w-3.5 h-3.5 text-muted-foreground" />
                    </button>
                  </td>
                </tr>
              ))}
              {!(records as RoadRecord[])?.length && (
                <tr>
                  <td colSpan={6} className="p-8 text-center text-muted-foreground">No road records found.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      <FieldTripForm open={tripFormOpen} onClose={closeTripForm} trip={editingTrip} />
      <RoadRecordForm open={recordFormOpen} onClose={closeRecordForm} record={editingRecord} />
    </div>
  );
}
