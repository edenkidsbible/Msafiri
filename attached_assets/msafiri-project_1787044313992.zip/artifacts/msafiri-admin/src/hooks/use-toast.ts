import { useState, useEffect } from "react"

export interface Toast {
  id: string
  title?: string
  description?: string
  variant?: "default" | "destructive"
}

export function useToast() {
  const [toasts, setToasts] = useState<Toast[]>([])

  useEffect(() => {
    const handleAdd = (e: CustomEvent<Toast>) => {
      const id = Math.random().toString(36).slice(2)
      setToasts((t) => [...t, { ...e.detail, id }])
      setTimeout(() => {
        setToasts((t) => t.filter((toast) => toast.id !== id))
      }, 5000)
    }
    
    window.addEventListener("add-toast" as any, handleAdd)
    return () => window.removeEventListener("add-toast" as any, handleAdd)
  }, [])

  return {
    toasts,
    toast: (props: Omit<Toast, "id">) => {
      window.dispatchEvent(new CustomEvent("add-toast", { detail: props }))
    }
  }
}
