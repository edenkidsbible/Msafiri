import { useEffect, useRef, useCallback } from "react";
import { useQueryClient } from "@tanstack/react-query";

type WsEvent =
  | { type: "connected"; userId: string }
  | { type: "new_message"; message: { id: number; conversationId: number; body: string; createdAt: string; senderId: string; senderFirstName: string | null; senderLastName: string | null; senderProfileImageUrl: string | null } }
  | { type: "read_receipt"; conversationId: number; userId: string; lastReadMessageId: number };

interface UseChatSocketOptions {
  enabled: boolean;
  activeConversationId?: number | null;
  onNewMessage?: (msg: WsEvent & { type: "new_message" }) => void;
}

// Simple notification tone via WebAudio
function playNotificationTone() {
  try {
    const ctx = new AudioContext();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 880;
    osc.type = "sine";
    gain.gain.setValueAtTime(0.1, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);
    osc.start(ctx.currentTime);
    osc.stop(ctx.currentTime + 0.3);
  } catch {
    // AudioContext may be blocked; ignore
  }
}

const BASE = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, "") ?? "";

export function useChatSocket({ enabled, activeConversationId, onNewMessage }: UseChatSocketOptions) {
  const queryClient = useQueryClient();
  const wsRef = useRef<WebSocket | null>(null);
  const retryRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const retryDelay = useRef(1000);
  const mountedRef = useRef(true);

  const connect = useCallback(() => {
    if (!mountedRef.current || !enabled) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const host = window.location.host;
    // Strip the base path prefix to get the API WS endpoint
    const wsUrl = `${protocol}//${host}${BASE}/api/ws`;

    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      retryDelay.current = 1000;
    };

    ws.onmessage = (ev) => {
      let event: WsEvent;
      try {
        event = JSON.parse(ev.data);
      } catch {
        return;
      }

      if (event.type === "new_message") {
        const msg = event.message;

        // Invalidate conversations list (updates last message + unread count)
        queryClient.invalidateQueries({ queryKey: ["chat", "conversations"] });
        // Invalidate unread total
        queryClient.invalidateQueries({ queryKey: ["chat", "unread"] });

        // Update the message thread cache if this conversation is active
        if (msg.conversationId === activeConversationId) {
          queryClient.setQueryData(
            ["chat", "messages", msg.conversationId],
            (old: any[] | undefined) => (old ? [...old, { ...msg, createdAt: new Date(msg.createdAt) }] : [{ ...msg, createdAt: new Date(msg.createdAt) }]),
          );
        } else {
          // Notify in non-active conversation
          playNotificationTone();
        }

        onNewMessage?.(event);
      }

      if (event.type === "read_receipt") {
        queryClient.invalidateQueries({ queryKey: ["chat", "conversations"] });
      }
    };

    ws.onclose = () => {
      if (!mountedRef.current) return;
      // Exponential backoff reconnect
      retryRef.current = setTimeout(() => {
        retryDelay.current = Math.min(retryDelay.current * 2, 30_000);
        connect();
      }, retryDelay.current);
    };

    ws.onerror = () => {
      ws.close();
    };
  }, [enabled, activeConversationId, onNewMessage, queryClient]);

  useEffect(() => {
    mountedRef.current = true;
    if (enabled) connect();
    return () => {
      mountedRef.current = false;
      if (retryRef.current) clearTimeout(retryRef.current);
      wsRef.current?.close(1000, "component unmount");
    };
  }, [enabled, connect]);

  return wsRef;
}
