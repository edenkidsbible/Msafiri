import { type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Layout } from '@/components/layout';
import NotFound from '@/pages/not-found';
import Login from '@/pages/login';
import AcceptInvite from '@/pages/accept-invite';
import ForgotPassword from '@/pages/forgot-password';
import ResetPassword from '@/pages/reset-password';
import Home from '@/pages/home';
import ThisWeek from '@/pages/this-week';
import Money from '@/pages/money';
import Subscriptions from '@/pages/subscriptions';
import Tasks from '@/pages/tasks';
import Content from '@/pages/content';
import FieldRoad from '@/pages/field';
import ImportData from '@/pages/import';
import Settings from '@/pages/settings';
import Team from '@/pages/team';
import Chat from '@/pages/chat';
import { useGetCurrentAuthUser } from '@workspace/api-client-react';
import { Route, Switch, useLocation, Router as WouterRouter, Redirect } from 'wouter';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: { retry: false, staleTime: 30_000 },
  },
});

function AuthGate({ children }: { children: ReactNode }) {
  const { data: auth, isLoading } = useGetCurrentAuthUser();

  if (isLoading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background">
        <div className="text-muted-foreground text-sm animate-pulse">Loading Msafiri OS…</div>
      </div>
    );
  }

  if (!auth?.isAuthenticated) {
    return <Redirect to="/login" />;
  }

  return <Layout>{children}</Layout>;
}

function Router() {
  const [location] = useLocation();
  return (
    <ErrorBoundary resetKey={location}>
      <Switch>
        <Route path="/login" component={Login} />
        <Route path="/accept-invite" component={AcceptInvite} />
        <Route path="/forgot-password" component={ForgotPassword} />
        <Route path="/reset-password" component={ResetPassword} />

        <Route path="/">
          <AuthGate><Home /></AuthGate>
        </Route>
        <Route path="/this-week">
          <AuthGate><ThisWeek /></AuthGate>
        </Route>
        <Route path="/money">
          <AuthGate><Money /></AuthGate>
        </Route>
        <Route path="/subscriptions">
          <AuthGate><Subscriptions /></AuthGate>
        </Route>
        <Route path="/tasks">
          <AuthGate><Tasks /></AuthGate>
        </Route>
        <Route path="/content">
          <AuthGate><Content /></AuthGate>
        </Route>
        <Route path="/field">
          <AuthGate><FieldRoad /></AuthGate>
        </Route>
        <Route path="/import">
          <AuthGate><ImportData /></AuthGate>
        </Route>
        <Route path="/settings">
          <AuthGate><Settings /></AuthGate>
        </Route>
        <Route path="/team">
          <AuthGate><Team /></AuthGate>
        </Route>
        <Route path="/chat">
          <AuthGate><Chat /></AuthGate>
        </Route>
        <Route path="/chat/:conversationId">
          <AuthGate><Chat /></AuthGate>
        </Route>

        <Route component={NotFound} />
      </Switch>
    </ErrorBoundary>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
