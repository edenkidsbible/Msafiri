import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatKes(amount: string | number | undefined | null): string {
  if (amount == null) return "KES 0.00";
  const num = typeof amount === "string" ? parseFloat(amount) : amount;
  if (isNaN(num)) return "KES 0.00";
  return `KES ${num.toLocaleString("en-KE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatNumber(num: number | undefined | null): string {
  if (num == null) return "0";
  return num.toLocaleString("en-KE");
}

export function parseDecimalString(val: string | null | undefined): number {
  if (!val) return 0;
  return parseFloat(val) || 0;
}
