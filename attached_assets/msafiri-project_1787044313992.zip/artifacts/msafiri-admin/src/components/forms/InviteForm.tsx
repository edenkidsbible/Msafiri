import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import { useQueryClient } from "@tanstack/react-query";
import { useListDepartments, getListDepartmentsQueryKey } from "@workspace/api-client-react";
import { toast } from "sonner";
import { Mail } from "lucide-react";
import { useState } from "react";

const inviteSchema = z.object({
  email: z.string().email("Enter a valid email address"),
  role: z.enum(["admin", "member", "viewer"]),
  departmentId: z.coerce.number().optional().nullable(),
});

type InviteFormValues = z.infer<typeof inviteSchema>;

interface InviteFormProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const BASE_URL = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, "") ?? "";

export function InviteForm({ open, onClose, onSuccess }: InviteFormProps) {
  const queryClient = useQueryClient();
  const { data: departments } = useListDepartments({ query: { enabled: open, queryKey: getListDepartmentsQueryKey() } });
  const [isPending, setIsPending] = useState(false);

  const form = useForm<InviteFormValues>({
    resolver: zodResolver(inviteSchema),
    defaultValues: { email: "", role: "member", departmentId: null },
  });

  const onSubmit = async (data: InviteFormValues) => {
    setIsPending(true);
    try {
      const res = await fetch(`${BASE_URL}/api/invitations`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: data.email,
          role: data.role,
          departmentId: data.departmentId || null,
        }),
        credentials: "include",
      });
      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        throw new Error(err.error || "Failed to send invitation");
      }
      const result = await res.json().catch(() => ({}));
      if (result.emailDelivered === false) {
        // Invitation record created but email failed — close and direct admin to the Resend button
        toast.warning(
          `Invitation created for ${data.email}, but the email could not be delivered. Use the Resend button in the Invitations tab to retry.`,
          { duration: 10000 },
        );
        form.reset();
        queryClient.invalidateQueries({ queryKey: ["invitations"] });
        onSuccess?.();
        onClose();
      } else {
        toast.success(`Invitation sent to ${data.email}`);
        form.reset();
        queryClient.invalidateQueries({ queryKey: ["invitations"] });
        onSuccess?.();
        onClose();
      }
    } catch (err: any) {
      toast.error(err.message || "Failed to send invitation");
    } finally {
      setIsPending(false);
    }
  };

  return (
    <FormDialog
      open={open}
      onClose={onClose}
      title="Invite Team Member"
      description="An email invitation will be sent with a secure signup link."
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <div className="flex items-start gap-3 p-3 bg-primary/5 border border-primary/20 rounded-lg">
            <Mail className="w-4 h-4 text-primary mt-0.5 shrink-0" />
            <p className="text-sm text-muted-foreground">
              The invitee will receive an email with a link to accept the invitation. They'll need to sign in with Replit using the same email address.
            </p>
          </div>

          <FormField
            control={form.control}
            name="email"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Email Address</FormLabel>
                <FormControl>
                  <Input type="email" placeholder="colleague@example.com" {...field} disabled={isPending} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="role"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Role</FormLabel>
                <Select onValueChange={field.onChange} value={field.value} disabled={isPending}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="admin">Admin — manage team &amp; settings</SelectItem>
                    <SelectItem value="member">Member — read &amp; write data</SelectItem>
                    <SelectItem value="viewer">Viewer — read-only</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="departmentId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Department (Optional)</FormLabel>
                <Select
                  onValueChange={(val) => field.onChange(val === "none" ? null : parseInt(val))}
                  value={field.value ? field.value.toString() : "none"}
                  disabled={isPending}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="No department" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {departments?.map((dept) => (
                      <SelectItem key={dept.id} value={dept.id.toString()}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormDescription>The invitee will be placed in this department when they accept.</FormDescription>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormDialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Sending…" : "Send Invitation"}
            </Button>
          </FormDialogFooter>
        </form>
      </Form>
    </FormDialog>
  );
}
