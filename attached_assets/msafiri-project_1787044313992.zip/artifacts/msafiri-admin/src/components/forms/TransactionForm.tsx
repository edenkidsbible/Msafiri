import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateTransaction, useUpdateTransaction, useDeleteTransaction,
  useListCategories,
  getListTransactionsQueryKey,
  getGetTransactionSummaryQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetDashboardActivityQueryKey,
  getListWeeksQueryKey,
} from "@workspace/api-client-react";
import type { Transaction, TransactionInputType } from "@workspace/api-client-react";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Trash2 } from "lucide-react";

interface TransactionFormProps {
  open: boolean;
  onClose: () => void;
  transaction?: Transaction;
  defaultAmount?: string;
  defaultType?: TransactionInputType;
  defaultDescription?: string;
}

export function TransactionForm({
  open, onClose, transaction, defaultAmount, defaultType, defaultDescription,
}: TransactionFormProps) {
  const qc = useQueryClient();
  const { data: categories } = useListCategories();
  const createTx = useCreateTransaction();
  const updateTx = useUpdateTransaction();
  const deleteTx = useDeleteTransaction();
  const [deleteOpen, setDeleteOpen] = useState(false);

  const today = new Date().toISOString().split("T")[0];

  const [form, setForm] = useState({
    date: transaction?.date?.split("T")[0] ?? today,
    type: (transaction?.type ?? defaultType ?? "expense") as TransactionInputType,
    amountKes: transaction?.amountKes ?? defaultAmount ?? "",
    description: transaction?.description ?? defaultDescription ?? "",
    categoryId: transaction?.categoryId?.toString() ?? "",
    cleared: transaction?.cleared ?? false,
    paymentMethod: transaction?.paymentMethod ?? "",
    reference: transaction?.reference ?? "",
    notes: transaction?.notes ?? "",
  });

  useEffect(() => {
    if (open) {
      setForm({
        date: transaction?.date?.split("T")[0] ?? today,
        type: (transaction?.type ?? defaultType ?? "expense") as TransactionInputType,
        amountKes: transaction?.amountKes ?? defaultAmount ?? "",
        description: transaction?.description ?? defaultDescription ?? "",
        categoryId: transaction?.categoryId?.toString() ?? "",
        cleared: transaction?.cleared ?? false,
        paymentMethod: transaction?.paymentMethod ?? "",
        reference: transaction?.reference ?? "",
        notes: transaction?.notes ?? "",
      });
    }
  }, [open, transaction]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getListTransactionsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetTransactionSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardActivityQueryKey() });
    // Invalidate weeks so Cash Context totals (Planned In/Out, Actual, Variance)
    // refresh immediately after a transaction is saved or deleted.
    qc.invalidateQueries({ queryKey: getListWeeksQueryKey() });
    // Refresh cash position (home Money Snapshot + money page breakdown cards)
    qc.invalidateQueries({ queryKey: ["cash-position"] });
    // Refresh focus board so cashKes KPI stays current
    qc.invalidateQueries({ queryKey: ["dashboard-focus"] });
    // Refresh per-week transaction breakdowns so expanded rows update
    qc.invalidateQueries({ queryKey: ["transactions", "week"] });
  };

  const filteredCategories = categories?.filter(c => {
    if (form.type === "income") return c.type === "income";
    if (form.type === "reserve_transfer") return c.type === "reserve";
    if (form.type === "refund_in" || form.type === "refund_out") return c.type === "refund";
    return c.type === "expense";
  }) ?? [];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.amountKes || !form.description || !form.date || !form.categoryId) return;
    const payload = {
      date: form.date,
      type: form.type,
      amountKes: form.amountKes,
      description: form.description,
      categoryId: parseInt(form.categoryId),
      cleared: form.cleared,
      paymentMethod: form.paymentMethod || undefined,
      reference: form.reference || undefined,
      notes: form.notes || undefined,
    };
    if (transaction) {
      await updateTx.mutateAsync({ id: transaction.id, data: payload });
    } else {
      await createTx.mutateAsync({ data: payload });
    }
    invalidate();
    onClose();
  };

  const handleDelete = async () => {
    if (!transaction) return;
    await deleteTx.mutateAsync({ id: transaction.id });
    invalidate();
    setDeleteOpen(false);
    onClose();
  };

  const isLoading = createTx.isPending || updateTx.isPending;

  return (
    <>
      <FormDialog
        open={open}
        onClose={onClose}
        title={transaction ? "Edit Transaction" : "Log Transaction"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Date</Label>
              <Input type="date" value={form.date} onChange={e => setForm(f => ({ ...f, date: e.target.value }))} required />
            </div>

            <div className="space-y-1.5">
              <Label>Type</Label>
              <Select value={form.type} onValueChange={v => setForm(f => ({ ...f, type: v as TransactionInputType, categoryId: "" }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="income">Income</SelectItem>
                  <SelectItem value="expense">Expense</SelectItem>
                  <SelectItem value="reserve_transfer">Reserve Transfer</SelectItem>
                  <SelectItem value="refund_in">Refund In</SelectItem>
                  <SelectItem value="refund_out">Refund Out</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Amount (KES)</Label>
            <Input
              type="number"
              min="0"
              step="0.01"
              placeholder="0.00"
              value={form.amountKes}
              onChange={e => setForm(f => ({ ...f, amountKes: e.target.value }))}
              required
              autoFocus
            />
          </div>

          <div className="space-y-1.5">
            <Label>Description</Label>
            <Input
              placeholder="What was this for?"
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              required
            />
          </div>

          <div className="space-y-1.5">
            <Label>Category</Label>
            <Select value={form.categoryId} onValueChange={v => setForm(f => ({ ...f, categoryId: v }))}>
              <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
              <SelectContent>
                {filteredCategories.map(c => (
                  <SelectItem key={c.id} value={c.id.toString()}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Payment Method</Label>
              <Input
                placeholder="e.g. M-Pesa"
                value={form.paymentMethod}
                onChange={e => setForm(f => ({ ...f, paymentMethod: e.target.value }))}
              />
            </div>
            <div className="space-y-1.5">
              <Label>Reference</Label>
              <Input
                placeholder="Receipt / Tx ID"
                value={form.reference}
                onChange={e => setForm(f => ({ ...f, reference: e.target.value }))}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Input
              placeholder="Optional notes"
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            />
          </div>

          <div className="flex items-center gap-2">
            <Checkbox
              id="cleared"
              checked={form.cleared}
              onCheckedChange={v => setForm(f => ({ ...f, cleared: !!v }))}
            />
            <Label htmlFor="cleared">Cleared (funds have moved)</Label>
          </div>

          <FormDialogFooter>
            <div>
              {transaction && (
                <Button type="button" variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => setDeleteOpen(true)}>
                  <Trash2 className="w-4 h-4 mr-1" /> Delete
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {transaction ? "Save Changes" : "Log Transaction"}
              </Button>
            </div>
          </FormDialogFooter>
        </form>
      </FormDialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Transaction?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently remove the transaction. Cash balances will be recalculated.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
