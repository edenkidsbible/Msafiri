import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateContentItem, useUpdateContentItem, useDeleteContentItem,
  getListContentItemsQueryKey,
  getGetWeeklyContentQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetDashboardActivityQueryKey,
} from "@workspace/api-client-react";
import type { ContentItem, ContentItemInputStatus } from "@workspace/api-client-react";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Trash2 } from "lucide-react";

const PLATFORMS = ["youtube", "instagram", "tiktok", "twitter", "linkedin", "whatsapp"];

interface ContentFormProps {
  open: boolean;
  onClose: () => void;
  item?: ContentItem;
  currentWeekId?: number;
}

export function ContentForm({ open, onClose, item, currentWeekId }: ContentFormProps) {
  const qc = useQueryClient();
  const createItem = useCreateContentItem();
  const updateItem = useUpdateContentItem();
  const deleteItem = useDeleteContentItem();
  const [deleteOpen, setDeleteOpen] = useState(false);

  const [form, setForm] = useState({
    title: item?.title ?? "",
    status: (item?.status ?? "idea") as ContentItemInputStatus,
    isCore: item?.isCore ?? false,
    pillar: item?.pillar ?? "",
    format: item?.format ?? "",
    hook: item?.hook ?? "",
    angle: item?.angle ?? "",
    platforms: item?.platforms ?? [] as string[],
    founderMinutes: item?.founderMinutes?.toString() ?? "",
    notes: item?.notes ?? "",
  });

  useEffect(() => {
    if (open) {
      setForm({
        title: item?.title ?? "",
        status: (item?.status ?? "idea") as ContentItemInputStatus,
        isCore: item?.isCore ?? false,
        pillar: item?.pillar ?? "",
        format: item?.format ?? "",
        hook: item?.hook ?? "",
        angle: item?.angle ?? "",
        platforms: item?.platforms ?? [],
        founderMinutes: item?.founderMinutes?.toString() ?? "",
        notes: item?.notes ?? "",
      });
    }
  }, [open, item]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getListContentItemsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardActivityQueryKey() });
    for (let i = 1; i <= 52; i++) {
      qc.invalidateQueries({ queryKey: getGetWeeklyContentQueryKey(i) });
    }
  };

  const togglePlatform = (p: string) => {
    setForm(f => ({
      ...f,
      platforms: f.platforms.includes(p) ? f.platforms.filter(x => x !== p) : [...f.platforms, p],
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.title) return;
    const payload = {
      title: form.title,
      status: form.status,
      isCore: form.isCore,
      weekId: item ? (item.weekId ?? undefined) : currentWeekId,
      pillar: form.pillar || undefined,
      format: form.format || undefined,
      hook: form.hook || undefined,
      angle: form.angle || undefined,
      platforms: form.platforms.length ? form.platforms : undefined,
      founderMinutes: form.founderMinutes ? parseInt(form.founderMinutes) : undefined,
      notes: form.notes || undefined,
    };
    if (item) {
      await updateItem.mutateAsync({ id: item.id, data: payload });
    } else {
      await createItem.mutateAsync({ data: payload });
    }
    invalidate();
    onClose();
  };

  const handleDelete = async () => {
    if (!item) return;
    await deleteItem.mutateAsync({ id: item.id });
    invalidate();
    setDeleteOpen(false);
    onClose();
  };

  const isLoading = createItem.isPending || updateItem.isPending;

  return (
    <>
      <FormDialog
        open={open}
        onClose={onClose}
        title={item ? "Edit Content" : "Add Content Idea"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1.5">
            <Label>Title *</Label>
            <Input
              placeholder="Content title or working title"
              value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))}
              required
              autoFocus
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as ContentItemInputStatus }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="idea">Idea</SelectItem>
                  <SelectItem value="selected">Selected</SelectItem>
                  <SelectItem value="brief">Brief</SelectItem>
                  <SelectItem value="script">Script</SelectItem>
                  <SelectItem value="film">Film</SelectItem>
                  <SelectItem value="edit">Edit</SelectItem>
                  <SelectItem value="review">Review</SelectItem>
                  <SelectItem value="schedule">Schedule</SelectItem>
                  <SelectItem value="posted">Posted</SelectItem>
                  <SelectItem value="measured">Measured</SelectItem>
                  <SelectItem value="archive">Archive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-1.5">
              <Label>Pillar</Label>
              <Input
                placeholder="e.g. Education"
                value={form.pillar}
                onChange={e => setForm(f => ({ ...f, pillar: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Format</Label>
              <Input
                placeholder="e.g. Short video"
                value={form.format}
                onChange={e => setForm(f => ({ ...f, format: e.target.value }))}
              />
            </div>

            <div className="space-y-1.5">
              <Label>Founder Minutes</Label>
              <Input
                type="number"
                min="0"
                placeholder="0"
                value={form.founderMinutes}
                onChange={e => setForm(f => ({ ...f, founderMinutes: e.target.value }))}
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Hook</Label>
            <Input
              placeholder="The opening hook line"
              value={form.hook}
              onChange={e => setForm(f => ({ ...f, hook: e.target.value }))}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Angle</Label>
            <Input
              placeholder="Content angle or perspective"
              value={form.angle}
              onChange={e => setForm(f => ({ ...f, angle: e.target.value }))}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Platforms</Label>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map(p => (
                <button
                  key={p}
                  type="button"
                  onClick={() => togglePlatform(p)}
                  className={`px-2.5 py-1 rounded text-xs font-medium border transition-colors ${
                    form.platforms.includes(p)
                      ? "bg-primary text-primary-foreground border-primary"
                      : "bg-background border-input text-muted-foreground hover:text-foreground"
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Input
              placeholder="Optional notes"
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            />
          </div>

          <div className="flex items-center gap-2">
            <Checkbox
              id="isCore"
              checked={form.isCore}
              onCheckedChange={v => setForm(f => ({ ...f, isCore: !!v }))}
            />
            <Label htmlFor="isCore">Mark as Core Piece (counts toward 4/week limit)</Label>
          </div>

          <FormDialogFooter>
            <div>
              {item && (
                <Button type="button" variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => setDeleteOpen(true)}>
                  <Trash2 className="w-4 h-4 mr-1" /> Delete
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {item ? "Save Changes" : "Add Content"}
              </Button>
            </div>
          </FormDialogFooter>
        </form>
      </FormDialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Content Item?</AlertDialogTitle>
            <AlertDialogDescription>This content item will be permanently deleted.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
