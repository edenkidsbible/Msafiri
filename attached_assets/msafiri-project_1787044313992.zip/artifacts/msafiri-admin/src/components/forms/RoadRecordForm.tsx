import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateRoadRecord, useUpdateRoadRecord,
  getListRoadRecordsQueryKey,
  getGetDashboardActivityQueryKey,
} from "@workspace/api-client-react";
import type { RoadRecord, RoadRecordInputDataType, RoadRecordInputConfidence, RoadRecordInputStatus } from "@workspace/api-client-react";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";

interface RoadRecordFormProps {
  open: boolean;
  onClose: () => void;
  record?: RoadRecord;
}

export function RoadRecordForm({ open, onClose, record }: RoadRecordFormProps) {
  const qc = useQueryClient();
  const createRecord = useCreateRoadRecord();
  const updateRecord = useUpdateRoadRecord();

  const [form, setForm] = useState({
    county: record?.county ?? "",
    corridor: record?.corridor ?? "",
    dataType: (record?.dataType ?? "speed_limit") as RoadRecordInputDataType,
    confidence: (record?.confidence ?? "C") as RoadRecordInputConfidence,
    status: (record?.status ?? "active") as RoadRecordInputStatus,
    speedLimitKph: record?.speedLimitKph?.toString() ?? "",
    landmark: record?.landmark ?? "",
    coordinates: record?.coordinates ?? "",
    evidence: record?.evidence ?? "",
    verifier: record?.verifier ?? "",
    notes: record?.notes ?? "",
  });

  useEffect(() => {
    if (open) {
      setForm({
        county: record?.county ?? "",
        corridor: record?.corridor ?? "",
        dataType: (record?.dataType ?? "speed_limit") as RoadRecordInputDataType,
        confidence: (record?.confidence ?? "C") as RoadRecordInputConfidence,
        status: (record?.status ?? "active") as RoadRecordInputStatus,
        speedLimitKph: record?.speedLimitKph?.toString() ?? "",
        landmark: record?.landmark ?? "",
        coordinates: record?.coordinates ?? "",
        evidence: record?.evidence ?? "",
        verifier: record?.verifier ?? "",
        notes: record?.notes ?? "",
      });
    }
  }, [open, record]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getListRoadRecordsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardActivityQueryKey() });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.county || !form.corridor || !form.dataType || !form.confidence) return;
    const payload = {
      county: form.county,
      corridor: form.corridor,
      dataType: form.dataType,
      confidence: form.confidence,
      status: form.status || undefined,
      speedLimitKph: form.speedLimitKph ? parseInt(form.speedLimitKph) : undefined,
      landmark: form.landmark || undefined,
      coordinates: form.coordinates || undefined,
      evidence: form.evidence || undefined,
      verifier: form.verifier || undefined,
      notes: form.notes || undefined,
    };
    if (record) {
      await updateRecord.mutateAsync({ id: record.id, data: payload });
    } else {
      await createRecord.mutateAsync({ data: payload });
    }
    invalidate();
    onClose();
  };

  const isLoading = createRecord.isPending || updateRecord.isPending;
  const isConfidenceA = form.confidence === "A";

  return (
    <FormDialog
      open={open}
      onClose={onClose}
      title={record ? "Edit Road Record" : "Add Road Record"}
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>County *</Label>
            <Input
              placeholder="e.g. Nairobi"
              value={form.county}
              onChange={e => setForm(f => ({ ...f, county: e.target.value }))}
              required
              autoFocus
            />
          </div>
          <div className="space-y-1.5">
            <Label>Corridor *</Label>
            <Input
              placeholder="e.g. Uhuru Highway"
              value={form.corridor}
              onChange={e => setForm(f => ({ ...f, corridor: e.target.value }))}
              required
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Data Type *</Label>
            <Select value={form.dataType} onValueChange={v => setForm(f => ({ ...f, dataType: v as RoadRecordInputDataType }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="speed_camera">Speed Camera</SelectItem>
                <SelectItem value="speed_limit">Speed Limit</SelectItem>
                <SelectItem value="road_hazard">Road Hazard</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Confidence *</Label>
            <Select value={form.confidence} onValueChange={v => setForm(f => ({ ...f, confidence: v as RoadRecordInputConfidence }))}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="A">A – Confirmed</SelectItem>
                <SelectItem value="B">B – Strong</SelectItem>
                <SelectItem value="C">C – Community</SelectItem>
                <SelectItem value="D">D – Unverified</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {form.dataType === "speed_limit" && (
          <div className="space-y-1.5">
            <Label>Speed Limit (km/h)</Label>
            <Input type="number" min="0" placeholder="e.g. 80" value={form.speedLimitKph} onChange={e => setForm(f => ({ ...f, speedLimitKph: e.target.value }))} />
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5">
            <Label>Landmark</Label>
            <Input placeholder="Nearby landmark" value={form.landmark} onChange={e => setForm(f => ({ ...f, landmark: e.target.value }))} />
          </div>
          <div className="space-y-1.5">
            <Label>Coordinates</Label>
            <Input placeholder="lat,lng" value={form.coordinates} onChange={e => setForm(f => ({ ...f, coordinates: e.target.value }))} />
          </div>
        </div>

        <div className="space-y-1.5">
          <Label>Status</Label>
          <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as RoadRecordInputStatus }))}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="needs_verification">Needs Verification</SelectItem>
              <SelectItem value="archived">Archived</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isConfidenceA && (
          <div className="p-3 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 rounded-lg space-y-3">
            <p className="text-xs font-medium text-emerald-700 dark:text-emerald-400">
              Confidence A requires evidence + verifier
            </p>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Evidence *</Label>
                <Input placeholder="Source of confirmation" value={form.evidence} onChange={e => setForm(f => ({ ...f, evidence: e.target.value }))} required={isConfidenceA} />
              </div>
              <div className="space-y-1.5">
                <Label>Verifier *</Label>
                <Input placeholder="Who verified this?" value={form.verifier} onChange={e => setForm(f => ({ ...f, verifier: e.target.value }))} required={isConfidenceA} />
              </div>
            </div>
          </div>
        )}

        <div className="space-y-1.5">
          <Label>Notes</Label>
          <Input placeholder="Optional notes" value={form.notes} onChange={e => setForm(f => ({ ...f, notes: e.target.value }))} />
        </div>

        <FormDialogFooter>
          <div />
          <div className="flex gap-2">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
              {record ? "Save Changes" : "Add Record"}
            </Button>
          </div>
        </FormDialogFooter>
      </form>
    </FormDialog>
  );
}
