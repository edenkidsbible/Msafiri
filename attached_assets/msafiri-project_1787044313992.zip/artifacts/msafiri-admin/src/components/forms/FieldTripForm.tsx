import { useState, useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  useCreateFieldTrip, useUpdateFieldTrip, useDeleteFieldTrip,
  getListFieldTripsQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetDashboardActivityQueryKey,
} from "@workspace/api-client-react";
import type { FieldTrip, FieldTripInputStatus } from "@workspace/api-client-react";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Trash2 } from "lucide-react";

interface FieldTripFormProps {
  open: boolean;
  onClose: () => void;
  trip?: FieldTrip;
}

export function FieldTripForm({ open, onClose, trip }: FieldTripFormProps) {
  const qc = useQueryClient();
  const createTrip = useCreateFieldTrip();
  const updateTrip = useUpdateFieldTrip();
  const deleteTrip = useDeleteFieldTrip();
  const [deleteOpen, setDeleteOpen] = useState(false);

  const today = new Date().toISOString().split("T")[0];

  const [form, setForm] = useState({
    date: trip?.date?.split("T")[0] ?? today,
    purpose: trip?.purpose ?? "",
    corridor: trip?.corridor ?? "",
    status: (trip?.status ?? "planned") as FieldTripInputStatus,
    plannedKm: trip?.plannedKm?.toString() ?? "",
    parkingKes: trip?.parkingKes?.toString() ?? "",
    tollsKes: trip?.tollsKes?.toString() ?? "",
    contingencyKes: "",
    requiredOutputs: trip?.requiredOutputs ?? "",
    notes: trip?.notes ?? "",
  });

  useEffect(() => {
    if (open) {
      setForm({
        date: trip?.date?.split("T")[0] ?? today,
        purpose: trip?.purpose ?? "",
        corridor: trip?.corridor ?? "",
        status: (trip?.status ?? "planned") as FieldTripInputStatus,
        plannedKm: trip?.plannedKm?.toString() ?? "",
        parkingKes: trip?.parkingKes?.toString() ?? "",
        tollsKes: trip?.tollsKes?.toString() ?? "",
        contingencyKes: "",
        requiredOutputs: trip?.requiredOutputs ?? "",
        notes: trip?.notes ?? "",
      });
    }
  }, [open, trip]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getListFieldTripsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetDashboardActivityQueryKey() });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.date || !form.purpose) return;
    const payload = {
      date: form.date,
      purpose: form.purpose,
      corridor: form.corridor || undefined,
      status: form.status || undefined,
      plannedKm: form.plannedKm ? parseFloat(form.plannedKm) : undefined,
      parkingKes: form.parkingKes || undefined,
      tollsKes: form.tollsKes || undefined,
      contingencyKes: form.contingencyKes || undefined,
      requiredOutputs: form.requiredOutputs || undefined,
      notes: form.notes || undefined,
    };
    if (trip) {
      await updateTrip.mutateAsync({ id: trip.id, data: payload });
    } else {
      await createTrip.mutateAsync({ data: payload });
    }
    invalidate();
    onClose();
  };

  const handleDelete = async () => {
    if (!trip) return;
    await deleteTrip.mutateAsync({ id: trip.id });
    invalidate();
    setDeleteOpen(false);
    onClose();
  };

  const isLoading = createTrip.isPending || updateTrip.isPending;

  return (
    <>
      <FormDialog
        open={open}
        onClose={onClose}
        title={trip ? "Edit Field Trip" : "Plan Field Trip"}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Date *</Label>
              <Input
                type="date"
                value={form.date}
                onChange={e => setForm(f => ({ ...f, date: e.target.value }))}
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>Status</Label>
              <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as FieldTripInputStatus }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="planned">Planned</SelectItem>
                  <SelectItem value="in_progress">In Progress</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="cancelled">Cancelled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Purpose *</Label>
            <Input
              placeholder="What is the trip for?"
              value={form.purpose}
              onChange={e => setForm(f => ({ ...f, purpose: e.target.value }))}
              required
              autoFocus
            />
          </div>

          <div className="space-y-1.5">
            <Label>Corridor / Route</Label>
            <Input
              placeholder="e.g. Nairobi → Mombasa"
              value={form.corridor}
              onChange={e => setForm(f => ({ ...f, corridor: e.target.value }))}
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1.5">
              <Label>Planned KM</Label>
              <Input type="number" min="0" placeholder="0" value={form.plannedKm} onChange={e => setForm(f => ({ ...f, plannedKm: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Parking (KES)</Label>
              <Input type="number" min="0" step="0.01" placeholder="0" value={form.parkingKes} onChange={e => setForm(f => ({ ...f, parkingKes: e.target.value }))} />
            </div>
            <div className="space-y-1.5">
              <Label>Tolls (KES)</Label>
              <Input type="number" min="0" step="0.01" placeholder="0" value={form.tollsKes} onChange={e => setForm(f => ({ ...f, tollsKes: e.target.value }))} />
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Contingency (KES)</Label>
            <Input type="number" min="0" step="0.01" placeholder="0" value={form.contingencyKes} onChange={e => setForm(f => ({ ...f, contingencyKes: e.target.value }))} />
          </div>

          <div className="space-y-1.5">
            <Label>Required Outputs</Label>
            <Input
              placeholder="What must come back from this trip?"
              value={form.requiredOutputs}
              onChange={e => setForm(f => ({ ...f, requiredOutputs: e.target.value }))}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Notes</Label>
            <Input
              placeholder="Optional notes"
              value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
            />
          </div>

          <FormDialogFooter>
            <div>
              {trip && (
                <Button type="button" variant="ghost" size="sm" className="text-destructive hover:text-destructive" onClick={() => setDeleteOpen(true)}>
                  <Trash2 className="w-4 h-4 mr-1" /> Delete
                </Button>
              )}
            </div>
            <div className="flex gap-2">
              <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
              <Button type="submit" disabled={isLoading}>
                {isLoading && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}
                {trip ? "Save Changes" : "Plan Trip"}
              </Button>
            </div>
          </FormDialogFooter>
        </form>
      </FormDialog>

      <AlertDialog open={deleteOpen} onOpenChange={setDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Field Trip?</AlertDialogTitle>
            <AlertDialogDescription>This field trip will be permanently deleted.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
