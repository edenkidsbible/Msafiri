import { useEffect, useMemo } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import { useQueryClient } from "@tanstack/react-query";
import { 
  useListUsers,
  useListDepartments, 
  useListTeamMembers,
  useCreateTeamMember, 
  useUpdateTeamMember, 
  getListUsersQueryKey,
  getListTeamMembersQueryKey, 
  getListDepartmentsQueryKey,
  type TeamMemberWithUser 
} from "@workspace/api-client-react";
import { toast } from "sonner";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const memberSchema = z.object({
  userId: z.string().min(1, "User is required").optional(), // Optional for edit
  role: z.enum(["owner", "admin", "member", "viewer"]),
  departmentId: z.coerce.number().optional().nullable(),
  notes: z.string().optional(),
  isActive: z.boolean().default(true),
});

type MemberFormValues = z.infer<typeof memberSchema>;

interface TeamMemberFormProps {
  open: boolean;
  onClose: () => void;
  member?: TeamMemberWithUser;
}

export function TeamMemberForm({ open, onClose, member }: TeamMemberFormProps) {
  const queryClient = useQueryClient();
  
  const { data: users } = useListUsers({ query: { enabled: open && !member, queryKey: getListUsersQueryKey() } });
  const { data: teamMembers } = useListTeamMembers({ query: { enabled: open && !member, queryKey: getListTeamMembersQueryKey() } });
  const { data: departments } = useListDepartments({ query: { enabled: open, queryKey: getListDepartmentsQueryKey() } });
  
  const createMember = useCreateTeamMember();
  const updateMember = useUpdateTeamMember();
  
  // Filter users to only show those who aren't already team members
  const availableUsers = useMemo(() => {
    if (!users || !teamMembers) return [];
    const teamUserIds = new Set(teamMembers.map(tm => tm.userId));
    return users.filter(u => !teamUserIds.has(u.id));
  }, [users, teamMembers]);

  const form = useForm<MemberFormValues>({
    resolver: zodResolver(memberSchema),
    defaultValues: {
      userId: "",
      role: "member",
      departmentId: null,
      notes: "",
      isActive: true,
    },
  });

  useEffect(() => {
    if (open) {
      if (member) {
        form.reset({
          userId: member.userId,
          role: (member.role as "owner"|"admin"|"member"|"viewer") || "member",
          departmentId: member.departmentId,
          notes: member.notes || "",
          isActive: member.isActive,
        });
      } else {
        form.reset({
          userId: "",
          role: "member",
          departmentId: null,
          notes: "",
          isActive: true,
        });
      }
    }
  }, [open, member, form]);

  const onSubmit = (data: MemberFormValues) => {
    // Convert null to undefined for API if needed, or pass directly
    if (member) {
      updateMember.mutate({ 
        id: member.id, 
        data: {
          role: data.role,
          departmentId: data.departmentId === null ? undefined : data.departmentId,
          isActive: data.isActive,
          notes: data.notes
        } 
      }, {
        onSuccess: () => {
          toast.success("Team member updated");
          queryClient.invalidateQueries({ queryKey: getListTeamMembersQueryKey() });
          onClose();
        },
        onError: () => toast.error("Failed to update team member")
      });
    } else {
      if (!data.userId) {
        form.setError("userId", { message: "Please select a user" });
        return;
      }
      createMember.mutate({ 
        data: {
          userId: data.userId,
          role: data.role,
          departmentId: data.departmentId === null ? undefined : data.departmentId,
          notes: data.notes
        }
      }, {
        onSuccess: () => {
          toast.success("Team member added");
          queryClient.invalidateQueries({ queryKey: getListTeamMembersQueryKey() });
          onClose();
        },
        onError: (err: any) => {
          toast.error(err.response?.data?.error || "Failed to add team member");
        }
      });
    }
  };

  const isPending = createMember.isPending || updateMember.isPending;

  return (
    <FormDialog
      open={open}
      onClose={onClose}
      title={member ? "Edit Team Member" : "Add Team Member"}
      description={member ? "Update role and department" : "Add an existing user to the team roster"}
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          
          {!member && (
            <FormField
              control={form.control}
              name="userId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>User</FormLabel>
                  <Select onValueChange={field.onChange} value={field.value} disabled={isPending}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a user" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {availableUsers.map(user => (
                        <SelectItem key={user.id} value={user.id}>
                          <div className="flex items-center gap-2">
                            <Avatar className="w-6 h-6">
                              <AvatarImage src={user.profileImageUrl || ""} />
                              <AvatarFallback className="text-[10px]">
                                {(user.firstName?.[0] || user.username?.[0] || "?").toUpperCase()}
                              </AvatarFallback>
                            </Avatar>
                            <span>
                              {user.firstName ? `${user.firstName} ${user.lastName || ''}` : (user.username || user.email || user.id)}
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                      {availableUsers.length === 0 && (
                        <div className="p-2 text-sm text-muted-foreground text-center">No available users found</div>
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          )}

          <FormField
            control={form.control}
            name="role"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Role</FormLabel>
                <Select onValueChange={field.onChange} value={field.value} disabled={isPending}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select role" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="owner">Owner (Full access)</SelectItem>
                    <SelectItem value="admin">Admin (Manage team & settings)</SelectItem>
                    <SelectItem value="member">Member (Read & write data)</SelectItem>
                    <SelectItem value="viewer">Viewer (Read-only)</SelectItem>
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="departmentId"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Department (Optional)</FormLabel>
                <Select 
                  onValueChange={(val) => field.onChange(val === "none" ? null : parseInt(val))} 
                  value={field.value ? field.value.toString() : "none"} 
                  disabled={isPending}
                >
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="No department" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent>
                    <SelectItem value="none">None</SelectItem>
                    {departments?.map(dept => (
                      <SelectItem key={dept.id} value={dept.id.toString()}>
                        {dept.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes (Optional)</FormLabel>
                <FormControl>
                  <Textarea placeholder="Internal notes about this member" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {member && (
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Active Status</FormLabel>
                    <FormDescription>
                      Deactivate to revoke access to team resources without deleting history.
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                      disabled={isPending}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          )}

          <FormDialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : "Save Member"}
            </Button>
          </FormDialogFooter>
        </form>
      </Form>
    </FormDialog>
  );
}
