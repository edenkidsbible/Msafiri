import { useEffect } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage, FormDescription } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { FormDialog, FormDialogFooter } from "@/components/ui/form-dialog";
import { useQueryClient } from "@tanstack/react-query";
import { useListDepartments, useCreateDepartment, useUpdateDepartment, getListDepartmentsQueryKey, type Department } from "@workspace/api-client-react";
import { toast } from "sonner";

const departmentSchema = z.object({
  name: z.string().min(1, "Name is required").max(100),
  description: z.string().max(500).optional(),
  isActive: z.boolean().default(true),
});

type DepartmentFormValues = z.infer<typeof departmentSchema>;

interface DepartmentFormProps {
  open: boolean;
  onClose: () => void;
  department?: Department;
}

export function DepartmentForm({ open, onClose, department }: DepartmentFormProps) {
  const queryClient = useQueryClient();
  const createDept = useCreateDepartment();
  const updateDept = useUpdateDepartment();
  
  const form = useForm<DepartmentFormValues>({
    resolver: zodResolver(departmentSchema),
    defaultValues: {
      name: "",
      description: "",
      isActive: true,
    },
  });

  useEffect(() => {
    if (open) {
      if (department) {
        form.reset({
          name: department.name,
          description: department.description || "",
          isActive: department.isActive,
        });
      } else {
        form.reset({
          name: "",
          description: "",
          isActive: true,
        });
      }
    }
  }, [open, department, form]);

  const onSubmit = (data: DepartmentFormValues) => {
    if (department) {
      updateDept.mutate({ id: department.id, data }, {
        onSuccess: () => {
          toast.success("Department updated");
          queryClient.invalidateQueries({ queryKey: getListDepartmentsQueryKey() });
          onClose();
        },
        onError: () => toast.error("Failed to update department")
      });
    } else {
      createDept.mutate({ data }, {
        onSuccess: () => {
          toast.success("Department created");
          queryClient.invalidateQueries({ queryKey: getListDepartmentsQueryKey() });
          onClose();
        },
        onError: () => toast.error("Failed to create department")
      });
    }
  };

  const isPending = createDept.isPending || updateDept.isPending;

  return (
    <FormDialog
      open={open}
      onClose={onClose}
      title={department ? "Edit Department" : "New Department"}
      description={department ? "Update department details" : "Create a new department for the team"}
    >
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="name"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Name</FormLabel>
                <FormControl>
                  <Input placeholder="Engineering" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <FormField
            control={form.control}
            name="description"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Description (Optional)</FormLabel>
                <FormControl>
                  <Textarea placeholder="Core engineering and product development" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          {department && (
            <FormField
              control={form.control}
              name="isActive"
              render={({ field }) => (
                <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                  <div className="space-y-0.5">
                    <FormLabel className="text-base">Active Status</FormLabel>
                    <FormDescription>
                      Inactive departments cannot be assigned to new team members.
                    </FormDescription>
                  </div>
                  <FormControl>
                    <Switch
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                </FormItem>
              )}
            />
          )}

          <FormDialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={isPending}>
              Cancel
            </Button>
            <Button type="submit" disabled={isPending}>
              {isPending ? "Saving..." : "Save Department"}
            </Button>
          </FormDialogFooter>
        </form>
      </Form>
    </FormDialog>
  );
}
