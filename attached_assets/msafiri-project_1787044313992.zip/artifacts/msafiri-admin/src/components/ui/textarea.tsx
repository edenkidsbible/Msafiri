import * as React from 'react';
import { cn } from '@/lib/utils';

/** Auto-expands to fit content — never shows a scrollbar. */
const Textarea = React.forwardRef<
  HTMLTextAreaElement,
  React.ComponentProps<'textarea'>
>(({ className, onChange, ...props }, ref) => {
  const innerRef = React.useRef<HTMLTextAreaElement>(null);

  const setRef = React.useCallback(
    (el: HTMLTextAreaElement | null) => {
      (innerRef as React.MutableRefObject<HTMLTextAreaElement | null>).current = el;
      if (typeof ref === 'function') ref(el);
      else if (ref) (ref as React.MutableRefObject<HTMLTextAreaElement | null>).current = el;
      // Resize on first mount
      if (el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [ref],
  );

  // Re-sync when the value prop changes (controlled input)
  React.useEffect(() => {
    const el = innerRef.current;
    if (el) { el.style.height = 'auto'; el.style.height = el.scrollHeight + 'px'; }
  }, [props.value, props.defaultValue]);

  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const el = e.target;
    el.style.height = 'auto';
    el.style.height = el.scrollHeight + 'px';
    onChange?.(e);
  };

  return (
    <textarea
      className={cn(
        'flex min-h-[60px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 md:text-sm resize-none overflow-hidden',
        className,
      )}
      ref={setRef}
      onChange={handleChange}
      {...props}
    />
  );
});
Textarea.displayName = 'Textarea';

export { Textarea };
