import * as React from "react"

interface TooltipProviderProps {
  children: React.ReactNode;
  delayDuration?: number;
  skipDelayDuration?: number;
  disableHoverableContent?: boolean;
}
export function TooltipProvider({ children }: TooltipProviderProps) {
  return <>{children}</>;
}

interface TooltipProps { children: React.ReactNode; open?: boolean; defaultOpen?: boolean; onOpenChange?: (v: boolean) => void; }
export const Tooltip = ({ children }: TooltipProps) => <>{children}</>;

interface TooltipTriggerProps { children: React.ReactNode; asChild?: boolean; }
export const TooltipTrigger = ({ children }: TooltipTriggerProps) => <>{children}</>;

interface TooltipContentProps { children?: React.ReactNode; side?: string; align?: string; hidden?: boolean; sideOffset?: number; className?: string; }
export const TooltipContent = ({ children, hidden }: TooltipContentProps) =>
  hidden ? null : (children ? <div className="z-50 overflow-hidden rounded-md border bg-popover px-3 py-1.5 text-sm text-popover-foreground shadow-md">{children}</div> : null);
