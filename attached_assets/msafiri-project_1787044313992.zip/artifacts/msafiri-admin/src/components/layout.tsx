import { ReactNode, useState } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  CalendarDays,
  Wallet,
  Users,
  CheckSquare,
  Video,
  Map,
  FileUp,
  Settings,
  UsersRound,
  MessageCircle,
  ChevronRight,
  Building2,
  Banknote,
  Megaphone,
  Truck,
  Cpu,
  Handshake,
  PlusCircle,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQuery } from "@tanstack/react-query";
import { useGetCurrentAuthUser } from "@workspace/api-client-react";

interface LayoutProps {
  children: ReactNode;
}

// ─── Static top-level items (always shown) ────────────────────────────────────

const TOP_ITEMS = [
  { href: "/", label: "Home", icon: LayoutDashboard },
  { href: "/this-week", label: "This Week", icon: CalendarDays },
];

// ─── Department → page mapping ────────────────────────────────────────────────
// Maps lowercase keyword fragments in the dept name to sub-nav items.

const DEPT_PAGE_MAP: Array<{
  keywords: string[];
  icon: React.FC<{ className?: string }>;
  pages: Array<{ href: string; label: string; icon: React.FC<{ className?: string }> }>;
}> = [
  {
    keywords: ["operation"],
    icon: Building2,
    pages: [{ href: "/tasks", label: "Tasks", icon: CheckSquare }],
  },
  {
    keywords: ["finance"],
    icon: Banknote,
    pages: [
      { href: "/money", label: "Money", icon: Wallet },
      { href: "/subscriptions", label: "Users & Revenue", icon: Users },
    ],
  },
  {
    keywords: ["marketing", "content"],
    icon: Megaphone,
    pages: [{ href: "/content", label: "Content", icon: Video }],
  },
  {
    keywords: ["field", "logistic", "transport", "road"],
    icon: Truck,
    pages: [{ href: "/field", label: "Field & Road", icon: Map }],
  },
  {
    keywords: ["tech", "product", "engineering", "digital"],
    icon: Cpu,
    pages: [],
  },
  {
    keywords: ["partner", "growth", "business development"],
    icon: Handshake,
    pages: [],
  },
];

function getDeptMeta(name: string) {
  const lower = name.toLowerCase();
  for (const entry of DEPT_PAGE_MAP) {
    if (entry.keywords.some((k) => lower.includes(k))) {
      return entry;
    }
  }
  return { icon: Building2, pages: [] };
}

// ─── System items (always at bottom) ─────────────────────────────────────────

const SYSTEM_ITEMS = [
  { href: "/team", label: "Team", icon: UsersRound },
  { href: "/import", label: "Import", icon: FileUp },
  { href: "/settings", label: "Settings", icon: Settings },
];

// ─── NavLink ─────────────────────────────────────────────────────────────────

function NavLink({
  href,
  label,
  icon: Icon,
  indent = false,
  badge,
}: {
  href: string;
  label: string;
  icon: React.FC<{ className?: string }>;
  indent?: boolean;
  badge?: number;
}) {
  const [location] = useLocation();
  const isActive = location === href || (href !== "/" && location.startsWith(href));

  return (
    <Link
      href={href}
      className={cn(
        "flex items-center gap-3 rounded-md text-sm font-medium transition-colors",
        indent ? "px-3 py-1.5 ml-3" : "px-3 py-2",
        isActive
          ? "bg-sidebar-accent text-sidebar-accent-foreground"
          : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
      )}
    >
      <Icon className={cn("shrink-0", indent ? "w-3.5 h-3.5" : "w-4 h-4")} />
      <span className="flex-1 truncate">{label}</span>
      {badge != null && badge > 0 && (
        <span className="shrink-0 min-w-[18px] h-[18px] rounded-full bg-primary text-primary-foreground text-[10px] font-bold flex items-center justify-center px-1">
          {badge > 99 ? "99+" : badge}
        </span>
      )}
    </Link>
  );
}

// ─── DepartmentGroup ─────────────────────────────────────────────────────────

function DepartmentGroup({
  name,
  isActive,
}: {
  name: string;
  isActive: boolean;
}) {
  const meta = getDeptMeta(name);
  const Icon = meta.icon;
  const [open, setOpen] = useState(isActive || meta.pages.length === 0 ? false : isActive);

  // Auto-open if a child page is active
  const [location] = useLocation();
  const childActive = meta.pages.some(
    (p) => location === p.href || (p.href !== "/" && location.startsWith(p.href)),
  );

  const expanded = open || childActive;

  if (meta.pages.length === 0) {
    // Department with no pages: just a label
    return (
      <div className="px-3 py-1.5 flex items-center gap-3 text-sm text-sidebar-foreground/40 cursor-default select-none">
        <Icon className="w-4 h-4 shrink-0" />
        <span className="flex-1 truncate">{name}</span>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => setOpen((v) => !v)}
        className={cn(
          "w-full flex items-center gap-3 px-3 py-2 rounded-md text-sm font-medium transition-colors text-left",
          childActive
            ? "text-sidebar-accent-foreground"
            : "text-sidebar-foreground/80 hover:bg-sidebar-accent/50 hover:text-sidebar-accent-foreground",
        )}
      >
        <Icon className="w-4 h-4 shrink-0" />
        <span className="flex-1 truncate">{name}</span>
        <ChevronRight className={cn("w-3.5 h-3.5 shrink-0 transition-transform", expanded && "rotate-90")} />
      </button>
      {expanded && (
        <div className="space-y-0.5 mt-0.5">
          {meta.pages.map((page) => (
            <NavLink key={page.href} href={page.href} label={page.label} icon={page.icon} indent />
          ))}
        </div>
      )}
    </div>
  );
}

// ─── Layout ───────────────────────────────────────────────────────────────────

const BASE = (import.meta as any).env?.BASE_URL?.replace?.(/\/$/, "") ?? "";

export function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const { data: auth } = useGetCurrentAuthUser();

  // Fetch departments for sidebar
  const { data: departments } = useQuery<Array<{ id: number; name: string; isActive: boolean }>>({
    queryKey: ["sidebar-departments"],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/team/departments`, { credentials: "include" });
      if (!res.ok) return [];
      return res.json();
    },
    staleTime: 60_000,
  });

  // Fetch unread count for Chat badge
  const { data: unreadData } = useQuery<{ total: number }>({
    queryKey: ["chat", "unread"],
    queryFn: async () => {
      const res = await fetch(`${BASE}/api/chat/unread`, { credentials: "include" });
      if (!res.ok) return { total: 0 };
      return res.json();
    },
    refetchInterval: 30_000,
    staleTime: 0,
  });

  const unread = unreadData?.total ?? 0;
  const activeDepts = departments?.filter((d) => d.isActive) ?? [];

  // Role-based visibility
  const role = auth?.role ?? "member";
  const isOwnerOrAdmin = role === "owner" || role === "admin";
  const userDeptName: string | null = (auth as any)?.departmentName ?? null;

  // Which departments to show in the sidebar:
  // owners/admins → all; members/viewers → only their own department
  const visibleDepts = isOwnerOrAdmin
    ? activeDepts
    : userDeptName
      ? activeDepts.filter((d) => d.name === userDeptName)
      : [];

  // Does this user's visible departments include Finance?
  const hasFinanceAccess = isOwnerOrAdmin || visibleDepts.some((d) =>
    d.name.toLowerCase().includes("finance")
  );

  const sidebarContent = (
    <>
      {/* Logo */}
      <div className="px-4 py-4 flex items-center gap-3">
        <img src="/logo.png" alt="Msafiri" className="w-9 h-9 rounded-lg object-contain bg-white" />
        <span className="text-[17px] font-bold tracking-tight text-white leading-none">
          Msafiri OS
        </span>
      </div>

      <nav className="flex-1 overflow-y-auto px-3 py-1 space-y-0.5">
        {/* Top items: Home, This Week */}
        {TOP_ITEMS.map((item) => (
          <NavLink key={item.href} href={item.href} label={item.label} icon={item.icon} />
        ))}

        {/* Chat */}
        <NavLink href="/chat" label="Chat" icon={MessageCircle} badge={unread} />

        {/* Log Expense — visible to everyone who doesn't already see the full Finance section */}
        {!hasFinanceAccess && (
          <NavLink href="/money?mode=log" label="Log Expense" icon={PlusCircle} />
        )}

        {/* Departments section */}
        {visibleDepts.length > 0 && (
          <>
            <p className="px-3 pt-4 pb-1 text-[10px] font-semibold text-sidebar-foreground/30 uppercase tracking-widest">
              {isOwnerOrAdmin ? "Departments" : "My Department"}
            </p>
            {visibleDepts.map((dept) => (
              <DepartmentGroup key={dept.id} name={dept.name} isActive={false} />
            ))}
          </>
        )}

        {/* System section */}
        <p className="px-3 pt-4 pb-1 text-[10px] font-semibold text-sidebar-foreground/30 uppercase tracking-widest">
          System
        </p>
        {SYSTEM_ITEMS.map((item) => (
          // Non-admin members only see Team + Settings (not Import)
          isOwnerOrAdmin || item.href !== "/import"
            ? <NavLink key={item.href} href={item.href} label={item.label} icon={item.icon} />
            : null
        ))}
      </nav>

      {/* User footer */}
      <div className="p-4 border-t border-sidebar-border text-xs text-sidebar-foreground/50 truncate">
        {auth?.firstName ?? auth?.email ?? "Logged in"}
        {auth?.role && (
          <span className="ml-1 text-primary/70 capitalize">· {auth.role}</span>
        )}
        {userDeptName && (
          <span className="block text-sidebar-foreground/30 truncate">{userDeptName}</span>
        )}
      </div>
    </>
  );

  return (
    <div className="flex h-[100dvh] w-full overflow-hidden bg-background">
      {/* Desktop Sidebar */}
      <aside className="hidden md:flex flex-col w-64 border-r border-sidebar-border bg-sidebar text-sidebar-foreground">
        {sidebarContent}
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden relative">
        <div className="flex-1 overflow-y-auto p-4 md:p-8 pb-24 md:pb-8">
          <div className="max-w-7xl mx-auto w-full animate-in">
            {children}
          </div>
        </div>
      </main>

      {/* Mobile Bottom Nav (5 most important) */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 border-t bg-card flex items-center justify-around px-2 py-3 z-50 safe-area-bottom">
        {[
          { href: "/", label: "Home", icon: LayoutDashboard },
          { href: "/this-week", label: "Week", icon: CalendarDays },
          { href: "/chat", label: "Chat", icon: MessageCircle, badge: unread },
          { href: "/team", label: "Team", icon: UsersRound },
          { href: "/settings", label: "Settings", icon: Settings },
        ].map((item) => {
          const isActive = location === item.href || (item.href !== "/" && location.startsWith(item.href));
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex flex-col items-center justify-center w-14 h-12 gap-1 rounded-md relative",
                isActive ? "text-primary" : "text-muted-foreground",
              )}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-[10px] font-medium leading-none">{item.label}</span>
              {(item as any).badge > 0 && (
                <span className="absolute top-0 right-1 min-w-[14px] h-[14px] rounded-full bg-primary text-primary-foreground text-[9px] font-bold flex items-center justify-center px-0.5">
                  {(item as any).badge}
                </span>
              )}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
