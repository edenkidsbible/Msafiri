import http from "http";
import app from "./app";
import { logger } from "./lib/logger";
import { attachWsServer } from "./lib/wsManager";
import { runSeed } from "./lib/seed";
import { getSession, getSessionId } from "./lib/auth";
import type { IncomingMessage } from "http";

const rawPort = process.env["PORT"];
if (!rawPort) throw new Error("PORT environment variable is required but was not provided.");
const port = Number(rawPort);
if (Number.isNaN(port) || port <= 0) throw new Error(`Invalid PORT value: "${rawPort}"`);

const server = http.createServer(app);

/** Resolve a Replit session user from an incoming WS upgrade request */
async function getSessionUser(req: IncomingMessage): Promise<{ id: string } | null> {
  // Parse cookies from the request headers
  const cookieHeader = req.headers["cookie"] ?? "";
  const cookies: Record<string, string> = {};
  for (const part of cookieHeader.split(";")) {
    const [k, ...v] = part.trim().split("=");
    if (k) cookies[k.trim()] = decodeURIComponent(v.join("="));
  }
  // Fake a minimal req object that getSessionId can work with (needs headers + cookies)
  const fakeReq = { cookies, headers: req.headers } as any;
  const sid = getSessionId(fakeReq);
  if (!sid) return null;
  const session = await getSession(sid);
  return session?.user?.id ? { id: session.user.id } : null;
}

attachWsServer(server, getSessionUser);

server.listen(port, async (err?: Error) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }
  logger.info({ port }, "Server listening");
  await runSeed();
});
