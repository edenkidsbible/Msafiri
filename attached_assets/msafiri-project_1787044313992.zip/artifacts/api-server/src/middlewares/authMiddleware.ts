import type { AuthUser } from '@workspace/api-zod';
import { type NextFunction, type Request, type Response } from 'express';
import { db, usersTable, teamMembersTable, departmentsTable } from '@workspace/db';
import { eq } from 'drizzle-orm';

// Role hierarchy: owner > admin > member > viewer
const ROLE_LEVEL: Record<string, number> = {
  owner: 4,
  admin: 3,
  member: 2,
  viewer: 1,
};

/**
 * Middleware factory that requires the authenticated user to have at least one
 * of the specified roles. Call after authMiddleware.
 *
 * Usage: router.delete('/settings', requireRole(['owner', 'admin']), handler)
 */
export function requireRole(roles: string[]) {
  return (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      res.status(401).json({ error: 'Unauthorized' });
      return;
    }
    const userRole = (req.user as any).role ?? 'member';
    const allowed = roles.some(
      (r) => (ROLE_LEVEL[userRole] ?? 0) >= (ROLE_LEVEL[r] ?? 0),
    );
    if (!allowed) {
      res
        .status(403)
        .json({ error: `Required role: ${roles.join(' or ')}` });
      return;
    }
    next();
  };
}

/** True if the user has at least the given role level. */
export function hasRole(req: Request, minRole: string): boolean {
  if (!req.isAuthenticated()) return false;
  const userRole = (req.user as any).role ?? 'member';
  return (ROLE_LEVEL[userRole] ?? 0) >= (ROLE_LEVEL[minRole] ?? 0);
}

import {
  clearSession,
  getSession,
  getSessionId,
} from '../lib/auth';

declare global {
  namespace Express {
    interface User extends AuthUser {}

    interface Request {
      isAuthenticated(): this is AuthedRequest;

      user?: User | undefined;
    }

    export interface AuthedRequest {
      user: User;
    }
  }
}

export async function authMiddleware(
  req: Request,
  res: Response,
  next: NextFunction,
) {
  req.isAuthenticated = function (this: Request) {
    return this.user != null;
  } as Request['isAuthenticated'];

  const sid = getSessionId(req);
  if (!sid) {
    next();
    return;
  }

  const session = await getSession(sid);
  if (!session?.user?.id) {
    await clearSession(res, sid);
    next();
    return;
  }

  // Always read authoritative role + department from DB so sessions stay fresh.
  if (session.user?.id) {
    const uid = session.user.id;

    const [[dbUser], [membership]] = await Promise.all([
      db.select({ role: usersTable.role })
        .from(usersTable)
        .where(eq(usersTable.id, uid)),
      db.select({
          departmentId: teamMembersTable.departmentId,
          departmentName: departmentsTable.name,
        })
        .from(teamMembersTable)
        .leftJoin(departmentsTable, eq(teamMembersTable.departmentId, departmentsTable.id))
        .where(eq(teamMembersTable.userId, uid))
        .limit(1),
    ]);

    req.user = {
      ...session.user,
      role: dbUser?.role ?? session.user.role ?? "member",
      departmentId: membership?.departmentId ?? null,
      departmentName: membership?.departmentName ?? null,
    } as Express.User;

    // Non-blocking last-seen update
    db.update(usersTable)
      .set({ lastSeenAt: new Date() })
      .where(eq(usersTable.id, uid))
      .catch(() => { /* silent */ });
  } else {
    req.user = session.user;
  }

  next();
}
