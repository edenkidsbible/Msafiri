/**
 * Runs on server startup to seed required data that must exist exactly once.
 * Safe to run repeatedly — checks existence before inserting.
 */
import { db, departmentsTable, conversationsTable, conversationMembersTable, usersTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { logger } from "./logger";

const SEED_DEPARTMENTS = [
  { name: "Operations", description: "Day-to-day business operations, logistics, and internal processes" },
  { name: "Finance", description: "Budgeting, cash flow, transactions, subscriptions, and revenue" },
  { name: "Marketing & Content", description: "Content creation, social media, brand, and audience growth" },
  { name: "Field & Logistics", description: "Field trips, road operations, vehicle management, and last-mile delivery" },
  { name: "Technology", description: "Product development, engineering, and digital infrastructure" },
  { name: "Partnerships & Growth", description: "Strategic partnerships, user acquisition, and business development" },
];

export async function runSeed() {
  try {
    // Seed departments
    for (const dept of SEED_DEPARTMENTS) {
      const [existing] = await db.select({ id: departmentsTable.id }).from(departmentsTable).where(eq(departmentsTable.name, dept.name));
      if (!existing) {
        await db.insert(departmentsTable).values(dept);
        logger.info({ name: dept.name }, "Seeded department");
      }
    }

    // Seed all_team conversation (exactly one)
    const [allTeamConv] = await db
      .select({ id: conversationsTable.id })
      .from(conversationsTable)
      .where(eq(conversationsTable.type, "all_team"));

    if (!allTeamConv) {
      const [conv] = await db
        .insert(conversationsTable)
        .values({ type: "all_team", name: "All Team" })
        .returning();

      // Add all existing users as members
      const users = await db.select({ id: usersTable.id }).from(usersTable);
      if (users.length > 0) {
        await db.insert(conversationMembersTable).values(
          users.map((u) => ({ conversationId: conv.id, userId: u.id })),
        );
      }
      logger.info("Seeded All Team conversation");
    } else {
      // Ensure all existing users are in the all_team conversation
      const users = await db.select({ id: usersTable.id }).from(usersTable);
      for (const user of users) {
        const [member] = await db
          .select({ id: conversationMembersTable.id })
          .from(conversationMembersTable)
          .where(
            sql`${conversationMembersTable.conversationId} = ${allTeamConv.id} AND ${conversationMembersTable.userId} = ${user.id}`,
          );
        if (!member) {
          await db.insert(conversationMembersTable).values({ conversationId: allTeamConv.id, userId: user.id });
        }
      }
    }

    // Seed department conversations and ensure all users are members of each
    const depts = await db.select({ id: departmentsTable.id, name: departmentsTable.name }).from(departmentsTable);
    const allUsers = await db.select({ id: usersTable.id }).from(usersTable);

    for (const dept of depts) {
      let convId: number;

      const [existing] = await db
        .select({ id: conversationsTable.id })
        .from(conversationsTable)
        .where(eq(conversationsTable.departmentId, dept.id));

      if (!existing) {
        const [conv] = await db
          .insert(conversationsTable)
          .values({ type: "department", departmentId: dept.id, name: dept.name })
          .returning();
        convId = conv.id;
        logger.info({ dept: dept.name }, "Seeded department conversation");
      } else {
        convId = existing.id;
      }

      // Ensure every user is a member of every department conversation
      // (small internal team — full transparency across channels)
      for (const user of allUsers) {
        const [member] = await db
          .select({ id: conversationMembersTable.id })
          .from(conversationMembersTable)
          .where(
            sql`${conversationMembersTable.conversationId} = ${convId} AND ${conversationMembersTable.userId} = ${user.id}`,
          );
        if (!member) {
          await db.insert(conversationMembersTable).values({ conversationId: convId, userId: user.id });
        }
      }
    }

    logger.info("Seed complete");
  } catch (err) {
    logger.error({ err }, "Seed failed");
  }
}
