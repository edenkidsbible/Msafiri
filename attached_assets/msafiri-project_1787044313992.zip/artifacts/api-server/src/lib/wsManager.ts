/**
 * WebSocket connection manager.
 * Maintains a map of userId → active WebSocket connection.
 * Exposed as a module-level singleton so routes can call broadcast().
 */
import { WebSocketServer, type WebSocket } from "ws";
import type { IncomingMessage } from "http";
import { logger } from "./logger";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const connections = new Map<string, WebSocket>();

export function registerConnection(userId: string, ws: WebSocket) {
  // Close any existing connection for this user
  const existing = connections.get(userId);
  if (existing && existing.readyState === existing.OPEN) {
    existing.close(1000, "replaced by new connection");
  }
  connections.set(userId, ws);
  logger.debug({ userId }, "WS connection registered");

  ws.on("close", () => {
    if (connections.get(userId) === ws) {
      connections.delete(userId);
      // Update lastSeenAt on disconnect
      db.update(usersTable)
        .set({ lastSeenAt: new Date() })
        .where(eq(usersTable.id, userId))
        .catch((err) => logger.error({ err }, "Failed to update lastSeenAt on disconnect"));
      logger.debug({ userId }, "WS connection closed");
    }
  });

  ws.on("error", (err) => {
    logger.error({ err, userId }, "WS error");
    connections.delete(userId);
  });
}

export function broadcast(userIds: string[], payload: unknown) {
  const data = JSON.stringify(payload);
  for (const uid of userIds) {
    const ws = connections.get(uid);
    if (ws && ws.readyState === ws.OPEN) {
      try {
        ws.send(data);
      } catch (err) {
        logger.error({ err, uid }, "Failed to send WS message");
      }
    }
  }
}

export function isOnline(userId: string): boolean {
  const ws = connections.get(userId);
  return ws != null && ws.readyState === ws.OPEN;
}

export function getOnlineUsers(): string[] {
  return Array.from(connections.keys());
}

/**
 * Attach the WebSocket upgrade handler to an HTTP server.
 * Authenticates via session cookie — reuses the same session
 * lookup as the HTTP auth middleware.
 */
export function attachWsServer(
  server: import("http").Server,
  getSessionUser: (req: IncomingMessage) => Promise<{ id: string } | null>,
) {
  const wss = new WebSocketServer({ server, path: "/api/ws" });

  wss.on("connection", async (ws, req) => {
    const user = await getSessionUser(req);
    if (!user) {
      ws.close(1008, "Unauthorized");
      return;
    }
    registerConnection(user.id, ws);

    // Heartbeat ping/pong
    const ping = setInterval(() => {
      if (ws.readyState === ws.OPEN) ws.ping();
    }, 30_000);

    ws.on("close", () => clearInterval(ping));

    ws.send(JSON.stringify({ type: "connected", userId: user.id }));
  });

  logger.info("WebSocket server attached at /api/ws");
  return wss;
}
