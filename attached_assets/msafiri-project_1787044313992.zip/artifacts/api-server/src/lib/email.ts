/**
 * Email service — uses Resend.
 * Set RESEND_API_KEY to enable sending. No-ops gracefully if not configured.
 * Set RESEND_FROM to a verified sender address (e.g. "Msafiri OS <noreply@yourdomain.com>").
 * Set APP_URL to control the base URL used in links (defaults to the msafirikenya.com domain).
 */
import { Resend } from "resend";
import { logger } from "./logger";

const resend = process.env["RESEND_API_KEY"]
  ? new Resend(process.env["RESEND_API_KEY"])
  : null;

// RESEND_FROM takes precedence; falls back to the verified msafirikenya.com sender
const FROM =
  process.env["RESEND_FROM"] ?? "Msafiri OS <noreply@msafirikenya.com>";

// APP_URL should be set to your production domain (e.g. https://msafiri.com).
// In dev the frontend lives under /msafiri-admin, so invite links use that prefix.
const BASE_URL =
  process.env["APP_URL"] ??
  (process.env["NODE_ENV"] === "production"
    ? "https://msafirikenya.replit.app"
    : `https://${process.env["REPL_SLUG"] ?? "msafirikenya"}.replit.app/msafiri-admin`);

/** Escape user-supplied strings before embedding them in HTML email templates. */
function esc(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#x27;");
}

interface MailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

export interface SendResult {
  delivered: boolean;
  error?: string;
}

/**
 * Send an email. Returns { delivered: true } on success, { delivered: false, error } on failure.
 * Never throws — callers should check the result and surface errors where appropriate.
 */
export async function sendMail(opts: MailOptions): Promise<SendResult> {
  if (!resend) {
    logger.warn(
      { to: opts.to, subject: opts.subject },
      "[email no-op] RESEND_API_KEY not configured",
    );
    return { delivered: false, error: "RESEND_API_KEY not configured" };
  }
  try {
    const { error } = await resend.emails.send({
      from: FROM,
      to: opts.to,
      subject: opts.subject,
      html: opts.html,
      text: opts.text,
    });
    if (error) {
      logger.error({ error, to: opts.to, subject: opts.subject }, "Resend delivery error");
      return { delivered: false, error: error.message };
    }
    logger.info({ to: opts.to, subject: opts.subject }, "Email sent via Resend");
    return { delivered: true };
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    logger.error({ err, to: opts.to, subject: opts.subject }, "Failed to send email");
    return { delivered: false, error: message };
  }
}

export function invitationEmail(opts: {
  inviterName: string;
  role: string;
  department?: string;
  token: string;
}): Pick<MailOptions, "subject" | "html" | "text"> {
  const link = `${BASE_URL}/accept-invite?token=${encodeURIComponent(opts.token)}`;
  const dept = opts.department ? ` in the <strong>${esc(opts.department)}</strong> department` : "";
  return {
    subject: `You've been invited to Msafiri OS`,
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;">
        <div style="background:#E53800;border-radius:8px;padding:20px 24px;margin-bottom:24px;">
          <h2 style="color:#fff;margin:0;font-size:20px;font-weight:700;">Msafiri Founder OS</h2>
        </div>
        <p style="color:#222;font-size:15px;">${esc(opts.inviterName)} has invited you to join the Msafiri team as a <strong>${esc(opts.role)}</strong>${dept}.</p>
        <p style="margin:24px 0;">
          <a href="${link}" style="background:#E53800;color:#fff;padding:14px 28px;border-radius:6px;text-decoration:none;display:inline-block;font-weight:600;">Accept Invitation</a>
        </p>
        <p style="color:#888;font-size:13px;">This link expires in 7 days. If you didn't expect this email, you can ignore it.</p>
      </div>
    `,
    text: `You've been invited to Msafiri OS as ${opts.role}${opts.department ? ` in ${opts.department}` : ""}.\n\nAccept: ${link}\n\nLink expires in 7 days.`,
  };
}

export function passwordResetEmail(opts: {
  firstName: string;
  token: string;
}): Pick<MailOptions, "subject" | "html" | "text"> {
  const link = `${BASE_URL}/reset-password?token=${encodeURIComponent(opts.token)}`;
  return {
    subject: `Reset your Msafiri OS password`,
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;">
        <div style="background:#E53800;border-radius:8px;padding:20px 24px;margin-bottom:24px;">
          <h2 style="color:#fff;margin:0;font-size:20px;font-weight:700;">Msafiri Founder OS</h2>
        </div>
        <p style="color:#222;font-size:15px;">Hi ${esc(opts.firstName)},</p>
        <p style="color:#222;font-size:15px;">Click the button below to set a new password for your account. This link expires in 1 hour.</p>
        <p style="margin:24px 0;">
          <a href="${link}" style="background:#E53800;color:#fff;padding:14px 28px;border-radius:6px;text-decoration:none;display:inline-block;font-weight:600;">Set New Password</a>
        </p>
        <p style="color:#888;font-size:13px;">If you didn't request this, you can safely ignore this email.</p>
      </div>
    `,
    text: `Hi ${opts.firstName},\n\nSet your new Msafiri OS password here:\n${link}\n\nThis link expires in 1 hour.`,
  };
}

export function taskAssignedEmail(opts: {
  assigneeName: string;
  taskTitle: string;
  assignerName: string;
}): Pick<MailOptions, "subject" | "html" | "text"> {
  const link = `${BASE_URL}/tasks`;
  return {
    subject: `Task assigned: ${opts.taskTitle}`,
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;">
        <div style="background:#E53800;border-radius:8px;padding:20px 24px;margin-bottom:24px;">
          <h2 style="color:#fff;margin:0;font-size:20px;font-weight:700;">Msafiri Founder OS</h2>
        </div>
        <p style="color:#222;font-size:15px;">Hi ${esc(opts.assigneeName)},</p>
        <p style="color:#222;font-size:15px;"><strong>${esc(opts.assignerName)}</strong> assigned you a task: <strong>${esc(opts.taskTitle)}</strong></p>
        <p style="margin:24px 0;">
          <a href="${link}" style="background:#E53800;color:#fff;padding:14px 28px;border-radius:6px;text-decoration:none;display:inline-block;font-weight:600;">View Task</a>
        </p>
      </div>
    `,
    text: `${opts.assignerName} assigned you: ${opts.taskTitle}\n\nView tasks: ${link}`,
  };
}

export function mentionEmail(opts: {
  mentionedName: string;
  senderName: string;
  channelName: string;
  messageBody: string;
}): Pick<MailOptions, "subject" | "html" | "text"> {
  const link = `${BASE_URL}/chat`;
  const preview = opts.messageBody.length > 100
    ? opts.messageBody.slice(0, 100) + "…"
    : opts.messageBody;
  return {
    subject: `${opts.senderName} mentioned you in ${opts.channelName}`,
    html: `
      <div style="font-family:sans-serif;max-width:520px;margin:auto;padding:24px;">
        <div style="background:#E53800;border-radius:8px;padding:20px 24px;margin-bottom:24px;">
          <h2 style="color:#fff;margin:0;font-size:20px;font-weight:700;">Msafiri Founder OS</h2>
        </div>
        <p style="color:#222;font-size:15px;">Hi ${esc(opts.mentionedName)},</p>
        <p style="color:#222;font-size:15px;"><strong>${esc(opts.senderName)}</strong> mentioned you in <strong>${esc(opts.channelName)}</strong>:</p>
        <blockquote style="border-left:3px solid #E53800;padding:8px 16px;color:#444;margin:16px 0;font-style:italic;">${esc(preview)}</blockquote>
        <p style="margin:24px 0;">
          <a href="${link}" style="background:#E53800;color:#fff;padding:14px 28px;border-radius:6px;text-decoration:none;display:inline-block;font-weight:600;">Open Chat</a>
        </p>
      </div>
    `,
    text: `${opts.senderName} mentioned you in ${opts.channelName}: "${preview}"\n\nOpen chat: ${link}`,
  };
}
