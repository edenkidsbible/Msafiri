/**
 * notifyAssignee — look up a user by name/email and send a task-assigned email.
 * Exported separately so it can be unit-tested without spinning up the full server.
 */
import { db, usersTable } from "@workspace/db";
import { eq, or, sql } from "drizzle-orm";
import { sendMail, taskAssignedEmail } from "./email";

export async function notifyAssignee(
  assignedTo: string,
  taskTitle: string,
  assignerName: string,
  log: { warn: (obj: object, msg: string) => void },
): Promise<void> {
  try {
    const needle = assignedTo.toLowerCase().trim();
    const [user] = await db
      .select({ firstName: usersTable.firstName, lastName: usersTable.lastName, email: usersTable.email })
      .from(usersTable)
      .where(
        or(
          // exact email match
          eq(sql`lower(coalesce(${usersTable.email},''))`, needle),
          // full name: "Brian Mwangi"
          eq(sql`lower(coalesce(${usersTable.firstName},'') || ' ' || coalesce(${usersTable.lastName},''))`, needle),
          // first name only: "Brian"
          eq(sql`lower(coalesce(${usersTable.firstName},''))`, needle),
          // username: "brian_m"
          eq(sql`lower(coalesce(${usersTable.username},''))`, needle),
        ),
      )
      .limit(1);

    if (!user?.email) {
      log.warn({ assignedTo }, "Task assignee not found or has no email — skipping notification");
      return;
    }

    const assigneeName = [user.firstName, user.lastName].filter(Boolean).join(" ") || assignedTo;
    const mail = taskAssignedEmail({ assigneeName, taskTitle, assignerName });
    await sendMail({ to: user.email, ...mail });
  } catch (err) {
    log.warn({ err, assignedTo }, "Failed to send task-assigned email");
  }
}
