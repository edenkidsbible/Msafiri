import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import settingsRouter from "./settings";
import weeksRouter from "./weeks";
import transactionsRouter from "./transactions";
import subscriptionsRouter from "./subscriptions";
import tasksRouter from "./tasks";
import contentRouter from "./content";
import fieldRouter from "./field";
import dashboardRouter from "./dashboard";
import importsRouter from "./imports";
import revenuecatRouter from "./revenuecat";
import teamRouter from "./team";
import chatRouter from "./chat";
import invitationsRouter from "./invitations";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(settingsRouter);
router.use(weeksRouter);
router.use(transactionsRouter);
router.use(subscriptionsRouter);
router.use(tasksRouter);
router.use(contentRouter);
router.use(fieldRouter);
router.use(dashboardRouter);
router.use(importsRouter);
router.use("/revenuecat", revenuecatRouter);
router.use(teamRouter);
router.use(chatRouter);
router.use(invitationsRouter);

export default router;
