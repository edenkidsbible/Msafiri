import { Router } from "express";
import { db, settingsTable, subscriptionWeekMetricsTable, tasksTable, contentItemsTable, fieldTripsTable, transactionsTable, recurringExpensesTable, operatingWeeksTable, weeklyPlansTable } from "@workspace/db";
import { eq, and, asc, desc, gte, sql, lte, isNull } from "drizzle-orm";

const router = Router();

function getCurrentWeekNumber(firstFundingDate: string): number {
  const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Nairobi" }));
  const first = new Date(firstFundingDate + "T00:00:00+03:00");
  const diffMs = now.getTime() - first.getTime();
  if (diffMs < 0) return 1;
  return Math.floor(diffMs / (7 * 24 * 60 * 60 * 1000)) + 1;
}

router.get("/dashboard/summary", async (req, res) => {
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);
    const firstFundingDate = settings?.firstFundingDate ?? "2026-08-14";
    const currentWeekNum = getCurrentWeekNumber(firstFundingDate);
    const subPrice = parseFloat(settings?.monthlySubscriptionPriceKes ?? "0");
    const baselineActive = settings?.baselineActivePaid ?? 0;
    const today = new Date().toISOString().split("T")[0];

    // Cash: sum of cleared transactions
    const cashRows = await db
      .select({ type: transactionsTable.type, amount: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text` })
      .from(transactionsTable)
      .where(and(eq(transactionsTable.isDeleted, false), eq(transactionsTable.cleared, true)))
      .groupBy(transactionsTable.type);

    let operatingCash = 0;
    let reserveCash = 0;
    for (const row of cashRows) {
      const amt = parseFloat(row.amount);
      if (row.type === "income" || row.type === "refund_in") operatingCash += amt;
      else if (row.type === "expense" || row.type === "refund_out") operatingCash -= amt;
      else if (row.type === "reserve_transfer") { operatingCash -= amt; reserveCash += amt; }
    }

    // Active paid subscribers from latest metric
    const [latestMetric] = await db
      .select()
      .from(subscriptionWeekMetricsTable)
      .orderBy(desc(subscriptionWeekMetricsTable.id))
      .limit(1);
    const activePaid = latestMetric?.activePaidEnd ?? baselineActive;
    const mrr = activePaid * subPrice;

    // Overdue tasks
    const [overdueCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(and(
        eq(tasksTable.isDeleted, false),
        sql`${tasksTable.dueDate} < ${today}`,
        sql`${tasksTable.status} NOT IN ('done', 'cancelled')`
      ));

    // Today tasks
    const todayTasks = await db.select().from(tasksTable)
      .where(and(
        eq(tasksTable.isDeleted, false),
        eq(tasksTable.dueDate, today),
        sql`${tasksTable.status} NOT IN ('done', 'cancelled')`
      ))
      .orderBy(asc(sql`CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END`))
      .limit(5);

    // This week tasks — get current week ID
    const [currentWeek] = await db.select().from(operatingWeeksTable).where(eq(operatingWeeksTable.weekNumber, currentWeekNum));
    const thisWeekTasks = currentWeek
      ? await db.select().from(tasksTable)
          .where(and(eq(tasksTable.isDeleted, false), eq(tasksTable.weekId, currentWeek.id), sql`${tasksTable.status} NOT IN ('done', 'cancelled')`))
          .orderBy(asc(sql`CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END`))
          .limit(10)
      : [];

    // Next content item
    const [nextContent] = await db.select().from(contentItemsTable)
      .where(and(
        eq(contentItemsTable.isDeleted, false),
        sql`${contentItemsTable.status} NOT IN ('posted', 'archive')`,
      ))
      .orderBy(asc(contentItemsTable.scheduledDate))
      .limit(1);

    // Next field trip
    const [nextTrip] = await db.select().from(fieldTripsTable)
      .where(and(eq(fieldTripsTable.isDeleted, false), eq(fieldTripsTable.status, "planned"), gte(fieldTripsTable.date, today)))
      .orderBy(asc(fieldTripsTable.date))
      .limit(1);

    // Next payment (recurring expense)
    const [nextPaymentExpense] = await db.select().from(recurringExpensesTable)
      .where(and(eq(recurringExpensesTable.isActive, true)))
      .orderBy(asc(recurringExpensesTable.nextBillingDate))
      .limit(1);

    let nextPayment = null;
    if (nextPaymentExpense) {
      nextPayment = {
        name: nextPaymentExpense.name,
        amountKes: nextPaymentExpense.amountKes ?? nextPaymentExpense.amountUsd
          ? (parseFloat(nextPaymentExpense.amountUsd ?? "0") * parseFloat(settings?.exchangeRateKesPerUsd ?? "129.36")).toFixed(2)
          : "0.00",
        dueDate: nextPaymentExpense.nextBillingDate ?? today,
      };
    }

    // Business priority from current week plan
    let businessPriority = "Log this week's metrics and plan your priorities.";

    res.json({
      currentWeekNumber: currentWeekNum,
      businessPriority,
      operatingCashKes: operatingCash.toFixed(2),
      reserveCashKes: reserveCash.toFixed(2),
      activePaidSubscribers: activePaid,
      mrrKes: mrr.toFixed(2),
      overdueTaskCount: overdueCount?.count ?? 0,
      nextContentItem: nextContent ?? null,
      nextFieldTrip: nextTrip ?? null,
      nextPayment,
      todayTasks,
      thisWeekTasks,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get dashboard summary");
    res.status(500).json({ error: "Failed to get dashboard summary" });
  }
});

router.get("/dashboard/activity", async (req, res) => {
  try {
    // Recent transactions as activity items
    const txns = await db.select().from(transactionsTable)
      .where(eq(transactionsTable.isDeleted, false))
      .orderBy(desc(transactionsTable.createdAt))
      .limit(10);

    const activity = txns.map(t => ({
      id: `tx-${t.id}`,
      type: t.type === "income" ? "money_in" : "money_out",
      description: `${t.type === "income" ? "Income" : "Expense"}: ${t.description} — KES ${parseFloat(t.amountKes).toLocaleString()}`,
      createdAt: t.createdAt.toISOString(),
      metadataJson: null,
    }));

    res.json(activity);
  } catch (err) {
    req.log.error({ err }, "Failed to get dashboard activity");
    res.status(500).json({ error: "Failed to get dashboard activity" });
  }
});

router.get("/dashboard/alerts", async (req, res) => {
  try {
    const alerts = [];
    const [settings] = await db.select().from(settingsTable).limit(1);
    const today = new Date().toISOString().split("T")[0];
    const cashFloor = parseFloat(settings?.cashFloorKes ?? "2500");

    // Check cash floor
    const cashRows = await db
      .select({ type: transactionsTable.type, amount: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text` })
      .from(transactionsTable)
      .where(and(eq(transactionsTable.isDeleted, false), eq(transactionsTable.cleared, true)))
      .groupBy(transactionsTable.type);

    let operatingCash = 0;
    for (const row of cashRows) {
      const amt = parseFloat(row.amount);
      if (row.type === "income" || row.type === "refund_in") operatingCash += amt;
      else if (row.type === "expense" || row.type === "refund_out") operatingCash -= amt;
    }

    if (operatingCash < cashFloor) {
      alerts.push({
        id: "cash-below-floor",
        severity: "critical",
        title: "Cash below floor",
        message: `Operating cash KES ${operatingCash.toFixed(2)} is below the minimum floor of KES ${cashFloor.toFixed(2)}.`,
        actionLabel: "Log Money",
        actionHref: "/money",
      });
    }

    // Check overdue tasks
    const [overdueCount] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(and(
        eq(tasksTable.isDeleted, false),
        sql`${tasksTable.dueDate} < ${today}`,
        sql`${tasksTable.status} NOT IN ('done', 'cancelled')`
      ));
    if ((overdueCount?.count ?? 0) > 0) {
      alerts.push({
        id: "overdue-tasks",
        severity: "warning",
        title: `${overdueCount?.count} overdue task${(overdueCount?.count ?? 0) > 1 ? "s" : ""}`,
        message: "You have tasks past their due date.",
        actionLabel: "View Tasks",
        actionHref: "/tasks",
      });
    }

    // Check if subscription metrics logged this week
    const firstFundingDate = settings?.firstFundingDate ?? "2026-08-14";
    const now = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Nairobi" }));
    const first = new Date(firstFundingDate + "T00:00:00+03:00");
    const currentWeekNum = Math.floor((now.getTime() - first.getTime()) / (7 * 24 * 60 * 60 * 1000)) + 1;
    const [currentWeek] = await db.select().from(operatingWeeksTable).where(eq(operatingWeeksTable.weekNumber, currentWeekNum));
    if (currentWeek) {
      const [weekMetric] = await db.select().from(subscriptionWeekMetricsTable).where(eq(subscriptionWeekMetricsTable.weekId, currentWeek.id));
      if (!weekMetric) {
        alerts.push({
          id: "missing-subscription-metrics",
          severity: "info",
          title: "Subscription metrics not logged",
          message: `Log this week's (Week ${currentWeekNum}) download and subscription numbers.`,
          actionLabel: "Log Subscribers",
          actionHref: "/subscriptions",
        });
      }
    }

    res.json(alerts.slice(0, 3));
  } catch (err) {
    req.log.error({ err }, "Failed to get dashboard alerts");
    res.status(500).json({ error: "Failed to get dashboard alerts" });
  }
});

// ─── FOCUS BOARD ─────────────────────────────────────────────────────────────
// Returns everything the founder needs to see on the home command-centre.

router.get("/dashboard/focus", async (req, res) => {
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);
    const firstFundingDate = settings?.firstFundingDate ?? "2026-08-14";
    const currentWeekNum = getCurrentWeekNumber(firstFundingDate);
    const cashFloor = parseFloat(settings?.cashFloorKes ?? "2500");

    const naiNow = new Date(new Date().toLocaleString("en-US", { timeZone: "Africa/Nairobi" }));
    const today = naiNow.toISOString().split("T")[0];
    const in7 = new Date(naiNow.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split("T")[0];

    const priOrder = sql`CASE priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END`;

    // Run all queries in parallel
    const [
      cashRows,
      [currentWeek],
      overdueTasks,
      todayTasks,
      upcomingTasks,
      upcomingTrips,
      contentDueSoon,
      contentSuggestions,
      [nextPaymentRow],
    ] = await Promise.all([
      db.select({ type: transactionsTable.type, amount: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text` })
        .from(transactionsTable)
        .where(and(eq(transactionsTable.isDeleted, false), eq(transactionsTable.cleared, true)))
        .groupBy(transactionsTable.type),

      db.select().from(operatingWeeksTable).where(eq(operatingWeeksTable.weekNumber, currentWeekNum)),

      db.select().from(tasksTable)
        .where(and(eq(tasksTable.isDeleted, false), sql`${tasksTable.dueDate} < ${today}`, sql`${tasksTable.status} NOT IN ('done','cancelled')`))
        .orderBy(asc(priOrder), asc(tasksTable.dueDate))
        .limit(10),

      db.select().from(tasksTable)
        .where(and(eq(tasksTable.isDeleted, false), eq(tasksTable.dueDate, today), sql`${tasksTable.status} NOT IN ('done','cancelled')`))
        .orderBy(asc(priOrder))
        .limit(10),

      db.select().from(tasksTable)
        .where(and(eq(tasksTable.isDeleted, false), sql`${tasksTable.dueDate} > ${today}`, sql`${tasksTable.dueDate} <= ${in7}`, sql`${tasksTable.status} NOT IN ('done','cancelled')`))
        .orderBy(asc(tasksTable.dueDate), asc(priOrder))
        .limit(10),

      db.select().from(fieldTripsTable)
        .where(and(eq(fieldTripsTable.isDeleted, false), sql`${fieldTripsTable.date} >= ${today}`, sql`${fieldTripsTable.date} <= ${in7}`, sql`${fieldTripsTable.status} NOT IN ('cancelled')`))
        .orderBy(asc(fieldTripsTable.date))
        .limit(5),

      db.select().from(contentItemsTable)
        .where(and(eq(contentItemsTable.isDeleted, false), sql`${contentItemsTable.scheduledDate} >= ${today}`, sql`${contentItemsTable.scheduledDate} <= ${in7}`, sql`${contentItemsTable.status} NOT IN ('posted','archive')`))
        .orderBy(asc(contentItemsTable.scheduledDate))
        .limit(5),

      db.select({ id: contentItemsTable.id, title: contentItemsTable.title, pillar: contentItemsTable.pillar, angle: contentItemsTable.angle, hook: contentItemsTable.hook, isCore: contentItemsTable.isCore })
        .from(contentItemsTable)
        .where(and(
          eq(contentItemsTable.isDeleted, false),
          eq(contentItemsTable.status, "idea"),
          sql`${contentItemsTable.pillar} NOT LIKE 'Hook Bank%'`,
          sql`${contentItemsTable.pillar} NOT LIKE 'CTA Bank%'`,
          sql`${contentItemsTable.pillar} NOT LIKE 'Series Playbook%'`,
        ))
        .orderBy(asc(sql`CASE WHEN ${contentItemsTable.isCore} THEN 0 ELSE 1 END`), asc(contentItemsTable.id))
        .limit(3),

      db.select().from(recurringExpensesTable)
        .where(and(eq(recurringExpensesTable.isActive, true), sql`${recurringExpensesTable.nextBillingDate} >= ${today}`))
        .orderBy(asc(recurringExpensesTable.nextBillingDate))
        .limit(1),
    ]);

    // Cash balance
    let cashKes = 0;
    for (const row of cashRows) {
      const amt = parseFloat(row.amount);
      if (row.type === "income" || row.type === "refund_in") cashKes += amt;
      else if (row.type === "expense" || row.type === "refund_out") cashKes -= amt;
    }

    // Week plan (objective / theme)
    let weekPlan = null;
    if (currentWeek) {
      const [plan] = await db.select().from(weeklyPlansTable).where(eq(weeklyPlansTable.weekId, currentWeek.id));
      weekPlan = plan ?? null;
    }

    // High-priority week tasks with no due date (catch-all)
    const weekTasks = currentWeek
      ? await db.select().from(tasksTable)
          .where(and(
            eq(tasksTable.isDeleted, false),
            eq(tasksTable.weekId, currentWeek.id),
            isNull(tasksTable.dueDate),
            sql`${tasksTable.status} NOT IN ('done','cancelled')`,
            sql`${tasksTable.priority} IN ('critical','high')`,
          ))
          .orderBy(asc(priOrder))
          .limit(5)
      : [];

    let nextPayment = null;
    if (nextPaymentRow) {
      const kes = nextPaymentRow.amountKes
        ? parseFloat(nextPaymentRow.amountKes)
        : parseFloat(nextPaymentRow.amountUsd ?? "0") * parseFloat(settings?.exchangeRateKesPerUsd ?? "129.36");
      nextPayment = { name: nextPaymentRow.name, amountKes: kes.toFixed(2), dueDate: nextPaymentRow.nextBillingDate };
    }

    res.json({
      today,
      weekNumber: currentWeekNum,
      weekObjective: weekPlan?.mainObjective ?? null,
      weekOutcomes: weekPlan?.requiredOutcomes ?? [],
      cashKes: cashKes.toFixed(2),
      cashFloor: cashFloor.toFixed(2),
      cashLow: cashKes < cashFloor,
      overdueTasks,
      todayTasks,
      upcomingTasks,
      weekTasks,
      upcomingTrips,
      contentDueSoon,
      contentSuggestions,
      nextPayment,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get dashboard focus");
    res.status(500).json({ error: "Failed to get dashboard focus" });
  }
});

export default router;
