import { GetCurrentAuthUserResponse } from '@workspace/api-zod';
import {
  db,
  usersTable,
  invitationsTable,
  teamMembersTable,
  conversationsTable,
  conversationMembersTable,
  passwordResetTokensTable,
} from '@workspace/db';
import { eq, and, gt, isNull } from 'drizzle-orm';
import { Router, type IRouter, type Request, type Response } from 'express';
import crypto from 'crypto';

import {
  clearSession,
  createSession,
  deleteSession,
  getSessionId,
  hashPassword,
  verifyPassword,
  SESSION_COOKIE,
  SESSION_TTL,
  type SessionData,
} from '../lib/auth';
import { sendMail, passwordResetEmail } from '../lib/email';
import { requireRole } from '../middlewares/authMiddleware';

const router: IRouter = Router();

function setSessionCookie(res: Response, sid: string) {
  res.cookie(SESSION_COOKIE, sid, {
    httpOnly: true,
    secure: true,
    sameSite: 'lax',
    path: '/',
    maxAge: SESSION_TTL,
  });
}

// ─── GET current user ─────────────────────────────────────────────────────────

router.get('/auth/user', (req: Request, res: Response) => {
  if (req.isAuthenticated()) {
    const u = req.user as any;
    const base = GetCurrentAuthUserResponse.parse({
      isAuthenticated: true,
      id: u.id,
      firstName: u.firstName,
      lastName: u.lastName,
      email: u.email,
      profileImageUrl: u.profileImageUrl,
      role: u.role ?? null,
    });
    res.json({
      ...base,
      departmentId: u.departmentId ?? null,
      departmentName: u.departmentName ?? null,
    });
  } else {
    res.json({ isAuthenticated: false });
  }
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────

router.post('/auth/login', async (req: Request, res: Response) => {
  const { email, password } = req.body ?? {};
  if (typeof email !== 'string' || typeof password !== 'string' || !email || !password) {
    res.status(400).json({ error: 'Email and password are required' });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email.toLowerCase().trim()));

  if (!user || !user.passwordHash) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) {
    res.status(401).json({ error: 'Invalid email or password' });
    return;
  }

  if (!user.isActive) {
    res.status(403).json({ error: 'Your account has been deactivated. Contact your admin.' });
    return;
  }

  const sessionData: SessionData = {
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      profileImageUrl: user.profileImageUrl,
      role: user.role,
    },
  };

  const sid = await createSession(sessionData);
  setSessionCookie(res, sid);
  res.json({ ok: true });
});

// ─── POST /api/auth/logout ────────────────────────────────────────────────────

router.post('/auth/logout', async (req: Request, res: Response) => {
  const sid = getSessionId(req);
  await clearSession(res, sid);
  res.json({ ok: true });
});

// Legacy GET logout — keeps sidebar logout links working
router.get('/logout', async (req: Request, res: Response) => {
  const sid = getSessionId(req);
  await clearSession(res, sid);
  res.redirect('/login');
});

// ─── GET /api/auth/invite — look up invite token metadata ────────────────────

router.get('/auth/invite', async (req: Request, res: Response) => {
  const token = typeof req.query.token === 'string' ? req.query.token : null;
  if (!token) {
    res.status(400).json({ error: 'token is required' });
    return;
  }

  const [inv] = await db
    .select()
    .from(invitationsTable)
    .where(eq(invitationsTable.token, token));

  if (!inv || inv.status !== 'pending' || inv.expiresAt < new Date()) {
    res.status(404).json({ error: 'Invitation not found or has expired' });
    return;
  }

  res.json({
    email: inv.email,
    role: inv.role,
    departmentId: inv.departmentId ?? null,
  });
});

// ─── POST /api/auth/accept-invite — create account & session ─────────────────

router.post('/auth/accept-invite', async (req: Request, res: Response) => {
  const { token, firstName, lastName, password } = req.body ?? {};

  if (
    typeof token !== 'string' ||
    typeof firstName !== 'string' ||
    typeof password !== 'string' ||
    !token || !firstName.trim() || !password
  ) {
    res.status(400).json({ error: 'token, firstName, and password are required' });
    return;
  }

  if (password.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters' });
    return;
  }

  const [inv] = await db
    .select()
    .from(invitationsTable)
    .where(eq(invitationsTable.token, token));

  if (!inv || inv.status !== 'pending' || inv.expiresAt < new Date()) {
    res.status(400).json({ error: 'Invitation is invalid or has expired' });
    return;
  }

  // Guard against duplicate accounts
  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, inv.email.toLowerCase()));

  if (existing) {
    res.status(409).json({
      error: 'An account with this email already exists. Please log in instead.',
    });
    return;
  }

  const passwordHash = await hashPassword(password);
  const userId = crypto.randomUUID();

  const [user] = await db
    .insert(usersTable)
    .values({
      id: userId,
      email: inv.email.toLowerCase(),
      firstName: firstName.trim(),
      lastName: typeof lastName === 'string' && lastName.trim() ? lastName.trim() : null,
      role: inv.role,
      passwordHash,
    })
    .returning();

  // Mark invitation accepted
  await db
    .update(invitationsTable)
    .set({ status: 'accepted', acceptedAt: new Date() })
    .where(eq(invitationsTable.id, inv.id));

  // Link to department if specified
  if (inv.departmentId) {
    await db
      .insert(teamMembersTable)
      .values({
        userId: user.id,
        departmentId: inv.departmentId,
        role: inv.role,
        invitedBy: inv.invitedBy ?? null,
      })
      .onConflictDoNothing();
  }

  // Add new user to every conversation so they can see all channels immediately
  const allConversations = await db
    .select({ id: conversationsTable.id })
    .from(conversationsTable);

  for (const conv of allConversations) {
    await db
      .insert(conversationMembersTable)
      .values({ conversationId: conv.id, userId: user.id })
      .onConflictDoNothing();
  }

  // Create session
  const sessionData: SessionData = {
    user: {
      id: user.id,
      email: user.email,
      firstName: user.firstName,
      lastName: user.lastName,
      profileImageUrl: null,
      role: user.role,
    },
  };

  const sid = await createSession(sessionData);
  setSessionCookie(res, sid);
  res.json({ ok: true });
});

// ─── POST /api/auth/forgot-password ──────────────────────────────────────────
// Public. Generates a 1-hour reset token. Tries email; always returns the link
// so an admin can share it manually if Resend is not configured.

router.post('/auth/forgot-password', async (req: Request, res: Response) => {
  const { email } = req.body ?? {};
  if (typeof email !== 'string' || !email.trim()) {
    res.status(400).json({ error: 'Email is required' });
    return;
  }

  const [user] = await db
    .select()
    .from(usersTable)
    .where(eq(usersTable.email, email.toLowerCase().trim()));

  // Always respond the same way to avoid email enumeration
  if (!user || !user.isActive) {
    res.json({ ok: true, emailSent: false });
    return;
  }

  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 60 * 60 * 1000); // 1 hour

  // Invalidate any previous unused tokens for this user
  await db
    .delete(passwordResetTokensTable)
    .where(and(eq(passwordResetTokensTable.userId, user.id), isNull(passwordResetTokensTable.usedAt)));

  await db.insert(passwordResetTokensTable).values({ userId: user.id, token, expiresAt });

  const firstName = user.firstName ?? user.email?.split('@')[0] ?? 'there';
  const emailContent = passwordResetEmail({ firstName, token });
  const result = await sendMail({ to: user.email!, ...emailContent });

  res.json({ ok: true, emailSent: result.delivered });
});

// ─── GET /api/auth/validate-reset/:token ─────────────────────────────────────
// Public. Validates a token and returns the associated email so the UI can show it.

router.get('/auth/validate-reset/:token', async (req: Request, res: Response) => {
  const { token } = req.params;

  const [row] = await db
    .select()
    .from(passwordResetTokensTable)
    .where(eq(passwordResetTokensTable.token, token));

  if (!row || row.usedAt || row.expiresAt < new Date()) {
    res.status(404).json({ error: 'This reset link is invalid or has expired.' });
    return;
  }

  const [user] = await db.select({ email: usersTable.email }).from(usersTable).where(eq(usersTable.id, row.userId));
  res.json({ email: user?.email ?? null });
});

// ─── POST /api/auth/reset-password ────────────────────────────────────────────
// Public. Consumes the token and sets the new password.

router.post('/auth/reset-password', async (req: Request, res: Response) => {
  const { token, password } = req.body ?? {};

  if (typeof token !== 'string' || typeof password !== 'string' || !token || !password) {
    res.status(400).json({ error: 'token and password are required' });
    return;
  }

  if (password.length < 8) {
    res.status(400).json({ error: 'Password must be at least 8 characters' });
    return;
  }

  const [row] = await db
    .select()
    .from(passwordResetTokensTable)
    .where(eq(passwordResetTokensTable.token, token));

  if (!row || row.usedAt || row.expiresAt < new Date()) {
    res.status(400).json({ error: 'This reset link is invalid or has expired.' });
    return;
  }

  const passwordHash = await hashPassword(password);

  await db.update(usersTable).set({ passwordHash }).where(eq(usersTable.id, row.userId));
  await db.update(passwordResetTokensTable).set({ usedAt: new Date() }).where(eq(passwordResetTokensTable.id, row.id));

  // Create a session so they're logged in immediately
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, row.userId));
  if (user) {
    const sessionData: SessionData = {
      user: {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        profileImageUrl: user.profileImageUrl,
        role: user.role,
      },
    };
    const sid = await createSession(sessionData);
    setSessionCookie(res, sid);
  }

  res.json({ ok: true });
});

// ─── POST /api/auth/change-password ──────────────────────────────────────────
// Authenticated. Lets a logged-in user change their own password.

router.post('/auth/change-password', async (req: Request, res: Response) => {
  if (!req.isAuthenticated()) {
    res.status(401).json({ error: 'Not authenticated' });
    return;
  }

  const { currentPassword, newPassword } = req.body ?? {};

  if (typeof newPassword !== 'string' || newPassword.length < 8) {
    res.status(400).json({ error: 'New password must be at least 8 characters' });
    return;
  }

  const userId = (req.user as any).id;
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));

  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  // If they already have a password, they must provide the current one
  if (user.passwordHash) {
    if (typeof currentPassword !== 'string' || !currentPassword) {
      res.status(400).json({ error: 'Current password is required' });
      return;
    }
    const valid = await verifyPassword(currentPassword, user.passwordHash);
    if (!valid) {
      res.status(401).json({ error: 'Current password is incorrect' });
      return;
    }
  }

  const passwordHash = await hashPassword(newPassword);
  await db.update(usersTable).set({ passwordHash }).where(eq(usersTable.id, userId));

  res.json({ ok: true });
});

// ─── POST /api/auth/admin/generate-reset-link ────────────────────────────────
// Owner/admin only. Generates a reset link for any user without sending email.
// Used to bootstrap accounts that have no password set.

router.post('/auth/admin/generate-reset-link', requireRole(['owner', 'admin']), async (req: Request, res: Response) => {
  const { userId } = req.body ?? {};

  if (typeof userId !== 'string' || !userId) {
    res.status(400).json({ error: 'userId is required' });
    return;
  }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));

  if (!user) {
    res.status(404).json({ error: 'User not found' });
    return;
  }

  const token = crypto.randomBytes(32).toString('hex');
  const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000); // 24 hours

  // Invalidate previous unused tokens
  await db
    .delete(passwordResetTokensTable)
    .where(and(eq(passwordResetTokensTable.userId, user.id), isNull(passwordResetTokensTable.usedAt)));

  await db.insert(passwordResetTokensTable).values({ userId: user.id, token, expiresAt });

  res.json({ ok: true, token });
});

// ─── Mobile auth stubs (kept so mobile clients don't 404) ────────────────────

router.post('/mobile-auth/logout', async (req: Request, res: Response) => {
  const sid = getSessionId(req);
  if (sid) await deleteSession(sid);
  res.json({ success: true });
});

export default router;
