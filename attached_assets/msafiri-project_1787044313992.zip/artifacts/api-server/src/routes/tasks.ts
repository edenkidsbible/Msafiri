import { Router } from "express";
import { db, tasksTable, operatingWeeksTable } from "@workspace/db";
import { eq, and, desc, asc, sql } from "drizzle-orm";
import { notifyAssignee } from "../lib/notifyAssignee";

const router = Router();

router.get("/tasks", async (req, res) => {
  try {
    const limit = parseInt(String(req.query.limit ?? 50));
    const offset = parseInt(String(req.query.offset ?? 0));
    const status = req.query.status ? String(req.query.status) : undefined;
    const weekId = req.query.weekId ? parseInt(String(req.query.weekId)) : undefined;
    const module = req.query.module ? String(req.query.module) : undefined;
    const priority = req.query.priority ? String(req.query.priority) : undefined;

    const conditions = [eq(tasksTable.isDeleted, false)];
    if (status) conditions.push(eq(tasksTable.status, status));
    if (weekId) conditions.push(eq(tasksTable.weekId, weekId));
    if (module) conditions.push(eq(tasksTable.module, module));
    if (priority) conditions.push(eq(tasksTable.priority, priority));

    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(and(...conditions));

    const items = await db
      .select({
        id: tasksTable.id,
        title: tasksTable.title,
        description: tasksTable.description,
        status: tasksTable.status,
        priority: tasksTable.priority,
        module: tasksTable.module,
        type: tasksTable.type,
        dueDate: tasksTable.dueDate,
        weekId: tasksTable.weekId,
        weekNumber: operatingWeeksTable.weekNumber,
        estimatedHours: tasksTable.estimatedHours,
        actualHours: tasksTable.actualHours,
        assignedTo: tasksTable.assignedTo,
        acceptanceCriteria: tasksTable.acceptanceCriteria,
        isRecurring: tasksTable.isRecurring,
        position: tasksTable.position,
        createdAt: tasksTable.createdAt,
        updatedAt: tasksTable.updatedAt,
      })
      .from(tasksTable)
      .leftJoin(operatingWeeksTable, eq(tasksTable.weekId, operatingWeeksTable.id))
      .where(and(...conditions))
      .orderBy(
        asc(tasksTable.position),
        desc(tasksTable.createdAt)
      )
      .limit(limit)
      .offset(offset);

    res.json({ items, total: countResult?.count ?? 0 });
  } catch (err) {
    req.log.error({ err }, "Failed to list tasks");
    res.status(500).json({ error: "Failed to list tasks" });
  }
});

router.post("/tasks", async (req, res) => {
  try {
    const { title, description, status, priority, module, type, dueDate, weekId, estimatedHours, assignedTo, acceptanceCriteria } = req.body;
    if (!title || !priority || !module) return res.status(400).json({ error: "title, priority, module are required" });

    // Assign the next position within the target status column
    const targetStatus = status ?? "todo";
    const [maxRow] = await db
      .select({ maxPos: sql<number>`COALESCE(MAX(position), -1)::int` })
      .from(tasksTable)
      .where(and(eq(tasksTable.isDeleted, false), eq(tasksTable.status, targetStatus)));
    const nextPosition = (maxRow?.maxPos ?? -1) + 1;

    const [task] = await db.insert(tasksTable).values({
      title, description, status: targetStatus, priority, module, type, dueDate, weekId,
      estimatedHours, assignedTo, acceptanceCriteria, createdBy: req.user?.id,
      position: nextPosition,
    }).returning();

    if (assignedTo) {
      const assignerName = [req.user?.firstName, req.user?.lastName].filter(Boolean).join(" ") || "A teammate";
      notifyAssignee(assignedTo, title, assignerName, req.log).catch(() => { /* already handled */ });
    }

    return res.status(201).json(task);
  } catch (err) {
    req.log.error({ err }, "Failed to create task");
    return res.status(500).json({ error: "Failed to create task" });
  }
});

router.get("/tasks/stats", async (req, res) => {
  try {
    const today = new Date().toISOString().split("T")[0];
    const byStatus = await db
      .select({ status: tasksTable.status, count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(eq(tasksTable.isDeleted, false))
      .groupBy(tasksTable.status);
    const byPriority = await db
      .select({ priority: tasksTable.priority, count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(eq(tasksTable.isDeleted, false))
      .groupBy(tasksTable.priority);
    const byModule = await db
      .select({ module: tasksTable.module, count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(eq(tasksTable.isDeleted, false))
      .groupBy(tasksTable.module);
    const [overdue] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(tasksTable)
      .where(and(
        eq(tasksTable.isDeleted, false),
        sql`${tasksTable.dueDate} < ${today}`,
        sql`${tasksTable.status} NOT IN ('done', 'cancelled')`
      ));

    res.json({
      byStatus: Object.fromEntries(byStatus.map(r => [r.status, r.count])),
      byPriority: Object.fromEntries(byPriority.map(r => [r.priority, r.count])),
      byModule: Object.fromEntries(byModule.map(r => [r.module, r.count])),
      totalOverdue: overdue?.count ?? 0,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get task stats");
    res.status(500).json({ error: "Failed to get task stats" });
  }
});

// Bulk reorder: update positions for multiple tasks in one shot
router.patch("/tasks/reorder", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  try {
    const { items } = req.body as { items: { id: number; position: number }[] };
    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: "items array is required" });
    }
    await db.transaction(async (tx) => {
      for (const { id, position } of items) {
        await tx
          .update(tasksTable)
          .set({ position, updatedBy: req.user?.id })
          .where(and(eq(tasksTable.id, id), eq(tasksTable.isDeleted, false)));
      }
    });
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to reorder tasks");
    return res.status(500).json({ error: "Failed to reorder tasks" });
  }
});

router.get("/tasks/:id", async (req, res) => {
  try {
    const [task] = await db.select().from(tasksTable).where(and(eq(tasksTable.id, parseInt(req.params.id)), eq(tasksTable.isDeleted, false)));
    if (!task) return res.status(404).json({ error: "Task not found" });
    return res.json(task);
  } catch (err) {
    req.log.error({ err }, "Failed to get task");
    return res.status(500).json({ error: "Failed to get task" });
  }
});

router.patch("/tasks/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const fields = ["title", "description", "status", "priority", "module", "type", "dueDate", "weekId", "estimatedHours", "actualHours", "assignedTo", "acceptanceCriteria", "position"];
    const update: Record<string, unknown> = {};
    for (const f of fields) if (req.body[f] !== undefined) update[f] = req.body[f];

    // Read current task once — used for status-column reorder and assignee change detection
    const [currentTask] = await db
      .select({ status: tasksTable.status, assignedTo: tasksTable.assignedTo, title: tasksTable.title })
      .from(tasksTable)
      .where(and(eq(tasksTable.id, id), eq(tasksTable.isDeleted, false)));

    // When moving to a different status column, assign to the end of that column
    if (update.status !== undefined && currentTask && currentTask.status !== update.status) {
      const [maxRow] = await db
        .select({ maxPos: sql<number>`COALESCE(MAX(position), -1)::int` })
        .from(tasksTable)
        .where(and(eq(tasksTable.isDeleted, false), eq(tasksTable.status, update.status as string)));
      update.position = (maxRow?.maxPos ?? -1) + 1;
    }

    update.updatedBy = req.user?.id;
    const [task] = await db.update(tasksTable).set(update).where(and(eq(tasksTable.id, id), eq(tasksTable.isDeleted, false))).returning();
    if (!task) return res.status(404).json({ error: "Task not found" });

    // Send email only when assignedTo is set AND has changed
    const newAssignee = update.assignedTo as string | undefined;
    if (newAssignee && newAssignee !== currentTask?.assignedTo) {
      const taskTitle = (update.title as string | undefined) ?? currentTask?.title ?? "";
      const assignerName = [req.user?.firstName, req.user?.lastName].filter(Boolean).join(" ") || "A teammate";
      notifyAssignee(newAssignee, taskTitle, assignerName, req.log).catch(() => { /* already handled */ });
    }

    return res.json(task);
  } catch (err) {
    req.log.error({ err }, "Failed to update task");
    return res.status(500).json({ error: "Failed to update task" });
  }
});

router.delete("/tasks/:id", async (req, res) => {
  try {
    await db.update(tasksTable).set({ isDeleted: true, updatedBy: req.user?.id }).where(eq(tasksTable.id, parseInt(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete task");
    res.status(500).json({ error: "Failed to delete task" });
  }
});

export default router;
