/**
 * RevenueCat integration routes
 * GET /api/revenuecat/overview   — live aggregate metrics + KES conversion
 * GET /api/revenuecat/breakdown  — weekly vs monthly paid/trial counts
 */
import { Router } from "express";
import { createClient } from "@replit/revenuecat-sdk/client";
import { getOverviewMetrics, listProducts } from "@replit/revenuecat-sdk";
import { db, settingsTable } from "@workspace/db";

const router = Router();

function getRcClient() {
  const key = process.env.REVENUECAT_API_KEY;
  if (!key) throw new Error("REVENUECAT_API_KEY not set");
  return createClient({
    baseUrl: "https://api.revenuecat.com/v2",
    headers: { Authorization: `Bearer ${key}` },
  });
}

const PROJECT_ID = () => {
  const id = process.env.REVENUECAT_PROJECT_ID;
  if (!id) throw new Error("REVENUECAT_PROJECT_ID not set");
  return id;
};

async function getExchangeRate(): Promise<number> {
  try {
    const [settings] = await db.select({ rate: settingsTable.exchangeRateKesPerUsd }).from(settingsTable).limit(1);
    return parseFloat(settings?.rate ?? "130");
  } catch {
    return 130; // sensible fallback
  }
}

// ── Cache ──────────────────────────────────────────────────────────────────────
let overviewCache: { data: unknown; ts: number } | null = null;
let breakdownCache: { data: unknown; ts: number } | null = null;
const CACHE_TTL_MS = 60_000;

// ── Overview ──────────────────────────────────────────────────────────────────
router.get("/overview", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  try {
    const now = Date.now();
    if (overviewCache && now - overviewCache.ts < CACHE_TTL_MS) {
      return res.json(overviewCache.data);
    }

    const [client, exchangeRate] = await Promise.all([
      Promise.resolve(getRcClient()),
      getExchangeRate(),
    ]);

    const { data, error } = await getOverviewMetrics({
      client,
      path: { project_id: PROJECT_ID() },
    });

    if (error) {
      console.error("[RC] overview error:", error);
      return res.status(502).json({ error: "RevenueCat API error" });
    }

    const byId: Record<string, number> = {};
    for (const m of data?.metrics ?? []) {
      byId[m.id] = m.value ?? 0;
    }

    const mrrUsd = byId["mrr"] ?? 0;
    const revenue28dUsd = byId["revenue"] ?? 0;

    const result = {
      activeTrials: byId["active_trials"] ?? 0,
      activeSubscriptions: byId["active_subscriptions"] ?? 0,
      mrrUsd,
      revenue28dUsd,
      newCustomers28d: byId["new_customers"] ?? 0,
      activeUsers28d: byId["active_users"] ?? 0,
      exchangeRate,
      mrrKes: Math.round(mrrUsd * exchangeRate),
      revenue28dKes: Math.round(revenue28dUsd * exchangeRate),
      updatedAt: new Date().toISOString(),
    };

    overviewCache = { data: result, ts: now };
    return res.json(result);
  } catch (err: any) {
    console.error("[RC] overview exception:", err.message);
    return res.status(500).json({ error: "Internal server error" });
  }
});

// ── Breakdown (weekly vs monthly) ─────────────────────────────────────────────
router.get("/breakdown", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  try {
    const now = Date.now();
    if (breakdownCache && now - breakdownCache.ts < CACHE_TTL_MS) {
      return res.json(breakdownCache.data);
    }

    const client = getRcClient();
    const projectId = PROJECT_ID();

    let weeklyPaid = 0, monthlyPaid = 0, weeklyTrial = 0, monthlyTrial = 0;
    const weeklyProductIds = new Set<string>();

    // 1. Classify products as weekly vs monthly from their store identifier
    try {
      const { data: productsData } = await listProducts({
        client,
        path: { project_id: projectId },
      });

      for (const p of (productsData as any)?.items ?? []) {
        const ident = (p.store_identifier ?? p.identifier ?? p.display_name ?? "").toLowerCase();
        if (ident.includes("week") || ident.includes("7day") || ident.includes("7_day")) {
          weeklyProductIds.add(p.id);
        }
      }
    } catch (e: any) {
      console.warn("[RC] listProducts failed:", e.message);
    }

    // Helper: classify a subscription item using product_id or product identifier
    const classify = (sub: any): "weekly" | "monthly" => {
      if (weeklyProductIds.has(sub.product_id)) return "weekly";
      const ident = (sub.product_identifier ?? sub.product?.store_identifier ?? "").toLowerCase();
      return ident.includes("week") || ident.includes("7day") ? "weekly" : "monthly";
    };

    // 2. Fetch active subscriptions via RC REST
    try {
      const resp = await client.get({
        url: `/projects/${projectId}/subscriptions` as any,
        query: { environment: "production", store_transaction_subscription_status: "trial", limit: 200 } as any,
      });
      for (const sub of (resp.data as any)?.items ?? []) {
        if (classify(sub) === "weekly") weeklyPaid++; else monthlyPaid++;
      }
    } catch (e: any) {
      console.warn("[RC] active subs fetch failed:", e.message);
    }

    // 3. Fetch trial subscriptions
    try {
      const resp = await client.get({
        url: `/projects/${projectId}/subscriptions` as any,
        query: { environment: "production", store_transaction_subscription_status: "trial", limit: 200 } as any,
      });
      for (const sub of (resp.data as any)?.items ?? []) {
        if (classify(sub) === "weekly") weeklyTrial++; else monthlyTrial++;
      }
    } catch (e: any) {
      console.warn("[RC] trial subs fetch failed:", e.message);
    }

    const result = { weeklyPaid, monthlyPaid, weeklyTrial, monthlyTrial, updatedAt: new Date().toISOString() };
    breakdownCache = { data: result, ts: now };
    return res.json(result);
  } catch (err: any) {
    console.error("[RC] breakdown exception:", err.message);
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
