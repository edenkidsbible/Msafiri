import { Router } from "express";
import { db, invitationsTable, departmentsTable, usersTable, teamMembersTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";
import { randomBytes } from "crypto";
import { sendMail, invitationEmail } from "../lib/email";

const router = Router();

function authGuard(req: any, res: any, next: any) {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  next();
}

// ─── CREATE INVITATION (owner/admin only) ─────────────────────────────────────

router.post("/invitations", authGuard, async (req, res) => {
  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can invite members" });
  }

  const { email, role, departmentId, message: _msg } = req.body;
  if (!email?.trim()) return res.status(400).json({ error: "email is required" });

  // Check for existing pending invitation
  const [existing] = await db
    .select()
    .from(invitationsTable)
    .where(and(eq(invitationsTable.email, email.toLowerCase().trim()), eq(invitationsTable.status, "pending")));
  if (existing) {
    return res.status(400).json({ error: "An active invitation already exists for this email" });
  }

  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

  const [inv] = await db
    .insert(invitationsTable)
    .values({
      email: email.toLowerCase().trim(),
      role: role ?? "member",
      departmentId: departmentId ?? null,
      token,
      invitedBy: req.user!.id,
      expiresAt,
    })
    .returning();

  // Resolve department name for email
  let deptName: string | undefined;
  if (departmentId) {
    const [dept] = await db.select({ name: departmentsTable.name }).from(departmentsTable).where(eq(departmentsTable.id, departmentId));
    deptName = dept?.name;
  }

  // Inviter name
  const [inviter] = await db.select({ firstName: usersTable.firstName, lastName: usersTable.lastName }).from(usersTable).where(eq(usersTable.id, req.user!.id));
  const inviterName = [inviter?.firstName, inviter?.lastName].filter((v): v is string => Boolean(v)).join(" ") || "The Msafiri team";

  const emailContent = invitationEmail({
    inviterName,
    role: inv.role,
    department: deptName,
    token,
  });

  const emailResult = await sendMail({ to: inv.email, ...emailContent });

  return res.status(201).json({
    id: inv.id,
    email: inv.email,
    role: inv.role,
    expiresAt: inv.expiresAt,
    status: inv.status,
    emailDelivered: emailResult.delivered,
    emailError: emailResult.delivered ? undefined : emailResult.error,
  });
});

// ─── LIST INVITATIONS ─────────────────────────────────────────────────────────

router.get("/invitations", authGuard, async (req, res) => {
  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const invs = await db
    .select({
      id: invitationsTable.id,
      email: invitationsTable.email,
      role: invitationsTable.role,
      departmentId: invitationsTable.departmentId,
      departmentName: departmentsTable.name,
      status: invitationsTable.status,
      expiresAt: invitationsTable.expiresAt,
      acceptedAt: invitationsTable.acceptedAt,
      createdAt: invitationsTable.createdAt,
    })
    .from(invitationsTable)
    .leftJoin(departmentsTable, eq(invitationsTable.departmentId, departmentsTable.id))
    .orderBy(invitationsTable.createdAt);

  res.json(invs.reverse());
});

// ─── REVOKE INVITATION ────────────────────────────────────────────────────────

router.delete("/invitations/:id", authGuard, async (req, res) => {
  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Forbidden" });
  }

  const id = parseInt(req.params.id);
  await db.update(invitationsTable).set({ status: "revoked" }).where(eq(invitationsTable.id, id));
  res.status(204).send();
});

// ─── ACCEPT INVITATION (called after login) ───────────────────────────────────
// Public — no auth guard, but validates the token

router.post("/invitations/accept", async (req, res) => {
  const { token } = req.body;
  if (!token) return res.status(400).json({ error: "token is required" });

  const [inv] = await db.select().from(invitationsTable).where(eq(invitationsTable.token, token));
  if (!inv) return res.status(404).json({ error: "Invitation not found" });
  if (inv.status !== "pending") return res.status(400).json({ error: `Invitation is ${inv.status}` });
  if (inv.expiresAt < new Date()) {
    await db.update(invitationsTable).set({ status: "expired" }).where(eq(invitationsTable.id, inv.id));
    return res.status(400).json({ error: "Invitation has expired" });
  }

  // Find user by email (must be logged in via Replit)
  const [user] = await db.select().from(usersTable).where(eq(usersTable.email, inv.email));
  if (!user) {
    return res.status(400).json({ error: "No user account found for this email. Please log in with Replit first." });
  }

  // Update user role
  await db.update(usersTable).set({ role: inv.role }).where(eq(usersTable.id, user.id));

  // Add to team_members if not already there
  const [existingMember] = await db.select().from(teamMembersTable).where(eq(teamMembersTable.userId, user.id));
  if (!existingMember) {
    await db.insert(teamMembersTable).values({
      userId: user.id,
      role: inv.role,
      departmentId: inv.departmentId ?? null,
      invitedBy: inv.invitedBy,
    });
  }

  // Mark invitation accepted
  await db.update(invitationsTable).set({ status: "accepted", acceptedAt: new Date() }).where(eq(invitationsTable.id, inv.id));

  res.json({ ok: true, userId: user.id });
});

// ─── GET INVITATION INFO BY TOKEN (public) ────────────────────────────────────

router.get("/invitations/token/:token", async (req, res) => {
  const { token } = req.params;
  const [inv] = await db
    .select({
      email: invitationsTable.email,
      role: invitationsTable.role,
      status: invitationsTable.status,
      expiresAt: invitationsTable.expiresAt,
      departmentName: departmentsTable.name,
    })
    .from(invitationsTable)
    .leftJoin(departmentsTable, eq(invitationsTable.departmentId, departmentsTable.id))
    .where(eq(invitationsTable.token, token));
  if (!inv) return res.status(404).json({ error: "Invitation not found" });
  res.json(inv);
});

export default router;
