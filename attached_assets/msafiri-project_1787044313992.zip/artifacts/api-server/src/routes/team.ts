import { Router } from "express";
import { db, usersTable, departmentsTable, teamMembersTable, conversationsTable, conversationMembersTable } from "@workspace/db";
import { eq, and, asc, ne } from "drizzle-orm";

const router = Router();

// ─── DEPARTMENTS ──────────────────────────────────────────────────────────────

router.get("/team/departments", async (req, res) => {
  try {
    const departments = await db
      .select()
      .from(departmentsTable)
      .orderBy(asc(departmentsTable.name));
    res.json(departments);
  } catch (err) {
    req.log.error({ err }, "Failed to list departments");
    res.status(500).json({ error: "Failed to list departments" });
  }
});

router.post("/team/departments", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });

  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can create departments" });
  }

  try {
    const { name, description } = req.body;
    if (!name?.trim()) return res.status(400).json({ error: "name is required" });

    const [dept] = await db
      .insert(departmentsTable)
      .values({ name: name.trim(), description })
      .returning();

    // Auto-create a department conversation
    const [conv] = await db
      .insert(conversationsTable)
      .values({ type: "department", departmentId: dept.id, name: dept.name })
      .returning();
    // Add the owner/admin who created it as first member
    const creatorId = req.user!.id;
    await db.insert(conversationMembersTable).values({ conversationId: conv.id, userId: creatorId });

    return res.status(201).json(dept);
  } catch (err) {
    req.log.error({ err }, "Failed to create department");
    return res.status(500).json({ error: "Failed to create department" });
  }
});

router.patch("/team/departments/:id", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });

  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can update departments" });
  }

  try {
    const id = parseInt(req.params.id);
    const { name, description, isActive } = req.body;
    const update: Record<string, unknown> = {};
    if (name !== undefined) update.name = name.trim();
    if (description !== undefined) update.description = description;
    if (isActive !== undefined) update.isActive = isActive;

    const [dept] = await db
      .update(departmentsTable)
      .set(update)
      .where(eq(departmentsTable.id, id))
      .returning();
    if (!dept) return res.status(404).json({ error: "Department not found" });
    return res.json(dept);
  } catch (err) {
    req.log.error({ err }, "Failed to update department");
    return res.status(500).json({ error: "Failed to update department" });
  }
});

router.delete("/team/departments/:id", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });

  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can delete departments" });
  }

  try {
    const id = parseInt(req.params.id);
    await db.delete(departmentsTable).where(eq(departmentsTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete department");
    return res.status(500).json({ error: "Failed to delete department" });
  }
});

// ─── USERS ────────────────────────────────────────────────────────────────────

router.get("/team/users", async (req, res) => {
  try {
    const users = await db
      .select({
        id: usersTable.id,
        username: usersTable.username,
        firstName: usersTable.firstName,
        lastName: usersTable.lastName,
        email: usersTable.email,
        profileImageUrl: usersTable.profileImageUrl,
        role: usersTable.role,
        isActive: usersTable.isActive,
      })
      .from(usersTable)
      .orderBy(asc(usersTable.firstName));
    res.json(users);
  } catch (err) {
    req.log.error({ err }, "Failed to list users");
    res.status(500).json({ error: "Failed to list users" });
  }
});

// ─── TEAM MEMBERS ─────────────────────────────────────────────────────────────

async function getTeamMembersWithUsers() {
  return db
    .select({
      id: teamMembersTable.id,
      userId: teamMembersTable.userId,
      role: teamMembersTable.role,
      departmentId: teamMembersTable.departmentId,
      departmentName: departmentsTable.name,
      isActive: teamMembersTable.isActive,
      notes: teamMembersTable.notes,
      createdAt: teamMembersTable.createdAt,
      updatedAt: teamMembersTable.updatedAt,
      username: usersTable.username,
      firstName: usersTable.firstName,
      lastName: usersTable.lastName,
      email: usersTable.email,
      profileImageUrl: usersTable.profileImageUrl,
    })
    .from(teamMembersTable)
    .leftJoin(usersTable, eq(teamMembersTable.userId, usersTable.id))
    .leftJoin(departmentsTable, eq(teamMembersTable.departmentId, departmentsTable.id))
    .orderBy(asc(usersTable.firstName));
}

router.get("/team/members", async (req, res) => {
  try {
    const members = await getTeamMembersWithUsers();
    res.json(members);
  } catch (err) {
    req.log.error({ err }, "Failed to list team members");
    res.status(500).json({ error: "Failed to list team members" });
  }
});

router.post("/team/members", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });

  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can add team members" });
  }

  try {
    const { userId, role, departmentId, notes } = req.body;
    if (!userId) return res.status(400).json({ error: "userId is required" });

    // Verify the user exists
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) return res.status(400).json({ error: "User not found" });

    // Check for duplicate
    const [existing] = await db
      .select()
      .from(teamMembersTable)
      .where(eq(teamMembersTable.userId, userId));
    if (existing) return res.status(400).json({ error: "User is already a team member" });

    const [member] = await db
      .insert(teamMembersTable)
      .values({
        userId,
        role: role ?? "member",
        departmentId: departmentId ?? null,
        notes,
        invitedBy: req.user?.id,
      })
      .returning();

    // Return with joined user info
    const [full] = await db
      .select({
        id: teamMembersTable.id,
        userId: teamMembersTable.userId,
        role: teamMembersTable.role,
        departmentId: teamMembersTable.departmentId,
        departmentName: departmentsTable.name,
        isActive: teamMembersTable.isActive,
        notes: teamMembersTable.notes,
        createdAt: teamMembersTable.createdAt,
        updatedAt: teamMembersTable.updatedAt,
        username: usersTable.username,
        firstName: usersTable.firstName,
        lastName: usersTable.lastName,
        email: usersTable.email,
        profileImageUrl: usersTable.profileImageUrl,
      })
      .from(teamMembersTable)
      .leftJoin(usersTable, eq(teamMembersTable.userId, usersTable.id))
      .leftJoin(departmentsTable, eq(teamMembersTable.departmentId, departmentsTable.id))
      .where(eq(teamMembersTable.id, member.id));

    return res.status(201).json(full);
  } catch (err) {
    req.log.error({ err }, "Failed to add team member");
    return res.status(500).json({ error: "Failed to add team member" });
  }
});

router.patch("/team/members/:id", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });

  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can update team members" });
  }

  try {
    const id = parseInt(req.params.id);
    const { role, departmentId, isActive, notes } = req.body;
    const update: Record<string, unknown> = {};
    if (role !== undefined) update.role = role;
    if (departmentId !== undefined) update.departmentId = departmentId;
    if (isActive !== undefined) update.isActive = isActive;
    if (notes !== undefined) update.notes = notes;

    const [member] = await db
      .update(teamMembersTable)
      .set(update)
      .where(eq(teamMembersTable.id, id))
      .returning();
    if (!member) return res.status(404).json({ error: "Team member not found" });

    // Also sync user role if role changed
    if (role !== undefined) {
      await db
        .update(usersTable)
        .set({ role, updatedAt: new Date() })
        .where(eq(usersTable.id, member.userId));
    }

    const [full] = await db
      .select({
        id: teamMembersTable.id,
        userId: teamMembersTable.userId,
        role: teamMembersTable.role,
        departmentId: teamMembersTable.departmentId,
        departmentName: departmentsTable.name,
        isActive: teamMembersTable.isActive,
        notes: teamMembersTable.notes,
        createdAt: teamMembersTable.createdAt,
        updatedAt: teamMembersTable.updatedAt,
        username: usersTable.username,
        firstName: usersTable.firstName,
        lastName: usersTable.lastName,
        email: usersTable.email,
        profileImageUrl: usersTable.profileImageUrl,
      })
      .from(teamMembersTable)
      .leftJoin(usersTable, eq(teamMembersTable.userId, usersTable.id))
      .leftJoin(departmentsTable, eq(teamMembersTable.departmentId, departmentsTable.id))
      .where(eq(teamMembersTable.id, member.id));

    return res.json(full);
  } catch (err) {
    req.log.error({ err }, "Failed to update team member");
    return res.status(500).json({ error: "Failed to update team member" });
  }
});

router.delete("/team/members/:id", async (req, res) => {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });

  const userRole = (req.user as any).role ?? "member";
  if (!["owner", "admin"].includes(userRole)) {
    return res.status(403).json({ error: "Only owners and admins can remove team members" });
  }

  try {
    const id = parseInt(req.params.id);
    await db.delete(teamMembersTable).where(eq(teamMembersTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to remove team member");
    return res.status(500).json({ error: "Failed to remove team member" });
  }
});

export default router;
