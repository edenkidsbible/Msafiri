import { Router } from "express";
import { db, transactionsTable, transactionCategoriesTable, recurringExpensesTable, settingsTable, operatingWeeksTable } from "@workspace/db";
import { eq, and, desc, asc, isNull, isNotNull, or, sql, lte, gte } from "drizzle-orm";

/** Return the operating week id whose date range contains the given date string (YYYY-MM-DD), or null if none match. */
async function resolveWeekId(date: string): Promise<number | null> {
  const [week] = await db
    .select({ id: operatingWeeksTable.id })
    .from(operatingWeeksTable)
    .where(and(lte(operatingWeeksTable.startDate, date), gte(operatingWeeksTable.endDate, date)))
    .limit(1);
  return week?.id ?? null;
}

const router = Router();

// ─── CATEGORIES ────────────────────────────────────────────────────────────

router.get("/categories", async (req, res) => {
  try {
    const cats = await db.select().from(transactionCategoriesTable).orderBy(asc(transactionCategoriesTable.name));
    res.json(cats);
  } catch (err) {
    req.log.error({ err }, "Failed to list categories");
    res.status(500).json({ error: "Failed to list categories" });
  }
});

router.post("/categories", async (req, res) => {
  try {
    const { name, type, description } = req.body;
    if (!name || !type) return res.status(400).json({ error: "name and type are required" });
    const [cat] = await db.insert(transactionCategoriesTable).values({ name, type, description }).returning();
    res.status(201).json(cat);
  } catch (err) {
    req.log.error({ err }, "Failed to create category");
    res.status(500).json({ error: "Failed to create category" });
  }
});

// ─── TRANSACTIONS ──────────────────────────────────────────────────────────

router.get("/transactions", async (req, res) => {
  try {
    const limit = parseInt(String(req.query.limit ?? 50));
    const offset = parseInt(String(req.query.offset ?? 0));
    const weekId = req.query.weekId ? parseInt(String(req.query.weekId)) : undefined;
    const type = req.query.type ? String(req.query.type) : undefined;

    const conditions = [eq(transactionsTable.isDeleted, false)];
    if (weekId) conditions.push(eq(transactionsTable.weekId, weekId));
    if (type) conditions.push(eq(transactionsTable.type, type));

    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(transactionsTable)
      .where(and(...conditions));

    const items = await db
      .select({
        id: transactionsTable.id,
        date: transactionsTable.date,
        type: transactionsTable.type,
        amountKes: transactionsTable.amountKes,
        description: transactionsTable.description,
        cleared: transactionsTable.cleared,
        categoryId: transactionsTable.categoryId,
        categoryName: transactionCategoriesTable.name,
        weekId: transactionsTable.weekId,
        paymentMethod: transactionsTable.paymentMethod,
        reference: transactionsTable.reference,
        notes: transactionsTable.notes,
        linkedFieldTripId: transactionsTable.linkedFieldTripId,
        linkedContentId: transactionsTable.linkedContentId,
        createdAt: transactionsTable.createdAt,
      })
      .from(transactionsTable)
      .leftJoin(transactionCategoriesTable, eq(transactionsTable.categoryId, transactionCategoriesTable.id))
      .where(and(...conditions))
      .orderBy(desc(transactionsTable.date), desc(transactionsTable.createdAt))
      .limit(limit)
      .offset(offset);

    // Enrich with weekNumber
    const weekIds = [...new Set(items.map(i => i.weekId).filter(Boolean))];
    const weeks = weekIds.length > 0
      ? await db.select({ id: operatingWeeksTable.id, weekNumber: operatingWeeksTable.weekNumber }).from(operatingWeeksTable)
      : [];
    const weekMap = new Map(weeks.map(w => [w.id, w.weekNumber]));

    res.json({
      items: items.map(i => ({ ...i, weekNumber: i.weekId ? (weekMap.get(i.weekId) ?? null) : null })),
      total: countResult?.count ?? 0,
    });
  } catch (err) {
    req.log.error({ err }, "Failed to list transactions");
    res.status(500).json({ error: "Failed to list transactions" });
  }
});

router.post("/transactions", async (req, res) => {
  try {
    const { date, type, amountKes, description, categoryId, cleared, paymentMethod, reference, notes, linkedFieldTripId, linkedContentId } = req.body;
    if (!date || !type || !amountKes || !description) {
      return res.status(400).json({ error: "date, type, amountKes, description are required" });
    }
    const weekId = await resolveWeekId(date);
    const [tx] = await db.insert(transactionsTable).values({
      date, type, amountKes, description, categoryId, cleared: cleared ?? false,
      paymentMethod, reference, notes, linkedFieldTripId, linkedContentId,
      weekId: weekId ?? undefined,
      createdBy: req.user?.id,
    }).returning();
    res.status(201).json(tx);
  } catch (err) {
    req.log.error({ err }, "Failed to create transaction");
    res.status(500).json({ error: "Failed to create transaction" });
  }
});

router.get("/transactions/summary", async (req, res) => {
  try {
    const [settings] = await db.select().from(settingsTable).limit(1);

    // Get total operating cash (sum of income + refund_in - expense - refund_out) and reserve
    const cashRows = await db
      .select({ type: transactionsTable.type, amount: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text` })
      .from(transactionsTable)
      .where(and(eq(transactionsTable.isDeleted, false), eq(transactionsTable.cleared, true)))
      .groupBy(transactionsTable.type);

    let operatingCash = 0;
    let reserveCash = 0;
    for (const row of cashRows) {
      const amt = parseFloat(row.amount);
      if (row.type === "income" || row.type === "refund_in") operatingCash += amt;
      else if (row.type === "expense" || row.type === "refund_out") operatingCash -= amt;
      else if (row.type === "reserve_transfer") { operatingCash -= amt; reserveCash += amt; }
    }

    // Get all weeks from Week 1 in ascending order
    const allWeeks = await db.select().from(operatingWeeksTable)
      .orderBy(asc(operatingWeeksTable.weekNumber));

    res.json({
      operatingCashKes: operatingCash.toFixed(2),
      reserveCashKes: reserveCash.toFixed(2),
      runwayWeeks: null,
      weeks: allWeeks.map(w => ({
        weekId: w.id,
        weekNumber: w.weekNumber,
        startDate: w.startDate,
        plannedInKes: w.plannedCashInKes,
        plannedOutKes: w.plannedCashOutKes,
        plannedEndingKes: w.plannedEndingCashKes,
        actualInKes: w.actualCashInKes,
        actualOutKes: w.actualCashOutKes,
        actualEndingKes: w.actualEndingCashKes,
        varianceKes: w.varianceKes,
      })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get transaction summary");
    res.status(500).json({ error: "Failed to get transaction summary" });
  }
});

// ── Cash position: balances by account + revenue by source + expenses by category ──
router.get("/transactions/cash-position", async (_req, res) => {
  try {
    const cleared = and(eq(transactionsTable.isDeleted, false), eq(transactionsTable.cleared, true));

    // Balance per payment method (income adds, expenses subtract)
    const accountRows = await db
      .select({
        account: transactionsTable.paymentMethod,
        type: transactionsTable.type,
        total: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text`,
      })
      .from(transactionsTable)
      .where(and(cleared, isNotNull(transactionsTable.paymentMethod)))
      .groupBy(transactionsTable.paymentMethod, transactionsTable.type);

    const accountMap: Record<string, number> = {};
    for (const row of accountRows) {
      const acc = row.account!;
      const amt = parseFloat(row.total);
      if (!(acc in accountMap)) accountMap[acc] = 0;
      if (row.type === "income" || row.type === "refund_in") accountMap[acc] += amt;
      else if (row.type === "expense" || row.type === "refund_out") accountMap[acc] -= amt;
      // reserve_transfer kept separate
    }

    // Income grouped by category
    const incomeRows = await db
      .select({
        category: transactionCategoriesTable.name,
        total: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text`,
      })
      .from(transactionsTable)
      .leftJoin(transactionCategoriesTable, eq(transactionsTable.categoryId, transactionCategoriesTable.id))
      .where(and(cleared, or(eq(transactionsTable.type, "income"), eq(transactionsTable.type, "refund_in"))))
      .groupBy(transactionCategoriesTable.name)
      .orderBy(desc(sql<number>`SUM(${transactionsTable.amountKes})`));

    // Expenses grouped by category
    const expenseRows = await db
      .select({
        category: transactionCategoriesTable.name,
        total: sql<string>`COALESCE(SUM(${transactionsTable.amountKes}), 0)::text`,
      })
      .from(transactionsTable)
      .leftJoin(transactionCategoriesTable, eq(transactionsTable.categoryId, transactionCategoriesTable.id))
      .where(and(cleared, or(eq(transactionsTable.type, "expense"), eq(transactionsTable.type, "refund_out"))))
      .groupBy(transactionCategoriesTable.name)
      .orderBy(desc(sql<number>`SUM(${transactionsTable.amountKes})`));

    res.json({
      byAccount: Object.entries(accountMap)
        .map(([account, balance]) => ({ account, balanceKes: balance.toFixed(2) }))
        .sort((a, b) => parseFloat(b.balanceKes) - parseFloat(a.balanceKes)),
      byIncomeSource: incomeRows.map(r => ({
        category: r.category ?? "Uncategorised",
        totalKes: r.total,
      })),
      byExpenseCategory: expenseRows.map(r => ({
        category: r.category ?? "Uncategorised",
        totalKes: r.total,
      })),
    });
  } catch (err) {
    req.log.error({ err }, "Failed to get cash position");
    res.status(500).json({ error: "Failed to get cash position" });
  }
});

router.get("/transactions/:id", async (req, res) => {
  try {
    const [tx] = await db.select().from(transactionsTable).where(and(eq(transactionsTable.id, parseInt(req.params.id)), eq(transactionsTable.isDeleted, false)));
    if (!tx) return res.status(404).json({ error: "Transaction not found" });
    res.json(tx);
  } catch (err) {
    req.log.error({ err }, "Failed to get transaction");
    res.status(500).json({ error: "Failed to get transaction" });
  }
});

router.patch("/transactions/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { date, type, amountKes, description, categoryId, cleared, paymentMethod, reference, notes } = req.body;
    const update: Record<string, unknown> = {};
    if (date !== undefined) {
      update.date = date;
      // Re-derive weekId whenever the date changes
      const weekId = await resolveWeekId(date);
      update.weekId = weekId ?? null;
    }
    if (type !== undefined) update.type = type;
    if (amountKes !== undefined) update.amountKes = amountKes;
    if (description !== undefined) update.description = description;
    if (categoryId !== undefined) update.categoryId = categoryId;
    if (cleared !== undefined) update.cleared = cleared;
    if (paymentMethod !== undefined) update.paymentMethod = paymentMethod;
    if (reference !== undefined) update.reference = reference;
    if (notes !== undefined) update.notes = notes;
    update.updatedBy = req.user?.id;

    const [tx] = await db.update(transactionsTable).set(update).where(and(eq(transactionsTable.id, id), eq(transactionsTable.isDeleted, false))).returning();
    if (!tx) return res.status(404).json({ error: "Transaction not found" });
    res.json(tx);
  } catch (err) {
    req.log.error({ err }, "Failed to update transaction");
    res.status(500).json({ error: "Failed to update transaction" });
  }
});

router.delete("/transactions/:id", async (req, res) => {
  try {
    await db.update(transactionsTable).set({ isDeleted: true, updatedBy: req.user?.id }).where(eq(transactionsTable.id, parseInt(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete transaction");
    res.status(500).json({ error: "Failed to delete transaction" });
  }
});

// ─── RECURRING EXPENSES ────────────────────────────────────────────────────

router.get("/recurring", async (req, res) => {
  try {
    const items = await db.select({
      id: recurringExpensesTable.id,
      name: recurringExpensesTable.name,
      amountKes: recurringExpensesTable.amountKes,
      currencyType: recurringExpensesTable.currencyType,
      amountUsd: recurringExpensesTable.amountUsd,
      frequency: recurringExpensesTable.frequency,
      categoryId: recurringExpensesTable.categoryId,
      categoryName: transactionCategoriesTable.name,
      nextBillingDate: recurringExpensesTable.nextBillingDate,
      isActive: recurringExpensesTable.isActive,
      notes: recurringExpensesTable.notes,
    }).from(recurringExpensesTable)
      .leftJoin(transactionCategoriesTable, eq(recurringExpensesTable.categoryId, transactionCategoriesTable.id))
      .orderBy(asc(recurringExpensesTable.name));
    res.json(items);
  } catch (err) {
    req.log.error({ err }, "Failed to list recurring expenses");
    res.status(500).json({ error: "Failed to list recurring expenses" });
  }
});

router.post("/recurring", async (req, res) => {
  try {
    const { name, amountKes, currencyType, amountUsd, frequency, categoryId, nextBillingDate, notes } = req.body;
    if (!name || !frequency || !currencyType) return res.status(400).json({ error: "name, frequency, currencyType are required" });
    const [item] = await db.insert(recurringExpensesTable).values({ name, amountKes, currencyType, amountUsd, frequency, categoryId, nextBillingDate, notes }).returning();
    res.status(201).json(item);
  } catch (err) {
    req.log.error({ err }, "Failed to create recurring expense");
    res.status(500).json({ error: "Failed to create recurring expense" });
  }
});

router.patch("/recurring/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const update: Record<string, unknown> = {};
    const fields = ["name", "amountKes", "currencyType", "amountUsd", "frequency", "categoryId", "nextBillingDate", "isActive", "notes"];
    for (const f of fields) if (req.body[f] !== undefined) update[f] = req.body[f];
    const [item] = await db.update(recurringExpensesTable).set(update).where(eq(recurringExpensesTable.id, id)).returning();
    if (!item) return res.status(404).json({ error: "Not found" });
    res.json(item);
  } catch (err) {
    req.log.error({ err }, "Failed to update recurring expense");
    res.status(500).json({ error: "Failed to update recurring expense" });
  }
});

router.delete("/recurring/:id", async (req, res) => {
  try {
    await db.delete(recurringExpensesTable).where(eq(recurringExpensesTable.id, parseInt(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete recurring expense");
    res.status(500).json({ error: "Failed to delete recurring expense" });
  }
});

export default router;
