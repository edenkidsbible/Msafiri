import { Router } from "express";
import { db, contentItemsTable, operatingWeeksTable } from "@workspace/db";
import { eq, and, desc, asc, sql } from "drizzle-orm";

const router = Router();

router.get("/content", async (req, res) => {
  try {
    const limit = parseInt(String(req.query.limit ?? 50));
    const offset = parseInt(String(req.query.offset ?? 0));
    const status = req.query.status ? String(req.query.status) : undefined;
    const weekId = req.query.weekId ? parseInt(String(req.query.weekId)) : undefined;
    const isCore = req.query.isCore !== undefined ? req.query.isCore === "true" : undefined;

    const conditions = [eq(contentItemsTable.isDeleted, false)];
    if (status) conditions.push(eq(contentItemsTable.status, status));
    if (weekId) conditions.push(eq(contentItemsTable.weekId, weekId));
    if (isCore !== undefined) conditions.push(eq(contentItemsTable.isCore, isCore));

    const [countResult] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(contentItemsTable)
      .where(and(...conditions));

    const items = await db
      .select({
        id: contentItemsTable.id,
        title: contentItemsTable.title,
        status: contentItemsTable.status,
        weekId: contentItemsTable.weekId,
        weekNumber: operatingWeeksTable.weekNumber,
        isCore: contentItemsTable.isCore,
        platforms: contentItemsTable.platforms,
        pillar: contentItemsTable.pillar,
        format: contentItemsTable.format,
        angle: contentItemsTable.angle,
        hook: contentItemsTable.hook,
        captionSeed: contentItemsTable.captionSeed,
        cta: contentItemsTable.cta,
        scheduledDate: contentItemsTable.scheduledDate,
        postedDate: contentItemsTable.postedDate,
        linkedFieldTripId: contentItemsTable.linkedFieldTripId,
        views: contentItemsTable.views,
        clicks: contentItemsTable.clicks,
        installs: contentItemsTable.installs,
        paidSubscribersAttributed: contentItemsTable.paidSubscribersAttributed,
        founderMinutes: contentItemsTable.founderMinutes,
        notes: contentItemsTable.notes,
        complianceNotes: contentItemsTable.complianceNotes,
        hasComplianceWarning: contentItemsTable.hasComplianceWarning,
        createdAt: contentItemsTable.createdAt,
      })
      .from(contentItemsTable)
      .leftJoin(operatingWeeksTable, eq(contentItemsTable.weekId, operatingWeeksTable.id))
      .where(and(...conditions))
      .orderBy(asc(contentItemsTable.scheduledDate), desc(contentItemsTable.createdAt))
      .limit(limit)
      .offset(offset);

    res.json({ items, total: countResult?.count ?? 0 });
  } catch (err) {
    req.log.error({ err }, "Failed to list content items");
    res.status(500).json({ error: "Failed to list content items" });
  }
});

router.post("/content", async (req, res) => {
  try {
    const { title, status, weekId, isCore, platforms, pillar, format, angle, hook, captionSeed, cta, scheduledDate, linkedFieldTripId, founderMinutes, notes, complianceNotes } = req.body;
    if (!title) return res.status(400).json({ error: "title is required" });

    // Enforce 4-core limit per week
    if (isCore && weekId) {
      const [coreCount] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(contentItemsTable)
        .where(and(eq(contentItemsTable.weekId, weekId), eq(contentItemsTable.isCore, true), eq(contentItemsTable.isDeleted, false)));
      if ((coreCount?.count ?? 0) >= 4) {
        return res.status(400).json({ error: "Maximum 4 core content items per week" });
      }
    }

    const [item] = await db.insert(contentItemsTable).values({
      title, status: status ?? "idea", weekId, isCore: isCore ?? false, platforms,
      pillar, format, angle, hook, captionSeed, cta, scheduledDate, linkedFieldTripId,
      founderMinutes, notes, complianceNotes, createdBy: req.user?.id,
    }).returning();
    res.status(201).json(item);
  } catch (err) {
    req.log.error({ err }, "Failed to create content item");
    res.status(500).json({ error: "Failed to create content item" });
  }
});

router.get("/content/week/:weekId", async (req, res) => {
  try {
    const weekId = parseInt(req.params.weekId);
    const [week] = await db.select().from(operatingWeeksTable).where(eq(operatingWeeksTable.id, weekId));
    if (!week) return res.status(404).json({ error: "Week not found" });

    const all = await db.select().from(contentItemsTable)
      .where(and(eq(contentItemsTable.weekId, weekId), eq(contentItemsTable.isDeleted, false)))
      .orderBy(asc(contentItemsTable.scheduledDate), desc(contentItemsTable.createdAt));

    const coreItems = all.filter(i => i.isCore);
    const optionalItems = all.filter(i => !i.isCore);

    res.json({ weekNumber: week.weekNumber, coreCapacity: 4, coreItems, optionalItems });
  } catch (err) {
    req.log.error({ err }, "Failed to get weekly content");
    res.status(500).json({ error: "Failed to get weekly content" });
  }
});

router.get("/content/:id", async (req, res) => {
  try {
    const [item] = await db.select().from(contentItemsTable).where(and(eq(contentItemsTable.id, parseInt(req.params.id)), eq(contentItemsTable.isDeleted, false)));
    if (!item) return res.status(404).json({ error: "Content item not found" });
    res.json(item);
  } catch (err) {
    req.log.error({ err }, "Failed to get content item");
    res.status(500).json({ error: "Failed to get content item" });
  }
});

router.patch("/content/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const fields = ["title", "status", "weekId", "isCore", "platforms", "pillar", "format", "angle", "hook", "captionSeed", "cta", "scheduledDate", "postedDate", "linkedFieldTripId", "views", "clicks", "installs", "paidSubscribersAttributed", "founderMinutes", "notes", "complianceNotes", "hasComplianceWarning"];
    const update: Record<string, unknown> = {};
    for (const f of fields) if (req.body[f] !== undefined) update[f] = req.body[f];
    update.updatedBy = req.user?.id;
    const [item] = await db.update(contentItemsTable).set(update).where(and(eq(contentItemsTable.id, id), eq(contentItemsTable.isDeleted, false))).returning();
    if (!item) return res.status(404).json({ error: "Content item not found" });
    res.json(item);
  } catch (err) {
    req.log.error({ err }, "Failed to update content item");
    res.status(500).json({ error: "Failed to update content item" });
  }
});

router.delete("/content/:id", async (req, res) => {
  try {
    await db.update(contentItemsTable).set({ isDeleted: true, updatedBy: req.user?.id }).where(eq(contentItemsTable.id, parseInt(req.params.id)));
    res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Failed to delete content item");
    res.status(500).json({ error: "Failed to delete content item" });
  }
});

export default router;
