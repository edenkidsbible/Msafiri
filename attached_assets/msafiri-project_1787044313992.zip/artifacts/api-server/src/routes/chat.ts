import { Router } from "express";
import { db, usersTable, conversationsTable, conversationMembersTable, messagesTable, departmentsTable } from "@workspace/db";
import { eq, and, desc, lt, gt, ne, asc, inArray, sql, isNull } from "drizzle-orm";
import { broadcast, isOnline } from "../lib/wsManager";
import { sendMail, mentionEmail } from "../lib/email";

const router = Router();

// ─── AUTH GUARD ────────────────────────────────────────────────────────────────
function authGuard(req: any, res: any, next: any) {
  if (!req.isAuthenticated()) return res.status(401).json({ error: "Unauthorized" });
  next();
}
router.use(authGuard);

// ─── HELPERS ──────────────────────────────────────────────────────────────────

/** Ensure the current user is a member of a conversation */
async function isMember(conversationId: number, userId: string): Promise<boolean> {
  const [row] = await db
    .select({ id: conversationMembersTable.id })
    .from(conversationMembersTable)
    .where(
      and(
        eq(conversationMembersTable.conversationId, conversationId),
        eq(conversationMembersTable.userId, userId),
      ),
    );
  return Boolean(row);
}

/** Get all userIds in a conversation */
async function getMemberIds(conversationId: number): Promise<string[]> {
  const rows = await db
    .select({ userId: conversationMembersTable.userId })
    .from(conversationMembersTable)
    .where(eq(conversationMembersTable.conversationId, conversationId));
  return rows.map((r) => r.userId);
}

// ─── CONVERSATIONS LIST ────────────────────────────────────────────────────────

router.get("/chat/conversations", async (req, res) => {
  const userId = req.user!.id;

  // Get all conversations this user belongs to
  const memberRows = await db
    .select({ conversationId: conversationMembersTable.conversationId, lastReadMessageId: conversationMembersTable.lastReadMessageId })
    .from(conversationMembersTable)
    .where(eq(conversationMembersTable.userId, userId));

  if (memberRows.length === 0) return res.json([]);

  const convIds = memberRows.map((r) => r.conversationId);
  const lastReadMap = new Map(memberRows.map((r) => [r.conversationId, r.lastReadMessageId]));

  // Fetch conversations
  const convs = await db
    .select({
      id: conversationsTable.id,
      type: conversationsTable.type,
      name: conversationsTable.name,
      departmentId: conversationsTable.departmentId,
      departmentName: departmentsTable.name,
      createdAt: conversationsTable.createdAt,
    })
    .from(conversationsTable)
    .leftJoin(departmentsTable, eq(conversationsTable.departmentId, departmentsTable.id))
    .where(inArray(conversationsTable.id, convIds));

  // For each conversation: last message + unread count
  const result = await Promise.all(
    convs.map(async (conv) => {
      const lastReadId = lastReadMap.get(conv.id) ?? null;

      // Last message
      const [lastMsg] = await db
        .select({
          id: messagesTable.id,
          body: messagesTable.body,
          createdAt: messagesTable.createdAt,
          senderId: messagesTable.senderId,
          senderFirst: usersTable.firstName,
          senderLast: usersTable.lastName,
        })
        .from(messagesTable)
        .leftJoin(usersTable, eq(messagesTable.senderId, usersTable.id))
        .where(and(eq(messagesTable.conversationId, conv.id), isNull(messagesTable.deletedAt)))
        .orderBy(desc(messagesTable.createdAt))
        .limit(1);

      // Unread count
      const unreadWhere = and(
        eq(messagesTable.conversationId, conv.id),
        isNull(messagesTable.deletedAt),
        ne(messagesTable.senderId, userId),
        ...(lastReadId ? [gt(messagesTable.id, lastReadId)] : []),
      );
      const [{ count: unreadCount }] = await db
        .select({ count: sql<number>`count(*)::int` })
        .from(messagesTable)
        .where(unreadWhere);

      // For DMs: get the other user's info
      let otherUser: { id: string; firstName: string | null; lastName: string | null; profileImageUrl: string | null; lastSeenAt: Date | null } | null = null;
      if (conv.type === "direct") {
        const members = await db
          .select({
            id: usersTable.id,
            firstName: usersTable.firstName,
            lastName: usersTable.lastName,
            profileImageUrl: usersTable.profileImageUrl,
            lastSeenAt: usersTable.lastSeenAt,
          })
          .from(conversationMembersTable)
          .innerJoin(usersTable, eq(conversationMembersTable.userId, usersTable.id))
          .where(
            and(
              eq(conversationMembersTable.conversationId, conv.id),
              ne(conversationMembersTable.userId, userId),
            ),
          );
        otherUser = members[0] ?? null;
      }

      return {
        ...conv,
        lastMessage: lastMsg ?? null,
        unreadCount: unreadCount ?? 0,
        otherUser,
      };
    }),
  );

  // Sort by last message recency
  result.sort((a, b) => {
    const aTime = a.lastMessage?.createdAt?.getTime() ?? a.createdAt.getTime();
    const bTime = b.lastMessage?.createdAt?.getTime() ?? b.createdAt.getTime();
    return bTime - aTime;
  });

  // Ensure all_team is first
  const sorted = [
    ...result.filter((c) => c.type === "all_team"),
    ...result.filter((c) => c.type === "department"),
    ...result.filter((c) => c.type === "direct"),
  ];

  res.json(sorted);
});

// ─── MESSAGES ─────────────────────────────────────────────────────────────────

router.get("/chat/conversations/:id/messages", async (req, res) => {
  const userId = req.user!.id;
  const convId = parseInt(req.params.id);
  const limit = Math.min(Number(req.query["limit"] ?? 50), 100);
  const before = req.query["before"] ? Number(req.query["before"]) : null;

  if (!(await isMember(convId, userId))) {
    return res.status(403).json({ error: "Not a member of this conversation" });
  }

  const msgWhere = before
    ? and(eq(messagesTable.conversationId, convId), isNull(messagesTable.deletedAt), lt(messagesTable.id, before))
    : and(eq(messagesTable.conversationId, convId), isNull(messagesTable.deletedAt));

  const msgs = await db
    .select({
      id: messagesTable.id,
      conversationId: messagesTable.conversationId,
      body: messagesTable.body,
      createdAt: messagesTable.createdAt,
      senderId: messagesTable.senderId,
      senderFirstName: usersTable.firstName,
      senderLastName: usersTable.lastName,
      senderProfileImageUrl: usersTable.profileImageUrl,
    })
    .from(messagesTable)
    .leftJoin(usersTable, eq(messagesTable.senderId, usersTable.id))
    .where(msgWhere)
    .orderBy(desc(messagesTable.id))
    .limit(limit);

  res.json(msgs.reverse()); // chronological order
});

// ─── SEND MESSAGE ─────────────────────────────────────────────────────────────

router.post("/chat/conversations/:id/messages", async (req, res) => {
  const userId = req.user!.id;
  const convId = parseInt(req.params.id);
  const { body } = req.body;

  if (!body?.trim()) return res.status(400).json({ error: "body is required" });

  if (!(await isMember(convId, userId))) {
    return res.status(403).json({ error: "Not a member of this conversation" });
  }

  const [msg] = await db
    .insert(messagesTable)
    .values({ conversationId: convId, senderId: userId, body: body.trim() })
    .returning();

  // Fetch sender info
  const [sender] = await db
    .select({ firstName: usersTable.firstName, lastName: usersTable.lastName, profileImageUrl: usersTable.profileImageUrl, email: usersTable.email })
    .from(usersTable)
    .where(eq(usersTable.id, userId));

  const payload = {
    type: "new_message",
    message: {
      id: msg.id,
      conversationId: convId,
      body: msg.body,
      createdAt: msg.createdAt,
      senderId: userId,
      senderFirstName: sender?.firstName ?? null,
      senderLastName: sender?.lastName ?? null,
      senderProfileImageUrl: sender?.profileImageUrl ?? null,
    },
  };

  // Broadcast to all members
  const memberIds = await getMemberIds(convId);
  broadcast(memberIds, payload);

  // Check for @mentions and send email notifications
  const mentionPattern = /@(\w+)/g;
  const mentions = [...body.matchAll(mentionPattern)].map((m) => m[1]);
  if (mentions.length > 0) {
    // Get the conversation name for email context
    const [conv] = await db.select({ name: conversationsTable.name, type: conversationsTable.type }).from(conversationsTable).where(eq(conversationsTable.id, convId));
    const channelName = conv?.name ?? "a conversation";

    for (const mention of mentions) {
      const [mentionedUser] = await db
        .select({ id: usersTable.id, email: usersTable.email, firstName: usersTable.firstName })
        .from(usersTable)
        .where(sql`lower(${usersTable.username}) = lower(${mention}) OR lower(${usersTable.firstName}) = lower(${mention})`);

      if (mentionedUser?.email && mentionedUser.id !== userId) {
        const emailContent = mentionEmail({
          mentionedName: mentionedUser.firstName ?? mention,
          senderName: [sender?.firstName, sender?.lastName].filter(Boolean).join(" ") || "A team member",
          channelName,
          messageBody: body,
        });
        sendMail({ to: mentionedUser.email, ...emailContent });
      }
    }
  }

  res.status(201).json(payload.message);
});

// ─── MARK READ ────────────────────────────────────────────────────────────────

router.post("/chat/conversations/:id/read", async (req, res) => {
  const userId = req.user!.id;
  const convId = parseInt(req.params.id);

  // Get the latest message id in this conversation
  const [latest] = await db
    .select({ id: messagesTable.id })
    .from(messagesTable)
    .where(and(eq(messagesTable.conversationId, convId), isNull(messagesTable.deletedAt)))
    .orderBy(desc(messagesTable.id))
    .limit(1);

  if (latest) {
    await db
      .update(conversationMembersTable)
      .set({ lastReadMessageId: latest.id })
      .where(
        and(
          eq(conversationMembersTable.conversationId, convId),
          eq(conversationMembersTable.userId, userId),
        ),
      );

    // Broadcast read receipt to other members
    const memberIds = await getMemberIds(convId);
    broadcast(
      memberIds.filter((id) => id !== userId),
      { type: "read_receipt", conversationId: convId, userId, lastReadMessageId: latest.id },
    );
  }

  res.json({ ok: true });
});

// ─── CREATE DM ────────────────────────────────────────────────────────────────

router.post("/chat/conversations", async (req, res) => {
  const userId = req.user!.id;
  const { participantUserId } = req.body;
  if (!participantUserId) return res.status(400).json({ error: "participantUserId is required" });
  if (participantUserId === userId) return res.status(400).json({ error: "Cannot DM yourself" });

  // Check for existing DM
  const existing = await db
    .select({ id: conversationsTable.id })
    .from(conversationsTable)
    .innerJoin(conversationMembersTable, eq(conversationMembersTable.conversationId, conversationsTable.id))
    .where(
      and(
        eq(conversationsTable.type, "direct"),
        eq(conversationMembersTable.userId, userId),
      ),
    );

  for (const e of existing) {
    const [other] = await db
      .select({ userId: conversationMembersTable.userId })
      .from(conversationMembersTable)
      .where(and(eq(conversationMembersTable.conversationId, e.id), eq(conversationMembersTable.userId, participantUserId)));
    if (other) return res.json({ id: e.id, existing: true });
  }

  // Create new DM
  const [conv] = await db.insert(conversationsTable).values({ type: "direct" }).returning();
  await db.insert(conversationMembersTable).values([
    { conversationId: conv.id, userId },
    { conversationId: conv.id, userId: participantUserId },
  ]);

  res.status(201).json({ id: conv.id, existing: false });
});

// ─── CONVERSATION MEMBERS LIST ────────────────────────────────────────────────

router.get("/chat/conversations/:id/members", async (req, res) => {
  const userId = req.user!.id;
  const convId = parseInt(req.params.id);

  if (!(await isMember(convId, userId))) {
    return res.status(403).json({ error: "Not a member of this conversation" });
  }

  const members = await db
    .select({
      id: usersTable.id,
      firstName: usersTable.firstName,
      lastName: usersTable.lastName,
      profileImageUrl: usersTable.profileImageUrl,
      email: usersTable.email,
      role: usersTable.role,
      lastSeenAt: usersTable.lastSeenAt,
      joinedAt: conversationMembersTable.joinedAt,
    })
    .from(conversationMembersTable)
    .leftJoin(usersTable, eq(conversationMembersTable.userId, usersTable.id))
    .where(eq(conversationMembersTable.conversationId, convId))
    .orderBy(asc(usersTable.firstName));

  const membersWithOnline = members.map((m) => ({
    ...m,
    isOnline: isOnline(m.id!),
  }));

  res.json(membersWithOnline);
});

// ─── UNREAD TOTAL ─────────────────────────────────────────────────────────────

router.get("/chat/unread", async (req, res) => {
  const userId = req.user!.id;

  const memberRows = await db
    .select({ conversationId: conversationMembersTable.conversationId, lastReadMessageId: conversationMembersTable.lastReadMessageId })
    .from(conversationMembersTable)
    .where(eq(conversationMembersTable.userId, userId));

  if (memberRows.length === 0) return res.json({ total: 0 });

  let total = 0;
  for (const row of memberRows) {
    const whereClause = and(
      eq(messagesTable.conversationId, row.conversationId),
      isNull(messagesTable.deletedAt),
      ne(messagesTable.senderId, userId),
      ...(row.lastReadMessageId ? [gt(messagesTable.id, row.lastReadMessageId)] : []),
    );
    const [{ count }] = await db
      .select({ count: sql<number>`count(*)::int` })
      .from(messagesTable)
      .where(whereClause);
    total += count ?? 0;
  }

  res.json({ total });
});

export default router;
