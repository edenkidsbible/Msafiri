#!/bin/bash
set -e

pnpm install --frozen-lockfile

# Apply database schema changes (adds tasks.position column if missing, etc.)
pnpm --filter @workspace/db push-force

# Backfill positions for existing tasks that have position = 0
# (safe to run repeatedly — only updates rows where position is still the default)
node -e "
const { Pool } = require('./lib/db/node_modules/pg');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
pool.query(\`
  WITH needs_backfill AS (
    SELECT status FROM tasks
    WHERE is_deleted = false
    GROUP BY status
    HAVING COUNT(*) FILTER (WHERE position != 0) = 0
  ),
  ranked AS (
    SELECT t.id,
           ROW_NUMBER() OVER (
             PARTITION BY t.status
             ORDER BY
               CASE t.priority WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END,
               t.due_date NULLS LAST,
               t.created_at
           ) - 1 AS rn
    FROM tasks t
    JOIN needs_backfill nb ON nb.status = t.status
    WHERE t.is_deleted = false
  )
  UPDATE tasks SET position = ranked.rn FROM ranked WHERE tasks.id = ranked.id
\`).then(r => { console.log('Position backfill: rows updated =', r.rowCount); pool.end(); })
  .catch(e => { console.error('Position backfill error:', e.message); pool.end(); process.exit(1); });
"

# Rebuild generated API client library (required for TypeScript project references)
pnpm --filter @workspace/api-client-react exec tsc -p tsconfig.json
