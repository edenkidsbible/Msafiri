/**
 * Full workbook seed — Msafiri Founder OS
 * Seeds: Content Idea Bank (252), Hook Bank (115), CTA Bank (35),
 *        Growth Experiments (44), Risk Register (12), Partnership CRM (5),
 *        Campaign Moments (7)
 * Run: node scripts/seed-all-workbook-data.mjs  (from lib/db dir or with cwd patch)
 */

import pg from 'pg';
import { createRequire } from 'module';
import { fileURLToPath } from 'url';
import { dirname, resolve } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// Load xlsx from workspace root
const XLSX = require(resolve(__dirname, '../node_modules/xlsx/lib/xlsx.js'));
const WB_PATH = resolve(__dirname, '../attached_assets/Msafiri_Founder_OS_Live_App_Masterplan_Aug2026-Jan2027_1786613115837.xlsx');

const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

function parseSheet(wb, name) {
  const ws = wb.Sheets[name];
  if (!ws) return [];
  return XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
}

function txt(v) {
  if (!v) return null;
  return String(v).trim() || null;
}

async function clearPreviousSeed(client) {
  // Remove only system-seeded content/tasks to avoid duplication; keep user data
  await client.query(`DELETE FROM content_items WHERE created_by = 'system-seed' AND status = 'idea' AND week_id IS NULL`);
  await client.query(`DELETE FROM tasks WHERE created_by = 'system-seed' AND module IN ('growth','risk','partnership','content') AND status = 'backlog'`);
  console.log('  ✓ Cleared previous library seed');
}

async function seedContentIdeas(client, wb, weekIdByNum) {
  const rows = parseSheet(wb, 'Content Idea Bank').slice(4).filter(r => r[0] && typeof r[0] === 'number');
  // cols: [0]id [1]pillar [2]feature [3]series [4]audience [5]funnel [6]format [7]hook [8]openingVisual [9]valuePay [10]captionSeed [11]cta [12]assets [13]diff [14]hookStr [15]useful [16]conv [17]prodEff [18]seasonal [19]priority [20]compliance [21]repurpose
  let count = 0;
  for (const r of rows) {
    const hook = txt(r[7]);
    const title = hook ? (hook.length > 140 ? hook.slice(0, 137) + '…' : hook) : `Content idea #${r[0]}`;
    const compliance = txt(r[20]);
    const notes = [
      r[3] && `Series: ${r[3]}`,
      r[4] && `Audience: ${r[4]}`,
      r[5] && `Funnel: ${r[5]}`,
      r[12] && `Assets: ${r[12]}`,
      r[19] && `Priority score: ${r[19]}`,
      r[21] && `Repurpose: ${r[21]}`,
    ].filter(Boolean).join(' | ');
    await client.query(
      `INSERT INTO content_items
       (title, status, week_id, is_core, pillar, format, angle, hook, caption_seed, cta, compliance_notes, has_compliance_warning, notes, created_by)
       VALUES ($1,'idea',NULL,false,$2,$3,$4,$5,$6,$7,$8,$9,$10,'system-seed')`,
      [
        title, txt(r[1]), txt(r[6]), txt(r[9]),
        hook, txt(r[10]), txt(r[11]),
        compliance, !!(compliance && compliance.length > 0), notes || null,
      ]
    );
    count++;
  }
  return count;
}

async function seedHookBank(client, wb) {
  const rows = parseSheet(wb, 'Hook Bank').slice(4).filter(r => r[0] && r[2]);
  // cols: [0]category [1]intent [2]hook [3]bestUse [4]example [5]notes
  let count = 0;
  for (const r of rows) {
    const hookText = txt(r[2]);
    if (!hookText) continue;
    const title = hookText.length > 140 ? hookText.slice(0, 137) + '…' : hookText;
    const notes = [
      r[1] && `Intent: ${r[1]}`,
      r[4] && `Example topic: ${r[4]}`,
      r[5] && `Note: ${r[5]}`,
    ].filter(Boolean).join(' | ');
    await client.query(
      `INSERT INTO content_items
       (title, status, week_id, is_core, pillar, format, hook, notes, has_compliance_warning, created_by)
       VALUES ($1,'idea',NULL,false,$2,$3,$4,$5,false,'system-seed')`,
      [`[Hook] ${title}`, `Hook Bank — ${txt(r[0]) || 'General'}`, txt(r[3]), hookText, notes || null]
    );
    count++;
  }
  return count;
}

async function seedCTABank(client, wb) {
  const rows = parseSheet(wb, 'CTA Bank').slice(4).filter(r => r[0] && r[2]);
  // cols: [0]funnelStage [1]ctaType [2]cta [3]bestUse [4]strongerWhen [5]notes
  let count = 0;
  for (const r of rows) {
    const ctaText = txt(r[2]);
    if (!ctaText) continue;
    const title = ctaText.length > 140 ? ctaText.slice(0, 137) + '…' : ctaText;
    const notes = [
      r[1] && `Type: ${r[1]}`,
      r[4] && `Stronger when: ${r[4]}`,
      r[5] && `Note: ${r[5]}`,
    ].filter(Boolean).join(' | ');
    await client.query(
      `INSERT INTO content_items
       (title, status, week_id, is_core, pillar, format, cta, notes, has_compliance_warning, created_by)
       VALUES ($1,'idea',NULL,false,$2,$3,$4,$5,false,'system-seed')`,
      [`[CTA] ${title}`, `CTA Bank — ${txt(r[0]) || 'General'}`, txt(r[3]), ctaText, notes || null]
    );
    count++;
  }
  return count;
}

async function seedGrowthExperiments(client, wb, weekIdByNum) {
  const rows = parseSheet(wb, 'Growth Experiments').slice(4)
    .filter(r => r[0] && typeof r[0] === 'string' && r[0].startsWith('G') && r[2]);
  // cols: [0]id [1]channel [2]experiment [3]hypothesis [4]howToRun [5]costBand [6]reach [7]trust [8]speed [9]effort [10]priority [11]status [12]stopRule [13]owner
  let count = 0;
  for (const r of rows) {
    const score = Number(r[10]) || 0;
    const priority = score >= 11 ? 'high' : score >= 8 ? 'medium' : 'low';
    const desc = [
      r[3] && `Hypothesis: ${r[3]}`,
      r[4] && `How to run: ${r[4]}`,
      r[5] && `Cost: ${r[5]}`,
      r[1] && `Channel: ${r[1]}`,
    ].filter(Boolean).join('\n');
    const existingStatus = txt(r[11]);
    const status = existingStatus === 'Done' ? 'done' : existingStatus === 'Running' ? 'in_progress' : 'backlog';
    await client.query(
      `INSERT INTO tasks (title, description, status, priority, module, type, acceptance_criteria, created_by)
       VALUES ($1,$2,$3,$4,'growth','admin',$5,'system-seed')`,
      [txt(r[2]), desc, status, priority, txt(r[12])]
    );
    count++;
  }
  return count;
}

async function seedRiskRegister(client, wb) {
  const rows = parseSheet(wb, 'Risk Register').slice(4)
    .filter(r => r[0] && r[1] && typeof r[1] === 'string' && r[1].length > 2);
  // cols: [0]id [1]risk [2]whyMatters [3]likelihood [4]impact [5]score [6]warning [7]mitigation [8]owner [9]status [10]notes
  let count = 0;
  for (const r of rows) {
    const score = Number(r[5]) || 4;
    const priority = score >= 9 ? 'critical' : score >= 6 ? 'high' : 'medium';
    const existingStatus = txt(r[9]);
    const status = existingStatus === 'Done' ? 'done' : existingStatus === 'In Progress' ? 'in_progress' : 'backlog';
    const desc = [
      r[2] && `Why it matters: ${r[2]}`,
      r[3] && `Likelihood: ${r[3]}`,
      r[4] && `Impact: ${r[4]}`,
      r[6] && `Early warning: ${r[6]}`,
      r[7] && `Mitigation: ${r[7]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO tasks (title, description, status, priority, module, type, created_by)
       VALUES ($1,$2,$3,$4,'risk','admin','system-seed')`,
      [`Risk: ${txt(r[1])}`, desc, status, priority]
    );
    count++;
  }
  return count;
}

async function seedPartnershipCRM(client, wb) {
  const rows = parseSheet(wb, 'Partnership CRM').slice(4)
    .filter(r => r[0] && r[1] && typeof r[1] === 'string' && r[1].length > 2);
  // cols: [0]id [1]org [2]type [3]contact [4]contactInfo [5]warmIntro [6]valueForThem [7]valueForMs [8]offer [9]stage [10]nextStep [11]objection [12]followUp [13]outcome [14]notes
  let count = 0;
  for (const r of rows) {
    const desc = [
      r[2] && `Type: ${r[2]}`,
      r[6] && `Value for them: ${r[6]}`,
      r[7] && `Value for Msafiri: ${r[7]}`,
      r[8] && `Offer: ${r[8]}`,
      r[10] && `Next step: ${r[10]}`,
      r[11] && `Objection to overcome: ${r[11]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO tasks (title, description, status, priority, module, type, created_by)
       VALUES ($1,$2,'backlog','medium','partnership','admin','system-seed')`,
      [`Partner: ${txt(r[1])}`, desc]
    );
    count++;
  }
  return count;
}

async function seedCampaignMoments(client, wb, weekIdByNum) {
  const rows = parseSheet(wb, 'Campaign Moments').slice(4)
    .filter(r => r[0] && r[1]);
  // cols: [0]date [1]moment [2]emotion [3]contentApproach [4]contentIdeas [5]features [6]cta [7]risk [8]sourceUrl
  let count = 0;
  for (const r of rows) {
    const desc = [
      r[2] && `Audience emotion: ${r[2]}`,
      r[3] && `Approach: ${r[3]}`,
      r[4] && `Content ideas: ${r[4]}`,
      r[5] && `Features to highlight: ${r[5]}`,
      r[6] && `CTA: ${r[6]}`,
      r[7] && `Risk/guardrail: ${r[7]}`,
    ].filter(Boolean).join('\n');
    // Excel serial date → JS date
    let dueDate = null;
    if (typeof r[0] === 'number') {
      const jsDate = new Date((r[0] - 25569) * 86400 * 1000);
      dueDate = jsDate.toISOString().slice(0, 10);
    } else if (typeof r[0] === 'string') {
      dueDate = null; // "Aug–Sep weekly" etc — skip
    }
    await client.query(
      `INSERT INTO tasks (title, description, status, priority, module, type, due_date, created_by)
       VALUES ($1,$2,'backlog','high','content','campaign',$3,'system-seed')`,
      [`Campaign: ${txt(r[1])}`, desc, dueDate]
    );
    count++;
  }
  return count;
}

async function seedSeriesPlaybook(client, wb) {
  const rows = parseSheet(wb, 'Series Playbook').slice(4).filter(r => r[0] && r[1]);
  // cols: [0]series [1]purpose [2]audiencePromise [3]episodeStructure [4]sigs [5]frequency [6]platforms [7]kpi [8]variations [9]avoid
  let count = 0;
  for (const r of rows) {
    const desc = [
      r[1] && `Purpose: ${r[1]}`,
      r[2] && `Audience promise: ${r[2]}`,
      r[3] && `Episode structure: ${r[3]}`,
      r[4] && `Signature shots: ${r[4]}`,
      r[5] && `Recommended frequency: ${r[5]}`,
      r[6] && `Best platforms: ${r[6]}`,
      r[7] && `Primary KPI: ${r[7]}`,
      r[8] && `Variation ideas: ${r[8]}`,
      r[9] && `Avoid: ${r[9]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO content_items (title, status, week_id, is_core, pillar, notes, has_compliance_warning, created_by)
       VALUES ($1,'idea',NULL,false,'Series Playbook',$2,false,'system-seed')`,
      [`[Series] ${txt(r[0])}`, desc]
    );
    count++;
  }
  return count;
}

async function seedAudienceMap(client, wb) {
  const rows = parseSheet(wb, 'Audience Map').slice(4).filter(r => r[0] && r[1] && typeof r[1] === 'string');
  // Store as tasks with module=growth for reference
  let count = 0;
  for (const r of rows) {
    if (!r[0] || !r[1]) continue;
    const desc = r.filter((v, i) => i > 0 && v).join(' | ');
    await client.query(
      `INSERT INTO tasks (title, description, status, priority, module, type, created_by)
       VALUES ($1,$2,'backlog','low','growth','research','system-seed')`,
      [`Audience: ${txt(r[0])}`, desc]
    );
    count++;
  }
  return count;
}

async function seedWeeklyThemes(client, wb) {
  // Already embedded in weekly_plans.content_plan during initial seed, but update fully
  const rows = parseSheet(wb, 'Weekly Themes').slice(4).filter(r => r[0] && typeof r[0] === 'number');
  // cols: [0]weekNum [1]weekDate [2]dateRange [3]editorialFocus [4]featureHighlight [5]audience [6]heroAngle [7]editorialTheme [8]coreContentPlan [9]openingQuestion [10]productionGuide [11]experiment [12]kpi [13]repurpose
  let count = 0;
  for (const r of rows) {
    const weekNum = r[0];
    const { rows: weekRows } = await client.query('SELECT id FROM operating_weeks WHERE week_number = $1', [weekNum]);
    if (!weekRows[0]) continue;
    const weekId = weekRows[0].id;
    const contentPlan = [
      r[3] && `Editorial focus: ${r[3]}`,
      r[4] && `Feature highlight: ${r[4]}`,
      r[5] && `Audience: ${r[5]}`,
      r[7] && `Theme: ${r[7]}`,
      r[8] && `Core content plan: ${r[8]}`,
      r[9] && `Opening question: ${r[9]}`,
      r[11] && `Experiment: ${r[11]}`,
      r[12] && `KPI: ${r[12]}`,
    ].filter(Boolean).join('\n');
    // Update the weekly plan's content_plan field with full theme data
    await client.query(
      `UPDATE weekly_plans SET content_plan = $1 WHERE week_id = $2`,
      [contentPlan, weekId]
    );
    count++;
  }
  return count;
}

async function main() {
  const client = await pool.connect();
  try {
    const wb = XLSX.readFile(WB_PATH);
    console.log('📚 Loaded workbook:', wb.SheetNames.length, 'sheets\n');

    await clearPreviousSeed(client);

    // Fetch week IDs
    const { rows: weeks } = await client.query('SELECT id, week_number FROM operating_weeks ORDER BY week_number');
    const weekIdByNum = {};
    weeks.forEach(w => { weekIdByNum[w.week_number] = w.id; });

    console.log('🎬 Seeding Content Idea Bank (252 ideas)...');
    const ideaCount = await seedContentIdeas(client, wb, weekIdByNum);
    console.log(`  ✓ ${ideaCount} content ideas`);

    console.log('🎣 Seeding Hook Bank...');
    const hookCount = await seedHookBank(client, wb);
    console.log(`  ✓ ${hookCount} hooks`);

    console.log('📢 Seeding CTA Bank...');
    const ctaCount = await seedCTABank(client, wb);
    console.log(`  ✓ ${ctaCount} CTAs`);

    console.log('🧪 Seeding Growth Experiments...');
    const growthCount = await seedGrowthExperiments(client, wb, weekIdByNum);
    console.log(`  ✓ ${growthCount} growth experiments`);

    console.log('⚠️  Seeding Risk Register...');
    const riskCount = await seedRiskRegister(client, wb);
    console.log(`  ✓ ${riskCount} risks`);

    console.log('🤝 Seeding Partnership CRM...');
    const partnerCount = await seedPartnershipCRM(client, wb);
    console.log(`  ✓ ${partnerCount} partnership prospects`);

    console.log('📅 Seeding Campaign Moments...');
    const campaignCount = await seedCampaignMoments(client, wb, weekIdByNum);
    console.log(`  ✓ ${campaignCount} campaigns`);

    console.log('📺 Seeding Series Playbook...');
    const seriesCount = await seedSeriesPlaybook(client, wb);
    console.log(`  ✓ ${seriesCount} series`);

    console.log('🗺️  Seeding Audience Map...');
    const audienceCount = await seedAudienceMap(client, wb);
    console.log(`  ✓ ${audienceCount} audience segments`);

    console.log('📋 Updating Weekly Themes in plans...');
    const themeCount = await seedWeeklyThemes(client, wb);
    console.log(`  ✓ ${themeCount} weekly themes updated`);

    // Final summary
    const { rows: summary } = await client.query(`SELECT
      (SELECT COUNT(*) FROM content_items WHERE NOT is_deleted) as content,
      (SELECT COUNT(*) FROM tasks WHERE NOT is_deleted) as tasks,
      (SELECT COUNT(*) FROM weekly_plans) as plans`);
    console.log(`\n🎉 Done!  content=${summary[0].content}  tasks=${summary[0].tasks}  plans=${summary[0].plans}`);
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch(err => { console.error('❌', err.message); process.exit(1); });
