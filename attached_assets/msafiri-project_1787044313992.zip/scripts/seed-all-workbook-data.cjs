/**
 * Full workbook seed — Msafiri Founder OS
 * Run: node /home/runner/workspace/scripts/seed-all-workbook-data.cjs
 */
'use strict';

const path = require('path');
const XLSX = require(path.resolve(__dirname, '../node_modules/xlsx'));
const { Pool } = require(path.resolve(__dirname, '../lib/db/node_modules/pg'));

const WB_PATH = path.resolve(__dirname, '../attached_assets/Msafiri_Founder_OS_Live_App_Masterplan_Aug2026-Jan2027_1786613115837.xlsx');
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

function parseSheet(wb, name) {
  const ws = wb.Sheets[name];
  if (!ws) return [];
  return XLSX.utils.sheet_to_json(ws, { header: 1, defval: null });
}

function txt(v) {
  if (v == null) return null;
  const s = String(v).trim();
  return s || null;
}

async function clearPreviousSeed(client) {
  await client.query(`DELETE FROM content_items WHERE created_by = 'system-seed' AND week_id IS NULL`);
  await client.query(`DELETE FROM tasks WHERE created_by = 'system-seed'`);
  console.log('  ✓ Cleared previous seed entries');
}

async function seedContentIdeas(client, wb) {
  const rows = parseSheet(wb, 'Content Idea Bank').slice(4).filter(r => r[0] && typeof r[0] === 'number');
  let count = 0;
  for (const r of rows) {
    const hook = txt(r[7]);
    const title = hook ? (hook.length > 140 ? hook.slice(0, 137) + '…' : hook) : `Idea #${r[0]}`;
    const compliance = txt(r[20]);
    const notes = [
      r[3] && `Series: ${r[3]}`,
      r[4] && `Audience: ${r[4]}`,
      r[5] && `Funnel: ${r[5]}`,
      r[12] && `Assets: ${r[12]}`,
      r[19] && `Priority: ${r[19]}`,
      r[21] && `Repurpose: ${r[21]}`,
    ].filter(Boolean).join(' | ');
    await client.query(
      `INSERT INTO content_items (title,status,week_id,is_core,pillar,format,angle,hook,caption_seed,cta,compliance_notes,has_compliance_warning,notes,created_by)
       VALUES ($1,'idea',NULL,false,$2,$3,$4,$5,$6,$7,$8,$9,$10,'system-seed')`,
      [title, txt(r[1]), txt(r[6]), txt(r[9]), hook, txt(r[10]), txt(r[11]),
       compliance, !!(compliance && compliance.length), notes || null]
    );
    count++;
  }
  return count;
}

async function seedHookBank(client, wb) {
  const rows = parseSheet(wb, 'Hook Bank').slice(4).filter(r => r[0] && r[2]);
  let count = 0;
  for (const r of rows) {
    const hookText = txt(r[2]);
    if (!hookText) continue;
    const title = '[Hook] ' + (hookText.length > 130 ? hookText.slice(0, 127) + '…' : hookText);
    const notes = [r[1] && `Intent: ${r[1]}`, r[4] && `Example: ${r[4]}`, r[5] && `Note: ${r[5]}`].filter(Boolean).join(' | ');
    await client.query(
      `INSERT INTO content_items (title,status,week_id,is_core,pillar,format,hook,notes,has_compliance_warning,created_by)
       VALUES ($1,'idea',NULL,false,$2,$3,$4,$5,false,'system-seed')`,
      [title, `Hook Bank — ${txt(r[0]) || 'General'}`, txt(r[3]), hookText, notes || null]
    );
    count++;
  }
  return count;
}

async function seedCTABank(client, wb) {
  const rows = parseSheet(wb, 'CTA Bank').slice(4).filter(r => r[0] && r[2]);
  let count = 0;
  for (const r of rows) {
    const ctaText = txt(r[2]);
    if (!ctaText) continue;
    const title = '[CTA] ' + (ctaText.length > 130 ? ctaText.slice(0, 127) + '…' : ctaText);
    const notes = [r[1] && `Type: ${r[1]}`, r[4] && `Stronger when: ${r[4]}`, r[5] && `Note: ${r[5]}`].filter(Boolean).join(' | ');
    await client.query(
      `INSERT INTO content_items (title,status,week_id,is_core,pillar,format,cta,notes,has_compliance_warning,created_by)
       VALUES ($1,'idea',NULL,false,$2,$3,$4,$5,false,'system-seed')`,
      [title, `CTA Bank — ${txt(r[0]) || 'General'}`, txt(r[3]), ctaText, notes || null]
    );
    count++;
  }
  return count;
}

async function seedGrowthExperiments(client, wb) {
  const rows = parseSheet(wb, 'Growth Experiments').slice(4)
    .filter(r => r[0] && typeof r[0] === 'string' && r[0].startsWith('G') && r[2]);
  let count = 0;
  for (const r of rows) {
    const score = Number(r[10]) || 0;
    const priority = score >= 11 ? 'high' : score >= 8 ? 'medium' : 'low';
    const existingStatus = txt(r[11]);
    const status = existingStatus === 'Done' ? 'done' : existingStatus === 'Running' ? 'in_progress' : 'backlog';
    const desc = [
      r[3] && `Hypothesis: ${r[3]}`,
      r[4] && `How to run: ${r[4]}`,
      r[5] && `Cost: ${r[5]}`,
      r[1] && `Channel: ${r[1]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO tasks (title,description,status,priority,module,type,acceptance_criteria,created_by)
       VALUES ($1,$2,$3,$4,'growth','admin',$5,'system-seed')`,
      [txt(r[2]), desc, status, priority, txt(r[12])]
    );
    count++;
  }
  return count;
}

async function seedRiskRegister(client, wb) {
  const rows = parseSheet(wb, 'Risk Register').slice(4).filter(r => r[0] && r[1] && String(r[1]).length > 2);
  let count = 0;
  for (const r of rows) {
    const score = Number(r[5]) || 4;
    const priority = score >= 9 ? 'critical' : score >= 6 ? 'high' : 'medium';
    const existingStatus = txt(r[9]);
    const status = existingStatus === 'Done' ? 'done' : existingStatus === 'In Progress' ? 'in_progress' : 'backlog';
    const desc = [
      r[2] && `Why it matters: ${r[2]}`,
      r[3] && `Likelihood: ${r[3]}`,
      r[4] && `Impact: ${r[4]}`,
      r[6] && `Early warning: ${r[6]}`,
      r[7] && `Mitigation: ${r[7]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO tasks (title,description,status,priority,module,type,created_by)
       VALUES ($1,$2,$3,$4,'risk','admin','system-seed')`,
      [`Risk: ${txt(r[1])}`, desc, status, priority]
    );
    count++;
  }
  return count;
}

async function seedPartnershipCRM(client, wb) {
  const rows = parseSheet(wb, 'Partnership CRM').slice(4)
    .filter(r => r[0] && r[1] && String(r[1]).length > 2);
  let count = 0;
  for (const r of rows) {
    const desc = [
      r[2] && `Type: ${r[2]}`,
      r[6] && `Value for them: ${r[6]}`,
      r[7] && `Value for Msafiri: ${r[7]}`,
      r[8] && `Offer: ${r[8]}`,
      r[10] && `Next step: ${r[10]}`,
      r[11] && `Objection: ${r[11]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO tasks (title,description,status,priority,module,type,created_by)
       VALUES ($1,$2,'backlog','medium','partnership','admin','system-seed')`,
      [`Partner: ${txt(r[1])}`, desc]
    );
    count++;
  }
  return count;
}

async function seedCampaignMoments(client, wb) {
  const rows = parseSheet(wb, 'Campaign Moments').slice(4).filter(r => r[0] && r[1]);
  let count = 0;
  for (const r of rows) {
    const desc = [
      r[2] && `Emotion: ${r[2]}`,
      r[3] && `Approach: ${r[3]}`,
      r[4] && `Content ideas: ${r[4]}`,
      r[5] && `Features: ${r[5]}`,
      r[6] && `CTA: ${r[6]}`,
      r[7] && `Guardrail: ${r[7]}`,
    ].filter(Boolean).join('\n');
    let dueDate = null;
    if (typeof r[0] === 'number') {
      const jsDate = new Date((r[0] - 25569) * 86400 * 1000);
      dueDate = jsDate.toISOString().slice(0, 10);
    }
    await client.query(
      `INSERT INTO tasks (title,description,status,priority,module,type,due_date,created_by)
       VALUES ($1,$2,'backlog','high','content','campaign',$3,'system-seed')`,
      [`Campaign: ${txt(r[1])}`, desc, dueDate]
    );
    count++;
  }
  return count;
}

async function seedSeriesPlaybook(client, wb) {
  const rows = parseSheet(wb, 'Series Playbook').slice(4).filter(r => r[0] && r[1]);
  let count = 0;
  for (const r of rows) {
    const desc = [
      r[1] && `Purpose: ${r[1]}`,
      r[2] && `Audience promise: ${r[2]}`,
      r[3] && `Structure: ${r[3]}`,
      r[4] && `Signature shots: ${r[4]}`,
      r[5] && `Frequency: ${r[5]}`,
      r[6] && `Best platforms: ${r[6]}`,
      r[7] && `KPI: ${r[7]}`,
      r[8] && `Variations: ${r[8]}`,
      r[9] && `Avoid: ${r[9]}`,
    ].filter(Boolean).join('\n');
    await client.query(
      `INSERT INTO content_items (title,status,week_id,is_core,pillar,notes,has_compliance_warning,created_by)
       VALUES ($1,'idea',NULL,false,'Series Playbook',$2,false,'system-seed')`,
      [`[Series] ${txt(r[0])}`, desc]
    );
    count++;
  }
  return count;
}

async function seedWeeklyThemes(client, wb) {
  const rows = parseSheet(wb, 'Weekly Themes').slice(4).filter(r => r[0] && typeof r[0] === 'number');
  let count = 0;
  for (const r of rows) {
    const weekNum = r[0];
    const { rows: weekRows } = await client.query('SELECT id FROM operating_weeks WHERE week_number = $1', [weekNum]);
    if (!weekRows[0]) continue;
    const plan = [
      r[3] && `Editorial focus: ${r[3]}`,
      r[4] && `Feature highlight: ${r[4]}`,
      r[5] && `Audience: ${r[5]}`,
      r[7] && `Theme: ${r[7]}`,
      r[8] && `Core content plan: ${r[8]}`,
      r[9] && `Opening question: ${r[9]}`,
      r[11] && `Experiment: ${r[11]}`,
      r[12] && `KPI: ${r[12]}`,
    ].filter(Boolean).join('\n');
    await client.query(`UPDATE weekly_plans SET content_plan = $1 WHERE week_id = $2`, [plan, weekRows[0].id]);
    count++;
  }
  return count;
}

async function main() {
  const client = await pool.connect();
  try {
    const wb = XLSX.readFile(WB_PATH);
    console.log('📚 Loaded workbook:', wb.SheetNames.length, 'sheets\n');

    await clearPreviousSeed(client);

    console.log('🎬 Content Idea Bank (252 ideas)...');
    console.log(`  ✓ ${await seedContentIdeas(client, wb)} content ideas`);

    console.log('🎣 Hook Bank...');
    console.log(`  ✓ ${await seedHookBank(client, wb)} hooks`);

    console.log('📢 CTA Bank...');
    console.log(`  ✓ ${await seedCTABank(client, wb)} CTAs`);

    console.log('🧪 Growth Experiments...');
    console.log(`  ✓ ${await seedGrowthExperiments(client, wb)} experiments`);

    console.log('⚠️  Risk Register...');
    console.log(`  ✓ ${await seedRiskRegister(client, wb)} risks`);

    console.log('🤝 Partnership CRM...');
    console.log(`  ✓ ${await seedPartnershipCRM(client, wb)} partnerships`);

    console.log('📅 Campaign Moments...');
    console.log(`  ✓ ${await seedCampaignMoments(client, wb)} campaigns`);

    console.log('📺 Series Playbook...');
    console.log(`  ✓ ${await seedSeriesPlaybook(client, wb)} series`);

    console.log('📋 Updating Weekly Themes in plans...');
    console.log(`  ✓ ${await seedWeeklyThemes(client, wb)} weekly plans updated`);

    const { rows: s } = await client.query(
      `SELECT (SELECT COUNT(*) FROM content_items WHERE NOT is_deleted) as ci,
              (SELECT COUNT(*) FROM tasks WHERE NOT is_deleted) as t`
    );
    console.log(`\n🎉 Done! content_items=${s[0].ci}  tasks=${s[0].t}`);
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch(err => { console.error('❌', err.message, err.stack); process.exit(1); });
